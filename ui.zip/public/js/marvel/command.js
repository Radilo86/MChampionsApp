import { Cards } from "./cards.js";
import { Notify } from "./notify.js";
export class Command {
    static setLastClickCard(card_div) {
        if (Command.newWindow && !Command.newWindow.closed) {
            const card = Cards.getCard(Number(card_div.dataset.id));
            const data = {
                type: 'setLastClickCard',
                card_object_id: card_div.dataset.id,
                card_id: card.card_id,
                card_name: card.name,
            };
            Command.newWindow.postMessage(data, '*');
            Command.newWindow.focus();
            return true;
        }
        else {
            return false;
        }
    }
    static async saveLocal() {
        const response_block_thread = await fetch("save_local?");
        const text = await response_block_thread.text();
        Notify.showCommand(`Your save file has been saved in: ${text}`);
    }
    static async uploadSave(save_type, comment = "") {
        if (Command.newWindow && !Command.newWindow.closed) {
            Command.newWindow.close();
        }
        Command.newWindow = window.open(`report`, "newWindow", "width=400,height=320");
        const data = {
            type: 'uploadSave',
            save_type: save_type,
            comment: comment
        };
        Command.newWindow.onload = () => {
            Command.newWindow.postMessage(data, '*');
        };
    }
}
Command.newWindow = null;
