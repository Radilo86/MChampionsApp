import { Lib } from './lib.js';
import { Setting } from "./settings.js";
import { HoverCard } from './hover.js';
export class Scene {
    static init() {
        document.addEventListener('DOMContentLoaded', () => {
            adjustSceneScale();
        });
        window.onresize = () => {
            adjustSceneScale();
        };
        if (Setting.scene_3d) {
            Lib.loader.loadCSS("./css./marvel./scene-3d.css");
            document.body.classList.add('scene-3d');
        }
    }
}
Scene.scale = 0;
Scene.fit = 0;
Scene.zoom = 1;
Scene.slack = 0;
Scene.panX = 0;
Scene.panY = 0;
export function convertScenePosToWindowPos(sceneX, sceneY) {
    const scene = document.getElementById('scene');
    const rect = scene.getBoundingClientRect();
    const scale = Scene.scale;
    const windowX = (sceneX * scale) + rect.left;
    const windowY = (sceneY * scale) + rect.top;
    return { x: windowX, y: windowY };
}
export function getMousePositionInScene(windowX, windowY) {
    const scene = document.getElementById('scene');
    const rect = scene.getBoundingClientRect();
    const mouseX = windowX - rect.left;
    const mouseY = windowY - rect.top;
    const scale = Scene.scale;
    const sceneX = mouseX / scale;
    const sceneY = mouseY / scale;
    return { x: sceneX, y: sceneY };
}
export function adjustSceneScale() {
    const camera = document.getElementById('camera');
    const rootStyles = getComputedStyle(document.documentElement);
    const sceneWidth = parseFloat(rootStyles.getPropertyValue('--scene-width'));
    const sceneHeight = parseFloat(rootStyles.getPropertyValue('--scene-height'));
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;
    const scaleX = viewportWidth / sceneWidth;
    const scaleY = viewportHeight / sceneHeight;
    Scene.fit = Math.min(scaleX, scaleY);
    Scene.zoom = Math.max(0.5, Scene.zoom);
    Scene.scale = Scene.fit * Scene.zoom;
    camera.style.transform = `scale(${Scene.scale})`;
    if (Setting.scene_3d) {
        document.getElementById('scene').style.transform = `scale(1) rotateX(20deg)`;
    }
    camera.style.display = "unset";
    const freeX = viewportWidth - sceneWidth * Scene.scale;
    const freeY = viewportHeight - sceneHeight * Scene.scale;
    const slackX = innerWidth * Scene.slack, slackY = innerHeight * Scene.slack;
    Scene.panX = Math.min(Math.abs(freeX) / 2 + slackX, Math.max(-Math.abs(freeX) / 2 - slackX, Scene.panX));
    Scene.panY = Math.min(Math.abs(freeY) / 2 + slackY, Math.max(-Math.abs(freeY) / 2 - slackY, Scene.panY));
    camera.style.left = `${freeX / 2 + Scene.panX}px`;
    camera.style.top = `${freeY / 2 + Scene.panY}px`;
    const x = parseInt(rootStyles.getPropertyValue('--font-size'));
    document.documentElement.style.setProperty('--font-size-out', `${x * Scene.fit}px`);
    HoverCard.updateRect();
}
window.Scene = Scene;
window.adjustSceneScale = adjustSceneScale;
