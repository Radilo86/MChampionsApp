// Marvel Champions offline — "Modo edición": create content packs (cards with no-code rules, scenarios, sets) without
// programming. Everything it writes is validated by the game engine itself (content_check) before installing.
(function () {
    "use strict";
    var $ = function (s, r) { return (r || document).querySelector(s); };
    var esc = function (t) { var d = document.createElement("div"); d.textContent = t == null ? "" : String(t); return d.innerHTML; };
    var req = function (m, u, b) { return window.MarvelApp.request(m, u, b); };
    var DRAFT = "marvel-creador-draft";

    // ------------------------------------------------------------------------------------------- vocabulary
    var TYPES = [["Event", "Evento"], ["Ally", "Aliado"], ["Support", "Apoyo"], ["Upgrade", "Mejora"], ["Resource", "Recurso"],
        ["Minion", "Esbirro"], ["Treachery", "Traición"], ["Attachment", "Accesorio"], ["Environment", "Entorno"], ["SideScheme", "Plan secundario"],
        ["Obligation", "Obligación"], ["Villain", "Villano (una fase)"], ["MainScheme", "Plan principal (una cara)"]];
    var TYPE_ES = {}; TYPES.forEach(function (t) { TYPE_ES[t[0]] = t[1]; });
    var PLAYER = ["Event", "Ally", "Support", "Upgrade", "Resource"];
    var DESC = { Event: ["Cost", "Class", "RES"], Ally: ["Cost", "Class", "HP", "ATK", "THW", "RES"], Support: ["Cost", "Class", "RES", "Uses"],
        Upgrade: ["Cost", "Class", "RES", "Uses"], Resource: ["Class", "RES"], Minion: ["HP", "ATK", "SCH", "Boost"], Treachery: ["Boost"],
        Attachment: ["Boost", "ATK+", "SCH+"], Environment: ["Boost"], SideScheme: ["StartingThreat", "Boost"], Obligation: ["Boost"],
        Villain: ["HP", "ATK", "SCH", "Stage"], MainScheme: ["Stage", "StartingThreat", "TargetThreat", "EscalationThreat"] };
    var KEYWORDS = { Minion: ["Guard", "Toughness", "Quickstrike", "Surge", "Patrol", "Retaliate", "Teamwork", "Villainous"], Treachery: ["Surge", "Peril"],
        SideScheme: ["Acceleration", "Hazard", "Crisis", "Surge", "Amplify"], Villain: ["Toughness", "Retaliate", "Steady", "Stalwart"], Ally: ["Toughness"],
        Attachment: ["Surge"], Environment: ["Surge"] };
    var KEY_ES = { Cost: "Coste", Class: "Aspecto", HP: "Vida", ATK: "Ataque", THW: "Frustración", SCH: "Maquinación", RES: "Recursos (ej. Y, BB, R)",
        Uses: "Usos", Boost: "Iconos de potenciación", "ATK+": "Ataque +", "SCH+": "Maquinación +", Stage: "Fase", StartingThreat: "Amenaza inicial",
        TargetThreat: "Amenaza objetivo", EscalationThreat: "Escalada por ronda", Guard: "Guardián", Toughness: "Dureza", Quickstrike: "Ataque rápido",
        Surge: "Oleada", Patrol: "Patrulla", Retaliate: "Represalia", Teamwork: "Trabajo en equipo", Villainous: "Malvado", Peril: "Peligro",
        Acceleration: "Aceleración", Hazard: "Peligro (icono)", Crisis: "Crisis", Amplify: "Amplificar", Steady: "Firme", Stalwart: "Inquebrantable" };
    var CLASSES = ["Basic", "Aggression", "Justice", "Leadership", "Protection", "Pool", "Hero"];

    function triggersFor(type) {
        if (type === "Event") return ["Acción", "Acción de héroe", "Acción de héroe (ataque)", "Acción de héroe (frustración)", "Acción de alter-ego"];
        if (type === "Support" || type === "Upgrade") return ["Acción", "Acción de héroe", "Acción de alter-ego", "Al entrar en juego"];
        if (type === "Ally") return ["Acción", "Al entrar en juego", "Al ser derrotado"];
        if (type === "Resource") return ["Acción"];
        if (type === "Treachery" || type === "Attachment" || type === "Environment" || type === "Obligation") return ["Al revelarse", "Al revelarse (héroe)", "Al revelarse (alter-ego)", "Potenciación"];
        if (type === "Minion") return ["Al revelarse", "Al revelarse (héroe)", "Al revelarse (alter-ego)", "Al ser derrotado", "Potenciación"];
        if (type === "SideScheme") return ["Al revelarse", "Al ser derrotado", "Potenciación"];
        if (type === "Villain") return ["Al revelarse", "Al ser derrotado"];
        if (type === "MainScheme") return ["Al revelarse"];
        return ["Acción"];
    }
    var A = function (t) { return /^el /.test(t) ? "al " + t.slice(3) : "a " + t; };
    var DE = function (t) { return /^el /.test(t) ? "del " + t.slice(3) : "de " + t; };
    var UNITS = ["un enemigo", "el villano", "un esbirro", "cada enemigo", "cada esbirro", "tu héroe", "cada héroe", "un personaje", "un aliado", "cada aliado", "esta carta"];
    var HEAL = ["tu héroe", "un personaje", "un aliado", "cada héroe", "cada aliado", "el villano", "esta carta"];
    var FOES = ["un enemigo", "el villano", "un esbirro", "cada enemigo", "cada esbirro"];
    var FRIENDS = ["tu héroe", "un personaje", "un aliado", "cada aliado"];
    var PLANS = ["un plan", "el plan principal", "cada plan", "un plan secundario", "cada plan secundario", "esta carta"];
    // every effect the engine understands (engine/browser/rules.py), as a small form
    var EFFECTS = [
        { k: "damage", es: "Infligir daño", p: ["n", "per", "t"], opts: UNITS, f: function (o) { return "inflige " + o.n + (o.per ? " por jugador" : "") + " de daño " + A(o.t); } },
        { k: "heal", es: "Curar daño", p: ["n", "t"], opts: HEAL, f: function (o) { return "cura " + o.n + " de daño " + A(o.t); } },
        { k: "rthreat", es: "Quitar amenaza", p: ["n", "per", "t"], opts: PLANS, f: function (o) { return "quita " + o.n + (o.per ? " por jugador" : "") + " de amenaza " + DE(o.t); } },
        { k: "pthreat", es: "Poner amenaza", p: ["n", "per", "t"], opts: PLANS, f: function (o) { return "pon " + o.n + (o.per ? " por jugador" : "") + " de amenaza en " + o.t; } },
        { k: "draw", es: "Robar cartas", p: ["n", "each"], f: function (o) { return (o.each ? "cada jugador roba " : "roba ") + o.n + (o.n == 1 ? " carta" : " cartas"); } },
        { k: "discard", es: "Descartar al azar", p: ["n", "each"], f: function (o) { return (o.each ? "cada jugador descarta " : "descarta ") + o.n + (o.n == 1 ? " carta" : " cartas") + " al azar"; } },
        { k: "stun", es: "Aturdir", p: ["t"], opts: FOES, f: function (o) { return "aturde " + A(o.t); } },
        { k: "confuse", es: "Confundir", p: ["t"], opts: FOES, f: function (o) { return "confunde " + A(o.t); } },
        { k: "tough", es: "Dar dureza", p: ["t"], opts: FRIENDS.concat(["el villano"]), f: function (o) { return "da dureza " + A(o.t); } },
        { k: "ready", es: "Preparar", p: ["t"], opts: FRIENDS, f: function (o) { return "prepara " + A(o.t); } },
        { k: "exhaust", es: "Agotar", p: ["t"], opts: FRIENDS.concat(FOES), f: function (o) { return "agota " + A(o.t); } },
        { k: "vscheme", es: "El villano maquina", enc: 1, p: ["each"], f: function (o) { return o.each ? "el villano maquina contra cada jugador" : "el villano maquina"; } },
        { k: "vattack", es: "El villano ataca", enc: 1, p: ["each"], f: function (o) { return o.each ? "el villano ataca a cada jugador" : "el villano te ataca"; } },
        { k: "encounter", es: "Recibir cartas de encuentro", enc: 1, p: ["n", "each"], f: function (o) { return (o.each ? "cada jugador recibe " : "recibe ") + o.n + (o.n == 1 ? " carta" : " cartas") + " de encuentro"; } },
        { k: "surge", es: "Oleada (revela otra carta)", enc: 1, p: [], f: function () { return "esta carta gana oleada"; } },
        { k: "search", es: "Buscar una carta y revelarla", enc: 1, p: ["name", "put"], f: function (o) { return "busca «" + (o.name || "Nombre") + "» en el mazo y la pila de descartes de encuentros y " + (o.put ? "ponla en juego" : "revélala"); } },
        { k: "until", es: "Descartar hasta un esbirro", enc: 1, p: [], f: function () { return "descarta cartas de encuentro hasta un esbirro y ponlo en juego"; } },
    ];

    // ------------------------------------------------------------------------------------------- state
    var V = null;            // vocabulary from the engine
    var P = null;            // the pack being edited
    var sel = { card: 0, scen: 0, set: 0 };
    var lastReport = null;
    function blank() {
        return { info: { id: "mi_campania", nombre: "Mi campaña", version: "1", autor: "", descripcion: "" }, caja: { nombre: "90. Mi campaña" },
                 cards: [], scenarios: [], sets: [] };
    }
    function save() { try { localStorage.setItem(DRAFT, JSON.stringify(P)); status("Borrador guardado"); } catch (e) {} $("#packname").textContent = P.info.nombre || P.info.id; }
    var saveSoon = (function () { var t; return function () { clearTimeout(t); t = setTimeout(save, 400); }; })();
    function status(t) { $("#status").textContent = t; }
    function slug(t) { return String(t || "").toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9_\-]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 40) || "x"; }
    function nextId(suffix) {
        var used = {}; (V.used_ids || []).forEach(function (i) { used[i.replace(/[a-z]$/, "")] = 1; }); P.cards.forEach(function (c) { used[String(c.card_id).replace(/[a-z]$/, "")] = 1; });
        for (var n = 99001; n < 99999; n++) if (!used[String(n)]) return String(n) + (suffix || "");
        return "99999";
    }
    function cardName(id) {
        var c = P.cards.find(function (x) { return x.card_id === id; }); if (c) return c.name;
        var v = (V.villains || []).concat(V.main_schemes || []).find(function (x) { return x[0] === id; }); return v ? v[1] : "";
    }
    function encounterCards() { return P.cards.filter(function (c) { return PLAYER.indexOf(c.type) < 0 && c.type !== "Villain" && c.type !== "MainScheme"; }); }

    // ------------------------------------------------------------------------------------------- tabs
    function show(tab) {
        Array.prototype.forEach.call(document.querySelectorAll("nav button"), function (b) { b.classList.toggle("on", b.dataset.tab === tab); });
        Array.prototype.forEach.call(document.querySelectorAll("section"), function (s) { s.classList.toggle("on", s.id === "tab-" + tab); });
        ({ pack: renderPack, cards: renderCards, scen: renderScen, sets: renderSets, check: renderCheck })[tab]();
        window.scrollTo(0, 0);
    }
    function counts() {
        var b = document.querySelectorAll("nav button");
        b[1].textContent = "Cartas (" + P.cards.length + ")"; b[2].textContent = "Escenarios (" + P.scenarios.length + ")"; b[3].textContent = "Sets (" + P.sets.length + ")";
    }
    function field(label, value, attrs, help) {
        return '<label class="f">' + esc(label) + '<input ' + (attrs || "") + ' value="' + esc(value == null ? "" : value) + '">' + (help ? '<span class="help">' + esc(help) + "</span>" : "") + "</label>";
    }

    // ------------------------------------------------------------------------------------------- pack
    function renderPack() {
        var s = $("#tab-pack");
        s.innerHTML = '<div class="box"><h2>Datos del paquete</h2><div class="grid">' +
            field("Nombre", P.info.nombre, 'data-k="nombre"') + field("Identificador (sin espacios)", P.info.id, 'data-k="id"', "minúsculas, números, _ o -") +
            field("Versión", P.info.version, 'data-k="version"') + field("Autor", P.info.autor, 'data-k="autor"') + "</div>" +
            '<label class="f" style="margin-top:8px">Descripción<textarea data-k="descripcion">' + esc(P.info.descripcion) + "</textarea></label></div>" +
            '<div class="box"><h2>Caja en «New Game»</h2><div class="grid">' + field("Nombre de la caja", P.caja.nombre, 'data-c="nombre"', "Ej.: «90. Mi campaña». Agrupa tus escenarios y sets.") + "</div>" +
            '<p class="help">La caja incluye automáticamente todos los escenarios y sets del paquete.</p></div>' +
            '<div class="box"><h2>Cómo funciona</h2><p class="help">1) Crea cartas en <b>Cartas</b> y describe lo que hacen con el <b>constructor de reglas</b> (sin programar). ' +
            "2) Crea escenarios (villano, plan principal y cartas de encuentro) y sets. 3) En <b>Comprobar e instalar</b> el motor del juego revisa todo, " +
            "lo instala y puedes <b>probar cada carta en partida</b>. El borrador se guarda solo en este dispositivo.</p></div>";
        s.querySelectorAll("[data-k]").forEach(function (i) { i.addEventListener("input", function () { P.info[i.dataset.k] = i.value; if (i.dataset.k === "nombre" && !P.info._idTouched) { P.info.id = slug(i.value); var idI = s.querySelector('[data-k="id"]'); if (idI) idI.value = P.info.id; } if (i.dataset.k === "id") P.info._idTouched = true; saveSoon(); }); });
        s.querySelectorAll("[data-c]").forEach(function (i) { i.addEventListener("input", function () { P.caja.nombre = i.value; saveSoon(); }); });
    }

    // ------------------------------------------------------------------------------------------- cards
    function errorsOf(cardId) {
        if (!lastReport) return [];
        return lastReport.errors.filter(function (e) { return e.indexOf("carta " + cardId + " ") >= 0 || e.indexOf("carta " + cardId + ")") >= 0 || e.indexOf("carta " + cardId + ":") >= 0; });
    }
    function renderCards() {
        counts();
        var s = $("#tab-cards");
        var list = P.cards.map(function (c, i) {
            var errs = errorsOf(c.card_id).length;
            return '<div class="item' + (i === sel.card ? " sel" : "") + '" data-i="' + i + '"><div class="t"><b>' + esc(c.name || "(sin nombre)") + "</b><small>" + esc(c.card_id) + " · " + esc(TYPE_ES[c.type] || c.type) + "</small></div>" +
                ((c.reglas || []).length ? '<span class="badge rule">' + c.reglas.length + " regla" + (c.reglas.length > 1 ? "s" : "") + "</span>" : "") + (errs ? '<span class="badge err">' + errs + " error</span>" : "") + "</div>";
        }).join("");
        s.innerHTML = '<div class="two"><div><div class="row"><select id="new-type">' + TYPES.map(function (t) { return '<option value="' + t[0] + '">' + t[1] + "</option>"; }).join("") +
            '</select><button class="btn red" id="add-card">+ Carta</button></div><div class="list" id="card-list">' + (list || '<p class="help">Aún no hay cartas.</p>') + "</div></div><div id=\"card-ed\"></div></div>";
        s.querySelector("#add-card").onclick = function () {
            var type = s.querySelector("#new-type").value;
            if (type === "MainScheme") {           // a main scheme has two faces: A (setup text) and B (threat values)
                var base = nextId(); P.cards.push({ card_id: base + "a", type: type, name: "Plan principal", desc: { Stage: "1" }, traits: [], reglas: [] },
                    { card_id: base + "b", type: type, name: "Plan principal", desc: { Stage: "1", StartingThreat: "0", TargetThreat: "7*", EscalationThreat: "1*" }, traits: [], reglas: [] });
                sel.card = P.cards.length - 2;
            } else {
                var c = { card_id: nextId(), type: type, name: "", desc: {}, traits: [], set_name: "", reglas: [] };
                (DESC[type] || []).forEach(function (k) { c.desc[k] = { Cost: "1", HP: "3", ATK: "1", THW: "1", SCH: "1", Boost: "1", Class: "Basic", Stage: "1", StartingThreat: "2", RES: "" }[k] || ""; });
                if (type === "Villain") { c.desc.HP = "12"; c.desc.ATK = "2"; }
                P.cards.push(c); sel.card = P.cards.length - 1;
            }
            save(); renderCards();
        };
        s.querySelectorAll(".item").forEach(function (it) { it.onclick = function () { sel.card = +it.dataset.i; renderCards(); }; });
        if (P.cards[sel.card]) renderCardEditor(P.cards[sel.card]); else sel.card = 0;
    }
    // refresh ONLY the list on the left: re-rendering the editor while the player is typing / about to tap a button would
    // destroy the button before it receives the tap (the "change" of a field fires right before the click)
    function renderCardList() {
        var box = $("#card-list"); if (!box) return;
        P.cards.forEach(function (c, i) {
            var it = box.querySelector('[data-i="' + i + '"]'); if (!it) return;
            it.querySelector("b").textContent = c.name || "(sin nombre)";
            it.querySelector("small").textContent = c.card_id + " · " + (TYPE_ES[c.type] || c.type);
        });
        counts();
    }
    function renderCardEditor(c) {
        var ed = $("#card-ed");
        var keys = (DESC[c.type] || []);
        var extra = Object.keys(c.desc || {}).filter(function (k) { return keys.indexOf(k) < 0 && (KEYWORDS[c.type] || []).indexOf(k) < 0; });
        var allowed = (V.desc_keys[c.type] || []).filter(function (k) { return keys.indexOf(k) < 0 && (KEYWORDS[c.type] || []).indexOf(k) < 0 && extra.indexOf(k) < 0; });
        var errs = errorsOf(c.card_id);
        ed.innerHTML = '<div class="box"><h2>' + esc(TYPE_ES[c.type] || c.type) + ' <span class="badge">' + esc(c.card_id) + "</span></h2>" +
            errs.map(function (e) { return '<div class="msg err">' + esc(e) + "</div>"; }).join("") +
            '<div class="grid">' + field("Número (id)", c.card_id, 'data-f="card_id"', c.type === "MainScheme" ? "termina en a o b (dos caras)" : "único, p. ej. 99001") +
            field("Nombre", c.name, 'data-f="name"') + field("Subtítulo", c.subtitle || "", 'data-f="subtitle"') +
            field("Rasgos (separados por comas)", (c.traits || []).join(", "), 'data-f="traits"', "ej.: CRIMINAL, HYDRA") +
            (PLAYER.indexOf(c.type) < 0 ? field("Set (nombre visible)", c.set_name || "", 'data-f="set_name"') : "") + "</div>" +
            '<h2 style="margin-top:12px">Valores impresos</h2><div class="grid">' +
            keys.concat(extra).map(function (k) {
                if (k === "Class") return '<label class="f">' + KEY_ES[k] + '<select data-d="Class">' + CLASSES.map(function (x) { return "<option" + (c.desc.Class === x ? " selected" : "") + ">" + x + "</option>"; }).join("") + "</select></label>";
                return field((KEY_ES[k] || k) + " (" + k + ")", (c.desc || {})[k], 'data-d="' + k + '"', /Threat|Stage/.test(k) ? "«*» = por jugador (ej. 7*)" : "");
            }).join("") + "</div>" +
            ((KEYWORDS[c.type] || []).length ? '<div class="row">' + KEYWORDS[c.type].map(function (k) { return '<label class="chk"><input type="checkbox" data-kw="' + k + '"' + ((c.desc || {})[k] ? " checked" : "") + ">" + esc(KEY_ES[k] || k) + "</label>"; }).join("") + "</div>" : "") +
            (allowed.length ? '<div class="row"><select id="add-desc"><option value="">+ otro valor impreso…</option>' + allowed.map(function (k) { return '<option value="' + k + '">' + esc((KEY_ES[k] || k) + " (" + k + ")") + "</option>"; }).join("") + "</select></div>" : "") +
            '<h2 style="margin-top:12px">Reglas (lo que hace la carta)</h2><div id="rules">' +
            (c.reglas || []).map(function (r, i) { return '<div class="rule"><input data-r="' + i + '" value="' + esc(r) + '"><button class="btn small" data-del="' + i + '">✕</button></div>'; }).join("") +
            ((c.reglas || []).length ? "" : '<p class="help">Sin reglas: la carta solo tiene sus valores y palabras clave.</p>') + "</div>" +
            '<div class="builder" id="builder"></div>' +
            '<label class="f" style="margin-top:10px">Texto que se ve en la carta<textarea data-f="text">' + esc(c.text || "") + "</textarea></label>" +
            '<div class="row"><button class="btn small" id="gen-text">Generar el texto a partir de las reglas</button><button class="btn small" id="dup">Duplicar</button><button class="btn small red" id="del">Eliminar carta</button></div></div>';
        ed.querySelectorAll("[data-f]").forEach(function (i) {
            i.addEventListener("input", function () {
                var f = i.dataset.f;
                if (f === "traits") c.traits = i.value.split(",").map(function (x) { return x.trim().toUpperCase(); }).filter(Boolean);
                else c[f] = i.value;
                saveSoon();
            });
            i.addEventListener("input", function () { if (i.dataset.f === "card_id" || i.dataset.f === "name") renderCardList(); });
        });
        ed.querySelectorAll("[data-d]").forEach(function (i) { i.addEventListener(i.tagName === "SELECT" ? "change" : "input", function () { c.desc[i.dataset.d] = i.value; saveSoon(); }); });
        ed.querySelectorAll("[data-kw]").forEach(function (i) { i.addEventListener("change", function () { if (i.checked) c.desc[i.dataset.kw] = "1"; else delete c.desc[i.dataset.kw]; saveSoon(); }); });
        var ad = ed.querySelector("#add-desc"); if (ad) ad.onchange = function () { if (ad.value) { c.desc[ad.value] = ""; save(); renderCardEditor(c); } };
        ed.querySelectorAll("[data-r]").forEach(function (i) { i.addEventListener("input", function () { c.reglas[+i.dataset.r] = i.value; saveSoon(); }); });
        ed.querySelectorAll("[data-del]").forEach(function (b) { b.onclick = function () { c.reglas.splice(+b.dataset.del, 1); save(); renderCardEditor(c); renderCardsListOnly(); }; });
        ed.querySelector("#gen-text").onclick = function () {
            var kws = (KEYWORDS[c.type] || []).filter(function (k) { return (c.desc || {})[k]; });
            c.text = kws.join(". ") + (kws.length ? ".\n" : "") + (c.reglas || []).map(function (r) { var k = r.indexOf(":"); return "<b>" + r.slice(0, k).trim() + "</b>:" + r.slice(k + 1); }).join("\n");
            save(); renderCardEditor(c);
        };
        ed.querySelector("#dup").onclick = function () { var d = JSON.parse(JSON.stringify(c)); d.card_id = nextId(/[ab]$/.test(c.card_id) ? c.card_id.slice(-1) : ""); P.cards.push(d); sel.card = P.cards.length - 1; save(); renderCards(); };
        ed.querySelector("#del").onclick = function () { if (confirm("¿Eliminar la carta " + c.card_id + "?")) { P.cards.splice(sel.card, 1); sel.card = Math.max(0, sel.card - 1); save(); renderCards(); } };
        renderBuilder(c);
    }
    function renderCardsListOnly() {          // the number of rules shown in the list changed
        var box = $("#card-list"), c = P.cards[sel.card]; if (!box || !c) return;
        var it = box.querySelector('[data-i="' + sel.card + '"]'); if (!it) return;
        var badge = it.querySelector(".badge.rule"); var n = (c.reglas || []).length;
        if (!badge && n) { badge = document.createElement("span"); badge.className = "badge rule"; it.appendChild(badge); }
        if (badge) { if (n) badge.textContent = n + " regla" + (n > 1 ? "s" : ""); else badge.remove(); }
    }

    // ------------------------------------------------------------------------------------------- rule builder
    function renderBuilder(c) {
        var b = $("#builder");
        var trig = triggersFor(c.type);
        var st = c._b || (c._b = { trig: trig[0], cost: "", effects: [] });
        if (trig.indexOf(st.trig) < 0) st.trig = trig[0];
        var canCost = /^Acción/.test(st.trig) && ["Support", "Upgrade", "Ally"].indexOf(c.type) >= 0;
        var effs = EFFECTS.filter(function (e) { return !e.enc || PLAYER.indexOf(c.type) < 0; });
        function sentence() {
            var head = st.trig + (canCost && st.cost ? ", " + st.cost : "");
            return head + ": " + (st.effects.map(function (e) { var d = EFFECTS.find(function (x) { return x.k === e.k; }); return d.f(e); }).join(" y ") || "…") + ".";
        }
        b.innerHTML = '<b>Constructor de reglas</b><div class="row"><label class="f">Cuándo<select id="b-trig">' + trig.map(function (t) { return "<option" + (t === st.trig ? " selected" : "") + ">" + t + "</option>"; }).join("") + "</select></label>" +
            (canCost ? '<label class="f">Coste<select id="b-cost"><option value="">ninguno</option><option' + (st.cost === "agota esta carta" ? " selected" : "") + '>agota esta carta</option><option' + (st.cost === "descarta una carta de tu mano" ? " selected" : "") + ">descarta una carta de tu mano</option></select></label>" : "") + "</div>" +
            '<div id="b-effs">' + st.effects.map(function (e, i) {
                var d = EFFECTS.find(function (x) { return x.k === e.k; });
                return '<div class="eff"><b>' + esc(d.es) + "</b>" + d.p.map(function (p) {
                    if (p === "n") return '<input type="number" min="1" max="20" data-e="' + i + '" data-p="n" value="' + (e.n || 1) + '">';
                    if (p === "per") return '<label class="chk"><input type="checkbox" data-e="' + i + '" data-p="per"' + (e.per ? " checked" : "") + ">por jugador</label>";
                    if (p === "each") return '<label class="chk"><input type="checkbox" data-e="' + i + '" data-p="each"' + (e.each ? " checked" : "") + ">cada jugador</label>";
                    if (p === "put") return '<label class="chk"><input type="checkbox" data-e="' + i + '" data-p="put"' + (e.put ? " checked" : "") + ">ponerla en juego (si no, se revela)</label>";
                    if (p === "name") return '<input data-e="' + i + '" data-p="name" placeholder="nombre exacto de la carta" value="' + esc(e.name || "") + '">';
                    if (p === "t") return '<select data-e="' + i + '" data-p="t">' + d.opts.map(function (o) { return "<option" + (o === e.t ? " selected" : "") + ">" + o + "</option>"; }).join("") + "</select>";
                    return "";
                }).join("") + '<button class="btn small" data-rm="' + i + '">✕</button></div>';
            }).join("") + "</div>" +
            '<div class="row"><select id="b-add"><option value="">+ añadir efecto…</option>' + effs.map(function (e) { return '<option value="' + e.k + '">' + esc(e.es) + "</option>"; }).join("") + "</select></div>" +
            '<div class="preview" id="b-prev">' + esc(sentence()) + '</div><div class="row"><button class="btn ok" id="b-ok"' + (st.effects.length ? "" : " disabled") + '>Añadir esta regla a la carta</button>' +
            '<span class="help">Si eliges «un enemigo», «un plan»…, el jugador lo elige al usar la carta (uno por regla).</span></div>';
        function upd() { $("#b-prev").textContent = sentence(); }
        b.querySelector("#b-trig").onchange = function (ev) { st.trig = ev.target.value; renderBuilder(c); };
        var bc = b.querySelector("#b-cost"); if (bc) bc.onchange = function () { st.cost = bc.value; upd(); };
        b.querySelector("#b-add").onchange = function (ev) {
            var k = ev.target.value; if (!k) return; var d = EFFECTS.find(function (x) { return x.k === k; });
            st.effects.push({ k: k, n: 1, t: d.opts ? d.opts[0] : undefined }); renderBuilder(c);
        };
        b.querySelectorAll("[data-e]").forEach(function (i) {
            i.addEventListener(i.type === "checkbox" || i.tagName === "SELECT" ? "change" : "input", function () {
                var e = st.effects[+i.dataset.e]; var p = i.dataset.p;
                e[p] = i.type === "checkbox" ? i.checked : (p === "n" ? Math.max(1, parseInt(i.value || "1", 10)) : i.value); upd();
            });
        });
        b.querySelectorAll("[data-rm]").forEach(function (x) { x.onclick = function () { st.effects.splice(+x.dataset.rm, 1); renderBuilder(c); }; });
        b.querySelector("#b-ok").onclick = function () { (c.reglas = c.reglas || []).push(sentence()); c._b = null; save(); renderCardEditor(c); renderCardsListOnly(); };
    }

    // ------------------------------------------------------------------------------------------- scenarios
    function idChips(arr, key, copies) {
        return '<div class="ids">' + arr.map(function (v, i) {
            return '<span class="chip">' + esc(v.id || v) + ' <small>' + esc(cardName((v.id || v).split(",")[0])) + "</small>" +
                (copies ? '<input type="number" min="1" max="9" data-cp="' + key + '" data-i="' + i + '" value="' + v.n + '">' : "") + '<button data-x="' + key + '" data-i="' + i + '">×</button></span>';
        }).join("") + "</div>";
    }
    function countsOf(list) { var out = [], m = {}; (list || []).forEach(function (id) { if (m[id]) m[id].n++; else { m[id] = { id: id, n: 1 }; out.push(m[id]); } }); return out; }
    function expand(arr) { var out = []; arr.forEach(function (v) { for (var i = 0; i < v.n; i++) out.push(v.id); }); return out; }
    function renderScen() {
        counts();
        var s = $("#tab-scen");
        var list = P.scenarios.map(function (sc, i) { return '<div class="item' + (i === sel.scen ? " sel" : "") + '" data-i="' + i + '"><div class="t"><b>' + esc(sc.name) + "</b><small>" + esc(sc.file) + (sc.expert ? " · con versión experta" : "") + "</small></div></div>"; }).join("");
        s.innerHTML = '<div class="two"><div><div class="row"><button class="btn red" id="add-scen">+ Escenario</button></div><div class="list">' + (list || '<p class="help">Aún no hay escenarios.</p>') + '</div></div><div id="scen-ed"></div></div>';
        s.querySelector("#add-scen").onclick = function () {
            P.scenarios.push({ name: "Nuevo escenario", file: "escenario_" + (P.scenarios.length + 1), villain: [], villain_expert: [], schemes: [], encounters: [], encounter_sets: ["standard"], modular_sets: [], set_aside: [], expert: true });
            sel.scen = P.scenarios.length - 1; save(); renderScen();
        };
        s.querySelectorAll(".item").forEach(function (it) { it.onclick = function () { sel.scen = +it.dataset.i; renderScen(); }; });
        var sc = P.scenarios[sel.scen]; if (!sc) return;
        var villains = P.cards.filter(function (c) { return c.type === "Villain"; }).map(function (c) { return [c.card_id, c.name + " (tuyo)"]; }).concat(V.villains);
        var mains = P.cards.filter(function (c) { return c.type === "MainScheme" && /a$/.test(c.card_id); }).map(function (c) { return [c.card_id, c.name + " (tuyo)"]; }).concat(V.main_schemes);
        var enc = encounterCards();
        var sets = P.sets.map(function (x) { return x.file; }).concat(V.encounter_sets.filter(function (n) { return ["standard", "standard_ii", "standard_iii", "expert", "expert_ii"].indexOf(n) < 0; }));
        var opt = function (arr) { return arr.map(function (x) { return '<option value="' + esc(x[0]) + '">' + esc(x[0] + " — " + x[1]) + "</option>"; }).join(""); };
        $("#scen-ed").innerHTML = '<div class="box"><div class="grid">' + field("Nombre", sc.name, 'data-s="name"') + field("Archivo (sin espacios)", sc.file, 'data-s="file"') + "</div>" +
            "<h2>Villano: fases (en orden)</h2>" + idChips(sc.villain, "villain") + '<div class="row"><select id="add-vil"><option value="">+ añadir fase de villano…</option>' + opt(villains) + "</select></div>" +
            '<label class="chk"><input type="checkbox" id="expert"' + (sc.expert ? " checked" : "") + '>Crear también la versión experta</label>' +
            (sc.expert ? "<h2>Villano en experto: fases</h2>" + idChips(sc.villain_expert, "villain_expert") + '<div class="row"><select id="add-vilx"><option value="">+ añadir fase (experto)…</option>' + opt(villains) + "</select></div>" : "") +
            "<h2>Plan principal</h2>" + idChips(sc.schemes, "schemes") + '<div class="row"><select id="add-sch"><option value="">+ añadir plan principal…</option>' + opt(mains) + "</select></div>" +
            "<h2>Cartas de encuentro propias (y copias)</h2>" + idChips(countsOf(sc.encounters), "encounters", true) +
            '<div class="row"><select id="add-enc"><option value="">+ añadir carta de encuentro…</option>' + enc.map(function (c) { return '<option value="' + c.card_id + '">' + esc(c.card_id + " — " + c.name + " (" + TYPE_ES[c.type] + ")") + "</option>"; }).join("") +
            '</select><input id="enc-free" placeholder="o un número del juego" style="max-width:170px"><button class="btn small" id="enc-add">Añadir</button></div>' +
            "<h2>Sets</h2><div class=\"row\">" + '<label class="chk"><input type="checkbox" id="std"' + (sc.encounter_sets.indexOf("standard") >= 0 ? " checked" : "") + '>Estándar (standard)</label></div>' +
            idChips(sc.modular_sets, "modular_sets") + '<div class="row"><select id="add-mod"><option value="">+ añadir set modular…</option>' + sets.map(function (n) { return "<option>" + esc(n) + "</option>"; }).join("") + "</select></div>" +
            '<div class="row"><button class="btn small red" id="del-scen">Eliminar escenario</button></div></div>';
        var ed = $("#scen-ed");
        ed.querySelectorAll("[data-s]").forEach(function (i) { i.addEventListener("input", function () { sc[i.dataset.s] = i.dataset.s === "file" ? slug(i.value) : i.value; if (i.dataset.s === "name" && !sc._fileTouched) sc.file = slug(i.value); if (i.dataset.s === "file") sc._fileTouched = true; saveSoon(); var it = document.querySelector('#tab-scen .item.sel'); if (it) { it.querySelector("b").textContent = sc.name; it.querySelector("small").textContent = sc.file; } var fi = ed.querySelector('[data-s="file"]'); if (fi && i.dataset.s === "name" && !sc._fileTouched) fi.value = sc.file; }); });
        var addTo = function (sel_, key, map) { var e = ed.querySelector(sel_); if (e) e.onchange = function () { if (e.value) { sc[key].push(map ? map(e.value) : e.value); save(); renderScen(); } }; };
        addTo("#add-vil", "villain"); addTo("#add-vilx", "villain_expert");
        addTo("#add-sch", "schemes", function (a) { return a + "," + a.replace(/a$/, "b"); });
        addTo("#add-mod", "modular_sets");
        addTo("#add-enc", "encounters");
        ed.querySelector("#enc-add").onclick = function () { var v = ed.querySelector("#enc-free").value.trim(); if (v) { sc.encounters.push(v); save(); renderScen(); } };
        ed.querySelector("#expert").onchange = function (ev) { sc.expert = ev.target.checked; save(); renderScen(); };
        ed.querySelector("#std").onchange = function (ev) { sc.encounter_sets = ev.target.checked ? ["standard"] : []; save(); };
        ed.querySelectorAll("[data-x]").forEach(function (x) { x.onclick = function () {
            var k = x.dataset.x, i = +x.dataset.i;
            if (k === "encounters") { var c = countsOf(sc.encounters); c.splice(i, 1); sc.encounters = expand(c); } else sc[k].splice(i, 1);
            save(); renderScen(); }; });
        ed.querySelectorAll("[data-cp]").forEach(function (x) { x.onchange = function () { var c = countsOf(sc.encounters); c[+x.dataset.i].n = Math.max(1, +x.value || 1); sc.encounters = expand(c); save(); }; });
        ed.querySelector("#del-scen").onclick = function () { if (confirm("¿Eliminar el escenario?")) { P.scenarios.splice(sel.scen, 1); sel.scen = 0; save(); renderScen(); } };
    }

    // ------------------------------------------------------------------------------------------- sets
    function renderSets() {
        counts();
        var s = $("#tab-sets");
        var list = P.sets.map(function (x, i) { return '<div class="item' + (i === sel.set ? " sel" : "") + '" data-i="' + i + '"><div class="t"><b>' + esc(x.name) + "</b><small>" + esc(x.file) + " · " + x.encounters.length + " cartas</small></div></div>"; }).join("");
        s.innerHTML = '<div class="two"><div><div class="row"><button class="btn red" id="add-set">+ Set</button></div><div class="list">' + (list || '<p class="help">Un set modular agrupa cartas de encuentro que se pueden añadir a cualquier escenario.</p>') + '</div></div><div id="set-ed"></div></div>';
        s.querySelector("#add-set").onclick = function () { P.sets.push({ name: "Nuevo set", file: "set_" + (P.sets.length + 1), encounters: [] }); sel.set = P.sets.length - 1; save(); renderSets(); };
        s.querySelectorAll(".item").forEach(function (it) { it.onclick = function () { sel.set = +it.dataset.i; renderSets(); }; });
        var st = P.sets[sel.set]; if (!st) return;
        var enc = encounterCards();
        $("#set-ed").innerHTML = '<div class="box"><div class="grid">' + field("Nombre", st.name, 'data-s="name"') + field("Archivo (sin espacios)", st.file, 'data-s="file"', "es el nombre que se usa en «Sets» del escenario") + "</div>" +
            "<h2>Cartas (y copias)</h2>" + idChips(countsOf(st.encounters), "encounters", true) +
            '<div class="row"><select id="add-enc"><option value="">+ añadir carta de encuentro…</option>' + enc.map(function (c) { return '<option value="' + c.card_id + '">' + esc(c.card_id + " — " + c.name) + "</option>"; }).join("") +
            '</select><input id="enc-free" placeholder="o un número del juego" style="max-width:170px"><button class="btn small" id="enc-add">Añadir</button></div>' +
            '<div class="row"><button class="btn small red" id="del-set">Eliminar set</button></div></div>';
        var ed = $("#set-ed");
        ed.querySelectorAll("[data-s]").forEach(function (i) { i.addEventListener("input", function () { st[i.dataset.s] = i.dataset.s === "file" ? slug(i.value) : i.value; if (i.dataset.s === "name" && !st._fileTouched) st.file = slug(i.value); if (i.dataset.s === "file") st._fileTouched = true; saveSoon(); var it = document.querySelector('#tab-sets .item.sel'); if (it) { it.querySelector("b").textContent = st.name; } var fi = ed.querySelector('[data-s="file"]'); if (fi && i.dataset.s === "name" && !st._fileTouched) fi.value = st.file; }); });
        ed.querySelector("#add-enc").onchange = function (ev) { if (ev.target.value) { st.encounters.push(ev.target.value); save(); renderSets(); } };
        ed.querySelector("#enc-add").onclick = function () { var v = ed.querySelector("#enc-free").value.trim(); if (v) { st.encounters.push(v); save(); renderSets(); } };
        ed.querySelectorAll("[data-x]").forEach(function (x) { x.onclick = function () { var c = countsOf(st.encounters); c.splice(+x.dataset.i, 1); st.encounters = expand(c); save(); renderSets(); }; });
        ed.querySelectorAll("[data-cp]").forEach(function (x) { x.onchange = function () { var c = countsOf(st.encounters); c[+x.dataset.i].n = Math.max(1, +x.value || 1); st.encounters = expand(c); save(); }; });
        ed.querySelector("#del-set").onclick = function () { if (confirm("¿Eliminar el set?")) { P.sets.splice(sel.set, 1); sel.set = 0; save(); renderSets(); } };
    }

    // ------------------------------------------------------------------------------------------- files (pack layout)
    function clean(card) {
        var c = {}; ["card_id", "type", "name", "subtitle", "desc", "traits", "set_name", "text", "reglas"].forEach(function (k) { if (card[k] != null && card[k] !== "") c[k] = card[k]; });
        c.desc = {}; Object.keys(card.desc || {}).forEach(function (k) { if (card.desc[k] !== "" && card.desc[k] != null) c.desc[k] = String(card.desc[k]); });
        if (c.reglas && !c.reglas.length) delete c.reglas;
        if (!c.traits) c.traits = [];
        return c;
    }
    function buildFiles() {
        var f = {};
        var info = { id: P.info.id, nombre: P.info.nombre, version: P.info.version || "1", autor: P.info.autor || "", descripcion: P.info.descripcion || "" };
        f["contenido.json"] = JSON.stringify(info, null, 1);
        if (P.cards.length) { var cat = {}; cat[P.info.id] = P.cards.map(clean); f["cartas/cartas.json"] = JSON.stringify(cat, null, 1); }
        P.scenarios.forEach(function (sc) {
            var base = { version: "0.5.8", name: sc.name, villain: sc.villain, expert: false, schemes: sc.schemes, set_aside: sc.set_aside || [], encounters: sc.encounters, encounter_sets: sc.encounter_sets, modular_sets: sc.modular_sets };
            f["escenarios/" + sc.file + ".json"] = JSON.stringify(base, null, 1);
            if (sc.expert) {
                var ex = JSON.parse(JSON.stringify(base)); ex.expert = true; ex.villain = sc.villain_expert.length ? sc.villain_expert : sc.villain;
                if (ex.encounter_sets.indexOf("expert") < 0) ex.encounter_sets = ex.encounter_sets.concat(["expert"]);
                f["escenarios/" + sc.file + "_expert.json"] = JSON.stringify(ex, null, 1);
            }
        });
        P.sets.forEach(function (st) { f["sets/" + st.file + ".json"] = JSON.stringify({ version: "0.5.8", name: st.name, encounters: st.encounters }, null, 1); });
        if (P.caja.nombre && (P.scenarios.length || P.sets.length))
            f["caja.json"] = JSON.stringify({ nombre: P.caja.nombre, escenarios: P.scenarios.map(function (s) { return s.file; }), heroes: [], sets: P.sets.map(function (s) { return s.file; }) }, null, 1);
        return f;
    }
    function fromFiles(files) {
        var p = blank();
        try { var i = JSON.parse(files["contenido.json"] || "{}"); Object.assign(p.info, i); p.info._idTouched = true; } catch (e) {}
        Object.keys(files).forEach(function (k) {
            try {
                if (/^cartas\/.*\.json$/.test(k)) { var cat = JSON.parse(files[k]); Object.keys(cat).forEach(function (g) { (cat[g] || []).forEach(function (c) { c.desc = c.desc || {}; c.traits = c.traits || []; c.reglas = c.reglas || []; p.cards.push(c); }); }); }
                if (/^sets\/.*\.json$/.test(k)) { var st = JSON.parse(files[k]); p.sets.push({ name: st.name, file: k.slice(5, -5), encounters: st.encounters || [], _fileTouched: true }); }
                if (k === "caja.json") p.caja.nombre = JSON.parse(files[k]).nombre || p.caja.nombre;
            } catch (e) {}
        });
        Object.keys(files).filter(function (k) { return /^escenarios\/.*\.json$/.test(k) && !/_expert\.json$/.test(k); }).forEach(function (k) {
            try {
                var sc = JSON.parse(files[k]), file = k.slice(11, -5), ex = files["escenarios/" + file + "_expert.json"];
                var exd = ex ? JSON.parse(ex) : null;
                p.scenarios.push({ name: sc.name, file: file, villain: sc.villain || [], villain_expert: exd ? exd.villain || [] : [], schemes: sc.schemes || [], encounters: sc.encounters || [],
                    encounter_sets: (sc.encounter_sets || []).filter(function (x) { return x !== "expert"; }), modular_sets: sc.modular_sets || [], set_aside: sc.set_aside || [], expert: !!exd, _fileTouched: true });
            } catch (e) {}
        });
        return p;
    }
    function fflate() {
        if (window.parent && window.parent.fflate) return Promise.resolve(window.parent.fflate);
        if (window.fflate) return Promise.resolve(window.fflate);
        return new Promise(function (ok, ko) { var s = document.createElement("script"); s.src = "../fflate.min.js"; s.onload = function () { ok(window.fflate); }; s.onerror = ko; document.head.appendChild(s); });
    }
    function zipFiles() {
        return fflate().then(function (z) { var e = {}, f = buildFiles(); Object.keys(f).forEach(function (k) { e[k] = z.strToU8(f[k]); }); return new File([z.zipSync(e)], (P.info.id || "contenido") + ".zip", { type: "application/zip" }); });
    }

    // ------------------------------------------------------------------------------------------- check / install / test
    function check() {
        status("Comprobando con el motor…");
        return req("POST", "content_check", JSON.stringify({ files: buildFiles(), images: [] })).then(function (r) { lastReport = JSON.parse(r.body); status(lastReport.ok ? "✔ Paquete válido" : "✘ " + lastReport.errors.length + " errores"); return lastReport; });
    }
    function filesHash() { var s = JSON.stringify(buildFiles()), h = 0; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return String(h); }
    function renderCheck() {
        counts();
        var s = $("#tab-check");
        var installed = localStorage.getItem("marvel-creador-installed") === filesHash();
        s.innerHTML = '<div class="box"><h2>1. Comprobar</h2><p class="help">El motor del juego revisa todas las cartas, reglas, escenarios y sets (los mismos cargadores que usará la partida).</p>' +
            '<div class="row"><button class="btn" id="c-check">Comprobar ahora</button></div><div id="c-out"></div></div>' +
            '<div class="box"><h2>2. Instalar y probar</h2><p class="help">Instala el paquete en este dispositivo (la app se reinicia y vuelve aquí). Después puedes probar cada carta en una partida preparada.</p>' +
            '<div class="row"><button class="btn red" id="c-inst">' + (installed ? "Reinstalar" : "Instalar en la app") + '</button>' + (installed ? '<span class="msg ok">Instalado: esta versión es la que hay en la app</span>' : '<span class="help">Cambios sin instalar</span>') + "</div>" +
            (installed ? '<div class="list" id="c-tests">' + P.cards.filter(function (c) { return !/b$/.test(c.card_id) || c.type !== "MainScheme"; }).map(function (c) {
                return '<div class="item"><div class="t"><b>' + esc(c.name || c.card_id) + "</b><small>" + esc(c.card_id + " · " + TYPE_ES[c.type]) + '</small></div><button class="btn small ok" data-test="' + esc(c.card_id) + '">Probar en partida</button></div>'; }).join("") +
                P.scenarios.map(function (sc) { return '<div class="item"><div class="t"><b>Escenario: ' + esc(sc.name) + "</b><small>Se juega desde New Game, caja «" + esc(P.caja.nombre) + '»</small></div><button class="btn small ok" data-scen="' + esc(sc.file) + '">Jugar</button></div>'; }).join("") + "</div>" : "") + "</div>" +
            '<div class="box"><h2>3. Compartir</h2><div class="row"><button class="btn" id="c-zip">Descargar ZIP del paquete</button></div><p class="help">El ZIP se puede importar en otro dispositivo con «Importar contenido» del menú, o volver a abrir aquí con «Abrir…».</p></div>';
        function out(rep) {
            var o = $("#c-out"); if (!o) return;
            o.innerHTML = (rep.ok ? '<div class="msg ok">✔ Todo correcto: ' + esc(JSON.stringify(rep.summary).replace(/[{}"]/g, "").replace(/,/g, ", ")) + "</div>" : "") +
                rep.errors.map(function (e) { return '<div class="msg err">' + esc(e) + "</div>"; }).join("") + rep.warnings.map(function (w) { return '<div class="msg warn">' + esc(w) + "</div>"; }).join("");
        }
        if (lastReport) out(lastReport);
        s.querySelector("#c-check").onclick = function () { check().then(out); };
        s.querySelector("#c-inst").onclick = function () {
            check().then(function (rep) {
                out(rep); if (!rep.ok) { status("Corrige los errores antes de instalar"); return; }
                return zipFiles().then(function (file) { return window.MarvelApp.shell.importContent(file); }).then(function (r) {
                    if (!r.ok) { lastReport = r; out(r); return; }
                    localStorage.setItem("marvel-creador-installed", filesHash());
                    sessionStorage.setItem("marvel-start-page", "creador.html");
                    status("Instalado. Reiniciando…"); setTimeout(function () { window.MarvelApp.shell.reload(); }, 700);
                });
            });
        };
        s.querySelector("#c-zip").onclick = function () {
            zipFiles().then(function (file) {
                var top = window.parent || window;
                if (top.navigator.canShare && top.navigator.canShare({ files: [file] })) return top.navigator.share({ files: [file], title: file.name }).catch(function () {});
                var a = document.createElement("a"); a.href = URL.createObjectURL(file); a.download = file.name; document.body.appendChild(a); a.click(); a.remove();
            });
        };
        s.querySelectorAll("[data-test]").forEach(function (b) { b.onclick = function () { testCard(b.dataset.test); }; });
        s.querySelectorAll("[data-scen]").forEach(function (b) { b.onclick = function () { location.href = "scene.html"; }; });
    }
    // a prepared game (puzzle) where the card can be seen in action right away
    function testCard(id) {
        var c = P.cards.find(function (x) { return x.card_id === id; }); if (!c) return;
        var puz = { version: "0.5.8", author: "", cover: "", comment: "Prueba de " + (c.name || id), seed: 7, villain: ["01094", "01095"], schemes: ["01097a,01097b"],
            encounter_deck: ["01101", "01101", "01106", "01105", "01104", "01104"], encounter_discard_pile: [], set_aside: [], expert: false,
            players: [{ identities: ["01001a,01001b"], hand_cards: [], player_deck: ["01088", "01086", "01085", "01085", "01088", "01086", "01085", "01088", "01086", "01085"], player_discard_pile: [], set_aside: [] }], puzzle_command: [] };
        // the card twice + one resource card of each kind, so its cost can be paid right away
        if (PLAYER.indexOf(c.type) >= 0) puz.players[0].hand_cards = [id, id, "01088", "01089", "01090"];
        else if (c.type === "Villain") puz.villain = [id];
        else if (c.type === "MainScheme") puz.schemes = [id.replace(/[ab]$/, "a") + "," + id.replace(/[ab]$/, "b")];
        else puz.puzzle_command = ["Puzzle.Deal('" + id + "')"];     // revealed in the first villain phase
        status("Preparando la partida de prueba…");
        req("GET", "new_puzzle?" + encodeURIComponent(JSON.stringify(puz))).then(function () { location.href = "marvel.html?p=0"; });
    }

    // ------------------------------------------------------------------------------------------- open / new
    function openDialog() {
        req("GET", "content_list").then(function (r) {
            var list = JSON.parse(r.body || "[]");
            var box = document.createElement("div");
            box.style.cssText = "position:fixed;inset:0;background:#000a;z-index:20;display:flex;align-items:center;justify-content:center;padding:12px";
            box.innerHTML = '<div class="box" style="max-width:520px;width:100%;max-height:90vh;overflow:auto"><h2>Abrir un paquete</h2>' +
                (list.length ? list.map(function (p) { return '<div class="item" data-id="' + esc(p.id) + '"><div class="t"><b>' + esc(p.nombre) + "</b><small>instalado · " + esc(p.id) + "</small></div></div>"; }).join("") : '<p class="help">No hay paquetes instalados.</p>') +
                '<div class="row"><button class="btn" id="o-zip">Abrir un ZIP…</button><button class="btn" id="o-x">Cancelar</button></div></div>';
            document.body.appendChild(box);
            box.querySelectorAll("[data-id]").forEach(function (it) { it.onclick = function () {
                req("GET", "content_files?" + encodeURIComponent(it.dataset.id)).then(function (r2) { var d = JSON.parse(r2.body); P = fromFiles(d.files); lastReport = null; sel = { card: 0, scen: 0, set: 0 }; localStorage.setItem("marvel-creador-installed", filesHash()); save(); box.remove(); show("cards"); }); }; });
            box.querySelector("#o-zip").onclick = function () { box.remove(); $("#zip-in").click(); };
            box.querySelector("#o-x").onclick = function () { box.remove(); };
        });
    }
    $("#zip-in").onchange = function (ev) {
        var file = ev.target.files[0]; ev.target.value = ""; if (!file) return;
        Promise.all([fflate(), file.arrayBuffer()]).then(function (a) {
            var z = a[0], entries = z.unzipSync(new Uint8Array(a[1])), names = Object.keys(entries).filter(function (n) { return !/\/$/.test(n); });
            var strip = ""; if (names.indexOf("contenido.json") < 0) { var roots = {}; names.forEach(function (n) { roots[n.split("/")[0]] = 1; }); if (Object.keys(roots).length === 1) strip = Object.keys(roots)[0] + "/"; }
            var files = {}; names.forEach(function (n) { var rel = n.indexOf(strip) === 0 ? n.slice(strip.length) : n; if (!/\.(jpe?g|png|webp)$/i.test(rel)) files[rel] = z.strFromU8(entries[n]); });
            P = fromFiles(files); lastReport = null; sel = { card: 0, scen: 0, set: 0 }; save(); show("cards");
        }).catch(function () { alert("No es un ZIP válido."); });
    };
    $("#b-open").onclick = openDialog;
    $("#b-new").onclick = function () { if (!P.cards.length || confirm("¿Empezar un paquete nuevo? (el actual sigue disponible si lo instalaste o descargaste)")) { P = blank(); lastReport = null; sel = { card: 0, scen: 0, set: 0 }; save(); show("pack"); } };
    document.querySelectorAll("nav button").forEach(function (b) { b.onclick = function () { show(b.dataset.tab); }; });

    // ------------------------------------------------------------------------------------------- start
    function start() {
        req("GET", "content_vocab").then(function (r) {
            V = JSON.parse(r.body);
            try { P = JSON.parse(localStorage.getItem(DRAFT) || "null"); } catch (e) { P = null; }
            if (!P || !P.info) P = blank();
            $("#packname").textContent = P.info.nombre || P.info.id; counts();
            show(localStorage.getItem("marvel-creador-installed") === filesHash() && P.cards.length ? "check" : "pack");
            window.Creador = { get pack() { return P; }, set pack(v) { P = v; }, buildFiles: buildFiles, check: check, show: show, testCard: testCard, EFFECTS: EFFECTS, triggersFor: triggersFor, fromFiles: fromFiles };
        }).catch(function (e) { document.body.insertAdjacentHTML("beforeend", '<div class="msg err">No se pudo hablar con el motor: ' + esc(e) + "</div>"); });
    }
    if (window.MarvelApp && window.MarvelApp.request) start(); else window.addEventListener("load", start);
})();
