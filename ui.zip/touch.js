// Touch helpers for the (mouse oriented) original UI. Browsers already synthesise mouseenter/mouseover/click from a tap,
// which gives "tap = hover preview + click". Here: long press = right click (context menu / card info), and no double-tap zoom.
(function () {
    "use strict";
    var LONG_PRESS_MS = 520, MOVE_TOLERANCE = 12;
    var timer = null, startX = 0, startY = 0, target = null, fired = false;

    function clear() { if (timer) { clearTimeout(timer); timer = null; } }
    document.addEventListener("touchstart", function (e) {
        if (e.touches.length !== 1) { clear(); return; }
        var t = e.touches[0]; startX = t.clientX; startY = t.clientY; target = e.target; fired = false;
        clear();
        timer = setTimeout(function () {
            fired = true;
            var ev = new MouseEvent("contextmenu", { bubbles: true, cancelable: true, clientX: startX, clientY: startY, button: 2 });
            target.dispatchEvent(ev);
        }, LONG_PRESS_MS);
    }, { passive: true });
    document.addEventListener("touchmove", function (e) {
        var t = e.touches[0];
        if (Math.abs(t.clientX - startX) > MOVE_TOLERANCE || Math.abs(t.clientY - startY) > MOVE_TOLERANCE) clear();
    }, { passive: true });
    document.addEventListener("touchend", function (e) { clear(); if (fired) { e.preventDefault(); fired = false; } }, { passive: false });
    document.addEventListener("touchcancel", clear, { passive: true });
    // keep the page from zooming on double tap / pinch (the scene is scaled to fit the screen already)
    document.addEventListener("gesturestart", function (e) { e.preventDefault(); });
})();
