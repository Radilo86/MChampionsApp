// Marvel Champions offline — hero picker + MarvelCDB importer (Spanish UI, touch friendly).
// Used by scene.html (new game), deck.html (deck editor) and main.html.
(function () {
    "use strict";
    var css = document.createElement("style");
    css.textContent = [
        ".dt-back{position:fixed;inset:0;background:#000b;z-index:100000;display:flex;align-items:center;justify-content:center;padding:max(8px,env(safe-area-inset-top)) max(8px,env(safe-area-inset-right)) max(8px,env(safe-area-inset-bottom)) max(8px,env(safe-area-inset-left))}",
        ".dt-box{background:#23262d;color:#e6e9ef;border:1px solid #556;border-radius:14px;max-width:760px;width:100%;max-height:100%;display:flex;flex-direction:column;font:15px/1.4 system-ui,Arial,sans-serif;box-shadow:0 10px 40px #000a}",
        ".dt-head{display:flex;align-items:center;gap:8px;padding:10px 14px;border-bottom:1px solid #3a3f4b}.dt-head h3{margin:0;font-size:17px;flex:1}",
        ".dt-x{background:none;border:0;color:#aab;font-size:26px;line-height:1;padding:4px 10px;cursor:pointer}",
        ".dt-body{padding:12px 14px;overflow:auto;-webkit-overflow-scrolling:touch}",
        ".dt-row{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}",
        ".dt-box input[type=search],.dt-box textarea{flex:1;min-width:0;background:#15171c;color:#fff;border:1px solid #556;border-radius:8px;padding:10px;font:16px system-ui}",
        ".dt-box textarea{width:100%;min-height:84px;box-sizing:border-box;font:16px ui-monospace,monospace}",
        "@media (max-height:500px){.dt-box textarea{min-height:56px}.dt-head{padding:6px 12px}.dt-body{padding:8px 12px}.dt-grid{grid-template-columns:repeat(auto-fill,minmax(96px,1fr))}}",
        ".dt-btn{background:#2d3340;color:#fff;border:0;border-radius:8px;padding:10px 14px;font:600 14px system-ui;cursor:pointer;min-height:42px}.dt-btn.pri{background:#e23636}.dt-btn:disabled{opacity:.5}",
        ".dt-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(112px,1fr));gap:10px}",
        ".dt-item{background:#15171c;border:1px solid #3a3f4b;border-radius:10px;padding:6px;text-align:center;cursor:pointer;position:relative}.dt-item:active{background:#2d3340}",
        ".dt-item img{width:100%;aspect-ratio:254/352;object-fit:cover;border-radius:6px;background:#333}",
        ".dt-item b{display:block;font-size:13px;margin-top:4px;line-height:1.15}.dt-item small{color:#9aa3b5;font-size:11px}",
        ".dt-tag{position:absolute;top:8px;left:8px;background:#e23636;color:#fff;border-radius:6px;font-size:10px;padding:1px 5px}",
        ".dt-note{font-size:13px;color:#9aa3b5;margin:6px 0}.dt-ok{color:#6fdc8c}.dt-err{color:#ff7b7b}.dt-warn{color:#f1c40f;font-size:13px}",
        ".dt-body a{color:#6cb6ff}"
    ].join("");
    document.head.appendChild(css);

    function el(tag, props, children) {
        var e = document.createElement(tag);
        Object.keys(props || {}).forEach(function (k) { if (k === "text") e.textContent = props[k]; else if (k === "html") e.innerHTML = props[k]; else if (k.slice(0, 2) === "on") e[k] = props[k]; else e.setAttribute(k, props[k]); });
        (children || []).forEach(function (c) { e.appendChild(c); });
        return e;
    }
    function modal(title) {
        var back = el("div", { "class": "dt-back" }), box = el("div", { "class": "dt-box", role: "dialog" }), body = el("div", { "class": "dt-body" });
        var x = el("button", { "class": "dt-x", "aria-label": "Cerrar", text: "×", onclick: close });
        box.appendChild(el("div", { "class": "dt-head" }, [el("h3", { text: title }), x])); box.appendChild(body); back.appendChild(box);
        back.addEventListener("click", function (e) { if (e.target === back) close(); });
        document.body.appendChild(back);
        function close() { if (back.parentNode) back.parentNode.removeChild(back); }
        return { body: body, close: close };
    }
    function api(method, url, body) {
        var r = window.MarvelApp ? window.MarvelApp.request(method, url, body || "") : fetch(url, { method: method, body: body });
        return Promise.resolve(r).then(function (res) { return res.body !== undefined ? res : res.text().then(function (t) { return { status: res.status, body: t }; }); });
    }

    // ================================================================================== hero picker
    function pickHero(slot) {
        var m = modal("Elegir héroe — jugador " + slot);
        var search = el("input", { type: "search", placeholder: "Buscar héroe…", autocomplete: "off" });
        var imp = el("button", { "class": "dt-btn pri", text: "Importar de MarvelCDB", onclick: function () { m.close(); openImport({ slot: slot }); } });
        var file = el("button", { "class": "dt-btn", text: "Cargar archivo .json", onclick: function () { var inp = document.getElementById("heroes-" + slot); if (inp) { m.close(); inp.click(); } } });
        var clear = el("button", { "class": "dt-btn", text: "Vaciar hueco", onclick: function () { var inp = document.getElementById("heroes-" + slot); if (inp && window.Reset) window.Reset(inp); m.close(); } });
        m.body.appendChild(el("div", { "class": "dt-row" }, [search]));
        m.body.appendChild(el("div", { "class": "dt-row" }, [imp, file, clear]));
        var grid = el("div", { "class": "dt-grid" }); m.body.appendChild(grid);
        var items = [];
        function render() {
            var q = search.value.trim().toLowerCase(); grid.textContent = "";
            items.filter(function (i) { return !q || (i.name + " " + i.hero + " " + (i.sub || "")).toLowerCase().indexOf(q) >= 0; }).forEach(function (i) {
                // two decks with the same name (e.g. Black Panther: T'Challa / Shuri): tell them apart by their file
                var twin = items.filter(function (o) { return o.name === i.name; }).length > 1;
                var hint = i.sub && i.sub !== i.name ? i.sub : (twin ? i.file.split("/").pop().replace(/\.json$/, "").replace(/_/g, " ") : "");
                var card = el("div", { "class": "dt-item", role: "button", tabindex: "0" }, [
                    el("img", { src: i.pic, alt: i.name, loading: "lazy" }), el("b", { text: i.name }), el("small", { text: (hint ? hint + " · " : "") + i.cards + " cartas" })]);
                if (i.source === "mine") card.insertBefore(el("span", { "class": "dt-tag", text: "Mío" }), card.firstChild);
                card.onclick = function () {
                    api("GET", "get_hero_json?" + i.file).then(function (r) {
                        if (r.status !== 200) throw new Error(r.body);
                        window.SetHero(JSON.parse(r.body), slot); m.close();
                    }).catch(function (e) { alert("No se pudo cargar el héroe: " + e); });
                };
                grid.appendChild(card);
            });
            if (!grid.children.length) grid.appendChild(el("div", { "class": "dt-note", text: "Sin resultados." }));
        }
        search.addEventListener("input", render);
        api("GET", "list_heroes").then(function (r) { items = JSON.parse(r.body); render(); }).catch(function (e) { grid.textContent = "Error: " + e; });
    }

    // ================================================================================== MarvelCDB import
    var CDB = "https://marvelcdb.com/";
    function parseInput(text) {
        var t = text.trim();
        if (!t) throw new Error("Pega un enlace, un ID o el JSON del mazo.");
        if (t[0] === "{") return { json: t };
        var m = t.match(/marvelcdb\.com\/(decklist|deck)\/view\/(\d+)/i) || t.match(/\/api\/public\/(decklist|deck)\/(\d+)/i);
        if (m) return { id: m[2], kinds: [m[1].toLowerCase()] };
        if (/^\d+$/.test(t)) return { id: t, kinds: ["decklist", "deck"] };       // a bare id: public decklist first, then shared deck
        throw new Error("No reconozco ese texto. Usa un enlace de marvelcdb.com, un número de mazo o el JSON.");
    }
    function fetchDeck(spec, status) {
        var kinds = spec.kinds.slice(), lastUrl = "", failure = null;
        function next() {
            var kind = kinds.shift(); if (!kind) return Promise.reject(failure || new Error("No se encontró el mazo."));
            lastUrl = CDB + "api/public/" + kind + "/" + spec.id + ".json";
            status("Descargando de MarvelCDB (" + (kind === "decklist" ? "mazo público" : "mazo compartido") + ")…");
            return fetch(lastUrl).then(function (r) {
                if (r.ok) return r.text();
                failure = new Error(kind === "decklist" ? "MarvelCDB respondió " + r.status + ". Comprueba el número; si es un mazo privado usa «Compartir» en MarvelCDB." : "MarvelCDB respondió " + r.status + ". El mazo no existe o no está compartido.");
                return next();
            }, function (err) {
                var e = new Error(navigator.onLine === false ? "No hay conexión. El importador necesita internet una sola vez; después el mazo queda guardado y funciona sin red." :
                    "No se pudo contactar con MarvelCDB (sin conexión o petición bloqueada por el navegador).");
                e.apiUrl = lastUrl; throw e;
            });
        }
        return next();
    }
    function openImport(opts) {
        opts = opts || {};
        var m = modal("Importar mazo de MarvelCDB");
        var ta = el("textarea", { placeholder: "https://marvelcdb.com/decklist/view/12345/…   ·   12345   ·   o el JSON del mazo", autocapitalize: "off", spellcheck: "false" });
        var status = el("div", { "class": "dt-note" }), out = el("div");
        var go = el("button", { "class": "dt-btn pri", text: "Importar", onclick: run });
        var paste = el("button", { "class": "dt-btn", text: "Pegar", onclick: function () { if (navigator.clipboard && navigator.clipboard.readText) navigator.clipboard.readText().then(function (t) { ta.value = t; }, function () { ta.focus(); }); else ta.focus(); } });
        m.body.appendChild(el("div", { "class": "dt-note", html: "Pega el <b>enlace</b> o el <b>número</b> de un mazo de <a href='https://marvelcdb.com' target='_blank' rel='noopener'>marvelcdb.com</a> (hace falta internet solo esta vez) o su <b>JSON</b>. Se convierte con las cartas de la app y queda guardado para jugar sin conexión." }));
        m.body.appendChild(ta); m.body.appendChild(el("div", { "class": "dt-row", style: "margin-top:8px" }, [go, paste])); m.body.appendChild(status); m.body.appendChild(out);

        function setStatus(t, cls) { status.className = "dt-note " + (cls || ""); status.textContent = t; }
        function run() {
            out.textContent = ""; go.disabled = true;
            var spec;
            try { spec = parseInput(ta.value); } catch (e) { setStatus(e.message, "dt-err"); go.disabled = false; return; }
            var raw = spec.json ? Promise.resolve(spec.json) : fetchDeck(spec, setStatus);
            raw.then(function (text) {
                setStatus("Convirtiendo…");
                return api("POST", "convert_marvelcdb", text);
            }).then(function (r) {
                var res = JSON.parse(r.body);
                if (r.status !== 200 || res.error) throw new Error(res.error || "Error al convertir el mazo");
                done(res);
            }).catch(function (e) {
                setStatus(e.message || String(e), "dt-err");
                if (e.apiUrl) out.appendChild(el("div", { "class": "dt-note", html: "Alternativa sin conexión directa: abre <a href='" + e.apiUrl + "' target='_blank' rel='noopener'>este enlace</a>, copia todo el texto y pégalo arriba." }));
            }).then(function () { go.disabled = false; });
        }
        function done(res) {
            var d = res.deck; setStatus("✔ " + d.name + " — " + (d.hero_deck.length + d.player_deck.length) + " cartas", "dt-ok");
            (res.warnings || []).forEach(function (w) { out.appendChild(el("div", { "class": "dt-warn", text: "⚠ " + w })); });
            var row = el("div", { "class": "dt-row", style: "margin-top:10px" });
            function save(then) {
                return api("POST", "save_deck", JSON.stringify({ name: d.name, data: d })).then(function (r) { if (r.status !== 200) throw new Error(r.body); return then && then(); });
            }
            if (opts.slot || opts.onDeck) {
                row.appendChild(el("button", { "class": "dt-btn pri", text: opts.slot && opts.slot !== "auto" ? "Usar en el hueco " + opts.slot : "Usar ahora", onclick: function () {
                    save().then(function () { if (opts.onDeck) opts.onDeck(d); else if (typeof opts.slot === "number" || /^\d$/.test(String(opts.slot))) window.SetHero(d, opts.slot); else window.importDeck(JSON.stringify(d)); m.close(); }).catch(function (e) { alert(e); });
                } }));
            }
            row.appendChild(el("button", { "class": "dt-btn" + (opts.slot || opts.onDeck ? "" : " pri"), text: "Guardar en «Mis mazos»", onclick: function (ev) {
                var b = ev.target; save().then(function () { b.textContent = "✔ Guardado"; b.disabled = true; setStatus("Guardado. Aparecerá en el selector de héroes (grupo «Mío») y en «My Deck» del editor.", "dt-ok"); }).catch(function (e) { alert(e); });
            } }));
            out.appendChild(row);
        }
        setTimeout(function () { ta.focus(); }, 50);
    }

    window.DeckTools = { pickHero: pickHero, openImport: openImport, parseInput: parseInput };

    // ---- New game screen: tapping a hero slot opens the picker instead of the (useless on a phone) file dialog ----
    document.addEventListener("click", function (e) {
        var label = e.target && e.target.closest && e.target.closest("label[for^='heroes-']");
        if (!label) return;
        var slot = parseInt(label.getAttribute("for").split("-")[1], 10);
        if (!slot) return;
        e.preventDefault(); e.stopPropagation(); pickHero(slot);
    }, true);
})();
