// New-game screen helpers for touch devices: scroll to what the user just unlocked, and a floating "Jugar" button.
(function () {
    "use strict";
    function ready(fn) { if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn); else fn(); }
    ready(function () {
        var small = matchMedia("(max-width: 900px)").matches || matchMedia("(pointer: coarse)").matches;
        if (!small) return;
        function $(s) { return document.querySelector(s); }
        function scrollTo(el, block) { if (el) el.scrollIntoView({ behavior: "smooth", block: block || "start" }); }

        // 1. tapping a set fills "#set-content" far below the tiles: bring it into view
        var content = $("#set-content");
        if (content) new MutationObserver(function () { if (content.children.length) setTimeout(function () { scrollTo(content, "center"); }, 80); })
            .observe(content, { childList: true });
        // 2. after choosing a scenario, move on to the heroes
        if (content) content.addEventListener("click", function (e) {
            if (e.target.closest && e.target.closest("button")) setTimeout(function () { scrollTo($("label[for='heroes-1']"), "center"); }, 450);
        });

        // 3. floating play button
        var bar = document.createElement("div");
        bar.id = "mobile-play";
        var btn = document.createElement("button"); btn.type = "button"; bar.appendChild(btn);
        var msg = document.createElement("span"); bar.appendChild(msg);
        document.body.appendChild(bar);
        function heroCount() { var n = 0; for (var i = 1; i <= 4; i++) { var im = document.getElementById("img-heroes-" + i); if (im && im.getAttribute("src")) n++; } return n; }
        function hasScenario() { try { return typeof scenario !== "undefined" && scenario && scenario.villain !== undefined; } catch (e) { return false; } }
        function refresh() {
            var n = heroCount(), s = hasScenario();
            btn.textContent = n > 1 ? "▶ Jugar (" + n + " jugadores, mismo dispositivo)" : "▶ Jugar";
            msg.textContent = !s ? "1) Elige escenario" : n === 0 ? "2) Elige héroe" : "";
            bar.classList.toggle("ready", s && n > 0);
        }
        btn.addEventListener("click", function () {
            var n = heroCount();
            if (!hasScenario()) { scrollTo($("#set-images"), "start"); return; }
            if (n === 0) { scrollTo($("label[for='heroes-1']"), "center"); return; }
            if (typeof doCreateNewGame === "function") doCreateNewGame(n > 1 ? "hot_seat" : "");
        });
        setInterval(refresh, 500); refresh();
    });
})();
