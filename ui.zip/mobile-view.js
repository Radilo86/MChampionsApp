// Marvel Champions offline — touch layer for the game board (marvel.html).
// The board is a fixed 1920x(1160 on touch) scene scaled to fit the screen: on a phone that is ~0.34x, unreadable.
//  * size classes on <html>: ui-phone (smaller side < 500 px) / ui-tablet; recomputed on resize / rotation
//  * quick views (Todo / Villano / Planes / Mesa / Mano) laid out on the real board zones, never under the toolbar / OK button
//  * AUTO-FOCUS: when the game asks you to choose targets or to pay, the board zooms to the cards you can tap, then goes back
//  * pinch to zoom, two-finger pan; big "Continuar" button when the game pauses on a revealed card; ☰ opens the side drawers
(function () {
    "use strict";
    var forced = /[?&]mobile\b/.test(location.search);
    if (!forced && !matchMedia("(pointer: coarse)").matches) return;
    var root = document.documentElement;
    root.classList.add("is-touch");

    function sizeClass() {
        var phone = Math.min(innerWidth, innerHeight) < 500;
        root.classList.toggle("ui-phone", phone);
        root.classList.toggle("ui-tablet", !phone);
        return phone ? "phone" : "tablet";
    }
    sizeClass();

    var MAX_ZOOM = 4, CARD_W = 127;
    // zones of the board (scene coordinates, see css/marvel/pos-area.css + pos-deck.css)
    var VIEWS = {
        villain: { x: 470, y: 0, w: 1000, h: 420 },      // villain, engaged minions
        schemes: { x: 1280, y: 40, w: 640, h: 470 },      // main + side schemes (right edge)
        table:   { x: 380, y: 395, w: 1160, h: 590 },     // allies, supports, identity
        hand:    { x: 470, y: 760, w: 980, h: 400 },      // identity + hand
    };
    var LABELS = [["all", "Todo"], ["villain", "Villano"], ["schemes", "Planes"], ["table", "Mesa"], ["hand", "Mano"]];
    var current = "all", userView = "all", auto = null, bar = null, userChose = false;

    // phones: the hand (readable cards); tablets in landscape: the whole board; tablets in portrait: the hand
    function defaultView() { return root.classList.contains("ui-phone") || innerHeight > innerWidth ? "hand" : "all"; }
    function scene() { return window.Scene && window.Scene.fit ? window.Scene : null; }
    function dims() {
        var cs = getComputedStyle(root);
        return { w: parseFloat(cs.getPropertyValue("--scene-width")) || 1920, h: parseFloat(cs.getPropertyValue("--scene-height")) || 1080 };
    }
    function apply() { if (typeof window.adjustSceneScale === "function") window.adjustSceneScale(); }
    // free screen area: not under the toolbar (left) nor under the OK / End Turn button (right), nor the prompt (top)
    function area() {
        var vw = innerWidth, vh = innerHeight, phone = root.classList.contains("ui-phone");
        var l = bar ? bar.getBoundingClientRect().right + 4 : 0;
        var r = phone ? 96 : 120, b = 4, t = 4;
        // keep the band under the prompt (now at the top edge) free
        var pr = document.getElementById("prompt-box-container");
        if (pr) { var q = pr.getBoundingClientRect(); if (q.height > 4 && getComputedStyle(pr).display !== "none" && +getComputedStyle(pr).opacity !== 0) t = Math.max(t, Math.min(q.bottom + 4, vh * .3)); }
        return { x: l, y: t, w: Math.max(100, vw - l - r), h: Math.max(100, vh - t - b) };
    }
    function focusRect(rect, maxCard) {
        var s = scene(); if (!s) return;
        var d = dims(), a = area(), vw = innerWidth, vh = innerHeight;
        var target = Math.min(a.w / rect.w, a.h / rect.h);
        if (maxCard) target = Math.min(target, maxCard / CARD_W);           // do not blow a single card up to the whole screen
        s.zoom = Math.max(1, Math.min(MAX_ZOOM, target / s.fit));
        var scale = s.fit * s.zoom, cx = rect.x + rect.w / 2, cy = rect.y + rect.h / 2;
        s.panX = (a.x + a.w / 2) - cx * scale - (vw - d.w * scale) / 2;
        s.panY = (a.y + a.h / 2) - cy * scale - (vh - d.h * scale) / 2;
        apply();
    }
    // Each view fits the cards that are REALLY in its zones right now (a hand of 4 cards is zoomed more than one of 8);
    // the static rectangles above are the minimum frame / fallback when a zone is empty.
    var ZONES = {
        villain: "#area-villain .card, #player-all-engaged-minions .card",
        schemes: "#area-schemes-main .card, #area-schemes-side .card",
        table: "#player-all-allies .card, #player-all-supports .card",           // the identity is in «Mano»
        hand: "#player-all-hand-cards .card, #player-all-area-hero .card",
    };
    function viewRect(name) {
        var base = VIEWS[name], cards = Array.prototype.slice.call(document.querySelectorAll(ZONES[name] || "x"));
        var r = sceneRectOf(cards);
        if (!r) return base;
        // never narrower than ~4 cards (a single card must not fill the screen) and never outside the base frame vertically
        var minW = 4 * CARD_W + 60;
        if (r.w < minW) { r.x -= (minW - r.w) / 2; r.w = minW; }
        return r;
    }
    function setView(name, byUser) {
        var s = scene(); if (!s) return;
        if (name === "all") {
            // the whole board, in the space NEXT TO the toolbar (it used to cover the decks on the left edge)
            var d = dims(), x0 = bar ? bar.getBoundingClientRect().right + 4 : 0, w = innerWidth - x0, h = innerHeight;
            var sc = Math.min(w / d.w, h / d.h);
            s.zoom = Math.max(0.5, Math.min(1, sc / s.fit));
            s.panX = x0 + w / 2 - innerWidth / 2; s.panY = 0; apply();
        }
        else focusRect(viewRect(name), root.classList.contains("ui-phone") ? 150 : 200);
        // how: "user" (toolbar) / "default" (start, rotation) / "restore" (after auto-focus, zone refit)
        current = name;
        if (byUser === "user" || byUser === "default" || byUser === undefined) { userView = name; auto = null; }
        if (byUser === "user" || byUser === undefined) userChose = true;
        zoneSig = zoneSignature();
        mark();
    }
    function mark() {
        if (!bar) return;
        Array.prototype.forEach.call(bar.querySelectorAll("button[data-v]"), function (b) { b.classList.toggle("on", b.dataset.v === current && !auto); });
    }

    // ---------------------------------------------------------------- auto-focus on what can be tapped
    function sceneRectOf(cards) {
        var s = scene(), cam = document.getElementById("camera"); if (!s || !cam || !cards.length) return null;
        var c = cam.getBoundingClientRect(), x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
        cards.forEach(function (e) {
            var r = e.getBoundingClientRect(); if (!r.width) return;
            x0 = Math.min(x0, (r.left - c.left) / s.scale); y0 = Math.min(y0, (r.top - c.top) / s.scale);
            x1 = Math.max(x1, (r.right - c.left) / s.scale); y1 = Math.max(y1, (r.bottom - c.top) / s.scale);
        });
        if (x1 < x0) return null;
        var pad = 24; return { x: x0 - pad, y: y0 - pad, w: x1 - x0 + 2 * pad, h: y1 - y0 + 2 * pad };
    }
    function allVisible(cards) {
        var a = area();
        return cards.every(function (e) { var r = e.getBoundingClientRect(); return r.left >= a.x - 2 && r.right <= a.x + a.w + 2 && r.top >= a.y - 30 && r.bottom <= innerHeight + 2 && r.width >= 64; });
    }
    var pending = 0, lastSig = "";
    var zoneSig = "";
    function zoneSignature() {
        if (!ZONES[current]) return "";
        return current + ":" + Array.prototype.map.call(document.querySelectorAll(ZONES[current]), function (e) { return e.dataset.id; }).sort().join(",");
    }
    function checkFocus() {
        pending = 0;
        if (!scene()) return;
        // the player's view follows its zone: a card entering / leaving the hand (or the table...) refits it
        if (!auto && current && ZONES[current] && !g) {
            var z = zoneSignature();
            if (z !== zoneSig) { zoneSig = z; setView(current, "restore"); }
        }
        var pay = Array.prototype.slice.call(document.querySelectorAll("#scene .card.highlight-pay"));
        var tgt = Array.prototype.slice.call(document.querySelectorAll("#scene .card.highlight-targets"));
        var set = pay.length ? pay.concat(Array.prototype.slice.call(document.querySelectorAll("#scene .card.selected"))) : tgt;
        var sig = set.map(function (e) { return e.dataset.id; }).sort().join(",");
        if (sig === lastSig) return;
        lastSig = sig;
        if (!set.length) {                                        // selection finished: back to the view the player chose
            if (auto) { auto = null; setView(userView || defaultView(), "restore"); }
            return;
        }
        if (allVisible(set)) return;                              // already on screen and readable: do not move the board
        var r = sceneRectOf(set); if (!r) return;
        auto = sig; current = ""; focusRect(r, root.classList.contains("ui-phone") ? 150 : 190); mark();
    }
    // wait until the board is quiet (cards being dealt / animated keep changing classes) before measuring
    function scheduleFocus() { if (pending) clearTimeout(pending); pending = setTimeout(checkFocus, 350); }

    // ---------------------------------------------------------------- toolbar
    function build() {
        bar = document.createElement("div"); bar.id = "mv-toolbar";
        var menu = document.createElement("button"); menu.type = "button"; menu.textContent = "☰"; menu.className = "menu"; menu.setAttribute("aria-label", "Menú");
        menu.addEventListener("click", function (e) {
            e.stopPropagation();
            var open = !document.body.classList.contains("mv-drawer");
            document.body.classList.toggle("mv-drawer", open);
            ["right-side-bar", "left-side-bar"].forEach(function (id) { var el = document.getElementById(id); if (el) el.classList.toggle("open", open); });
            menu.classList.toggle("on", open);
        });
        bar.appendChild(menu);
        LABELS.forEach(function (p) {
            var b = document.createElement("button"); b.dataset.v = p[0]; b.textContent = p[1]; b.type = "button";
            b.addEventListener("click", function (e) { e.stopPropagation(); setView(p[0], "user"); });
            bar.appendChild(b);
        });
        var rot = document.createElement("button"); rot.type = "button"; rot.className = "rot"; rot.textContent = "⟳"; rot.setAttribute("aria-label", "Girar tablero");
        rot.addEventListener("click", function (e) { e.stopPropagation(); try { window.parent.marvelShell.toggleRotate(); } catch (err) {} });
        bar.appendChild(rot);
        setInterval(function () { try { rot.classList.toggle("show", !!window.parent.marvelShell.portraitTouch()); } catch (err) {} }, 700);
        document.body.appendChild(bar); mark();

        var resume = document.createElement("button"); resume.id = "mv-resume"; resume.type = "button"; resume.textContent = "▶ Continuar";
        resume.addEventListener("click", function (e) { e.stopPropagation(); var b = document.getElementById("pause-btn"); if (b) b.click(); });
        document.body.appendChild(resume);
    }

    // ---------------------------------------------------------------- pinch zoom + two-finger pan
    var g = null;
    function mid(t) { return { x: (t[0].clientX + t[1].clientX) / 2, y: (t[0].clientY + t[1].clientY) / 2 }; }
    function dist(t) { return Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY); }
    document.addEventListener("touchstart", function (e) {
        if (e.touches.length !== 2 || !scene()) { g = null; return; }
        var s = scene(), cam = document.getElementById("camera"), r = cam.getBoundingClientRect(), m = mid(e.touches);
        g = { d0: dist(e.touches), z0: s.zoom, px: (m.x - r.left) / s.scale, py: (m.y - r.top) / s.scale };
        e.preventDefault();
    }, { passive: false, capture: true });
    document.addEventListener("touchmove", function (e) {
        if (!g || e.touches.length !== 2) return;
        var s = scene(); if (!s) return; e.preventDefault();
        var d = dims(), m = mid(e.touches), z = Math.max(1, Math.min(MAX_ZOOM, g.z0 * dist(e.touches) / g.d0)), scale = s.fit * z;
        s.zoom = z;
        s.panX = m.x - g.px * scale - (innerWidth - d.w * scale) / 2;
        s.panY = m.y - g.py * scale - (innerHeight - d.h * scale) / 2;
        current = ""; userView = ""; auto = null; apply(); mark();
    }, { passive: false, capture: true });
    document.addEventListener("touchend", function (e) { if (e.touches.length < 2) g = null; }, { capture: true, passive: true });

    function init() {
        build();
        var tries = 0, t = setInterval(function () {
            if (scene()) {
                clearInterval(t);
                window.Scene.slack = 0.1;
                setView(defaultView(), "default");
                var sc = document.getElementById("scene");
                if (sc) new MutationObserver(scheduleFocus).observe(sc, { subtree: true, childList: true, attributes: true, attributeFilter: ["class"] });
            } else if (++tries > 100) clearInterval(t);
        }, 100);
        var lastClass = sizeClass();
        addEventListener("resize", function () {
            var now = sizeClass();
            setTimeout(function () {
                lastClass = now;
                if (!userChose) setView(defaultView(), "default");       // rotation: follow the new default…
                else if (current) setView(current, "restore");           // …unless the player picked a view
            }, 120);
        });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
    window.MobileView = { setView: setView, focus: checkFocus, VIEWS: VIEWS, size: sizeClass, defaultView: defaultView, state: function () { return { current: current, userView: userView, auto: auto, lastSig: lastSig }; } };
})();
