// Marvel Champions offline — touch camera for the game board (marvel.html).
// The board is a fixed 1920x1080 scene scaled to fit the screen: on a phone that is ~0.36x, i.e. unreadable.
// This adds: pinch to zoom, two-finger pan, and quick views (whole board / villain / table / hand).
(function () {
    "use strict";
    var forced = /[?&]mobile\b/.test(location.search);
    if (!forced && !matchMedia("(pointer: coarse)").matches) return;
    document.documentElement.classList.add("is-touch");

    var MAX_ZOOM = 4;
    // regions of the 1920x1080 scene (measured on the real layout)
    var VIEWS = {
        villain: { x: 480, y: 0, w: 1440, h: 430 },
        table:   { x: 380, y: 330, w: 1160, h: 830 },
        hand:    { x: 470, y: 720, w: 980, h: 440 },
    };
    var current = "all", bar = null;

    function scene() { return window.Scene && window.Scene.fit ? window.Scene : null; }
    function dims() {
        var cs = getComputedStyle(document.documentElement);
        return { w: parseFloat(cs.getPropertyValue("--scene-width")) || 1920, h: parseFloat(cs.getPropertyValue("--scene-height")) || 1080 };
    }
    function apply() { if (typeof window.adjustSceneScale === "function") window.adjustSceneScale(); }

    function setView(name) {
        var s = scene(); if (!s) return;
        var d = dims(), vw = innerWidth, vh = innerHeight;
        if (name === "all") { s.zoom = 1; s.panX = 0; s.panY = 0; }
        else {
            var r = VIEWS[name];
            s.zoom = Math.max(1, Math.min(MAX_ZOOM, Math.min(vw / r.w, vh / r.h) / s.fit));
            var scale = s.fit * s.zoom, cx = r.x + r.w / 2, cy = r.y + r.h / 2;
            s.panX = vw / 2 - cx * scale - (vw - d.w * scale) / 2;
            s.panY = vh / 2 - cy * scale - (vh - d.h * scale) / 2;
        }
        current = name; apply(); mark();
    }
    function mark() {
        if (!bar) return;
        Array.prototype.forEach.call(bar.querySelectorAll("button"), function (b) { b.classList.toggle("on", b.dataset.v === current); });
    }

    // ---- toolbar ----
    function build() {
        bar = document.createElement("div"); bar.id = "mv-toolbar";
        [["all", "Todo"], ["villain", "Villano"], ["table", "Mesa"], ["hand", "Mano"]].forEach(function (p) {
            var b = document.createElement("button"); b.dataset.v = p[0]; b.textContent = p[1]; b.type = "button";
            b.addEventListener("click", function (e) { e.stopPropagation(); setView(p[0]); });
            bar.appendChild(b);
        });
        // the side drawers (Log / Pause / Undo / Redo / QSave...) only opened on mouse hover
        var menu = document.createElement("button"); menu.type = "button"; menu.textContent = "☰"; menu.className = "menu"; menu.setAttribute("aria-label", "Menú");
        menu.addEventListener("click", function (e) {
            e.stopPropagation();
            var open = !document.body.classList.contains("mv-drawer");
            document.body.classList.toggle("mv-drawer", open);
            ["right-side-bar", "left-side-bar"].forEach(function (id) { var el = document.getElementById(id); if (el) el.classList.toggle("open", open); });
            menu.classList.toggle("on", open);
        });
        bar.insertBefore(menu, bar.firstChild);
        // portrait phone: the shell rotates the board 90 degrees to use the whole screen; this button turns that on / off
        var rot = document.createElement("button"); rot.type = "button"; rot.className = "rot"; rot.textContent = "⟳"; rot.setAttribute("aria-label", "Girar tablero");
        rot.addEventListener("click", function (e) { e.stopPropagation(); try { window.parent.marvelShell.toggleRotate(); } catch (err) {} });
        bar.appendChild(rot);
        setInterval(function () { try { rot.classList.toggle("show", !!window.parent.marvelShell.portraitPhone()); } catch (err) {} }, 700);
        // The game pauses whenever an encounter / boost card is revealed (so you can read it); on desktop you press SPACE.
        // There is no keyboard on a phone: show a big button while the game is paused.
        var resume = document.createElement("button"); resume.id = "mv-resume"; resume.type = "button"; resume.textContent = "▶ Continuar";
        resume.addEventListener("click", function (e) { e.stopPropagation(); var b = document.getElementById("pause-btn"); if (b) b.click(); });
        document.body.appendChild(resume);
        document.body.appendChild(bar); mark();
    }

    // ---- pinch zoom + two-finger pan ----
    var g = null;
    function mid(t) { return { x: (t[0].clientX + t[1].clientX) / 2, y: (t[0].clientY + t[1].clientY) / 2 }; }
    function dist(t) { return Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY); }
    document.addEventListener("touchstart", function (e) {
        if (e.touches.length !== 2 || !scene()) { g = null; return; }
        var s = scene(), cam = document.getElementById("camera"), r = cam.getBoundingClientRect(), m = mid(e.touches);
        g = { d0: dist(e.touches), z0: s.zoom, px: (m.x - r.left) / s.scale, py: (m.y - r.top) / s.scale };
        e.preventDefault();
    }, { passive: false, capture: true });
    document.addEventListener("touchmove", function (e) {
        if (!g || e.touches.length !== 2) return;
        var s = scene(); if (!s) return; e.preventDefault();
        var d = dims(), m = mid(e.touches), z = Math.max(1, Math.min(MAX_ZOOM, g.z0 * dist(e.touches) / g.d0));
        var scale = s.fit * z;
        s.zoom = z;
        s.panX = m.x - g.px * scale - (innerWidth - d.w * scale) / 2;
        s.panY = m.y - g.py * scale - (innerHeight - d.h * scale) / 2;
        current = ""; apply(); mark();
    }, { passive: false, capture: true });
    document.addEventListener("touchend", function (e) { if (e.touches.length < 2) g = null; }, { capture: true, passive: true });

    function init() {
        build();
        // the board is built by marvel.js (a module): wait until Scene is ready, then pick a readable first view
        var tries = 0, t = setInterval(function () {
            if (scene()) { clearInterval(t); setView("hand"); }
            else if (++tries > 100) clearInterval(t);
        }, 100);
        addEventListener("orientationchange", function () { setTimeout(function () { setView(current || "all"); }, 300); });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
    window.MobileView = { setView: setView, VIEWS: VIEWS };
})();
