// Marvel Champions offline — injected FIRST into every UI page (they live inside an <iframe> of the shell).
// Replaces the network of the original web client (fetch, XMLHttpRequest, WebSocket, window.open) with calls to the
// Python engine that runs in the shell's worker. The original UI code is left untouched.
(function () {
    "use strict";
    var shell = window.parent !== window ? window.parent : null;
    var engine = null;
    try { engine = shell && shell.marvelEngine; } catch (e) { engine = null; }
    if (!engine) {
        // Opened directly (not through the shell): go through it so the engine exists.
        var rel = location.pathname.replace(/^.*\/ui\//, "ui/") + location.search;
        location.replace(new URL("../", location.href).href + "#" + rel);
        return;
    }

    var API = new Set(("list_file list_scenarios list_encounter_sets list_deck list_starter_deck list_replay_files " +
        "list_puzzle_files list_puzzle_test_files read_file get_encounter_set_json get_scenario_json get_hero_json " +
        "get_sets_json get_sets_custom_scenario get_cards_json get_translate_json get_card_json get_completion_rate " +
        "get_statistics get_session_statistics get_play_scene_name get_max_timeout get_puzzle_json get_replay_json " +
        "get_gamers get_version new new_debug load_replay load_replay_data save_replay_data load_puzzle " +
        "new_puzzle_replay new_puzzle new_game_online new_game_lan debug client_updated get_ask get_world post " +
        "autosave_info load_autosave delete_replay save_deck delete_deck").split(" "));

    function parse(url) { try { return new URL(url, location.href); } catch (e) { return null; } }
    function isApi(url) {
        var u = parse(url);
        return !!u && u.origin === location.origin && API.has(u.pathname.split("/").pop());
    }
    function route(url) { var u = parse(url); return u.pathname.split("/").pop() + u.search; }

    // ---- the original server set this cookie (the main menu prints it as the version) ----
    try { document.cookie = "app_version=" + encodeURIComponent(engine.version) + "; path=/; max-age=31536000"; } catch (e) {}

    // ---- fetch ----
    var nativeFetch = window.fetch.bind(window);
    window.fetch = async function (input, init) {
        var url = typeof input === "string" ? input : (input && input.url) || String(input);
        if (!isApi(url)) return nativeFetch(input, init);
        var method = (init && init.method) || (typeof input !== "string" && input.method) || "GET";
        var body = init && init.body;
        if (body == null && typeof input !== "string" && method !== "GET") body = await input.clone().text();
        var r = await engine.request(method, route(url), body == null ? "" : body);
        return new Response(r.status === 204 ? null : r.body, { status: r.status, headers: { "Content-Type": r.contentType || "text/plain" } });
    };

    // ---- XMLHttpRequest ----
    var NativeXHR = window.XMLHttpRequest;
    function define(name, getter) { Object.defineProperty(ShimXHR.prototype, name, { configurable: true, get: getter }); }
    function ShimXHR() { return Reflect.construct(NativeXHR, [], ShimXHR); }
    ShimXHR.prototype = Object.create(NativeXHR.prototype, { constructor: { value: ShimXHR } });
    Object.setPrototypeOf(ShimXHR, NativeXHR);
    var nativeOpen = NativeXHR.prototype.open, nativeSend = NativeXHR.prototype.send,
        nativeSetHeader = NativeXHR.prototype.setRequestHeader, nativeGetHeader = NativeXHR.prototype.getResponseHeader,
        nativeAbort = NativeXHR.prototype.abort;
    function nativeGet(self, prop) { return Object.getOwnPropertyDescriptor(NativeXHR.prototype, prop).get.call(self); }
    ShimXHR.prototype.open = function (method, url) {
        if (!isApi(url)) { this.__api = false; return nativeOpen.apply(this, arguments); }
        this.__api = true; this.__method = method; this.__url = url; this.__rs = 1; this.__status = 0; this.__text = "";
        this.__type = "";
        this.dispatchEvent(new Event("readystatechange"));
    };
    ShimXHR.prototype.setRequestHeader = function (k, v) { if (!this.__api) return nativeSetHeader.call(this, k, v); };
    ShimXHR.prototype.getResponseHeader = function (k) {
        if (!this.__api) return nativeGetHeader.call(this, k);
        return /^content-type$/i.test(k) ? this.__ctype || null : null;
    };
    ShimXHR.prototype.abort = function () { if (!this.__api) return nativeAbort.call(this); this.__aborted = true; };
    ShimXHR.prototype.send = function (body) {
        if (!this.__api) return nativeSend.call(this, body);
        var self = this;
        engine.request(this.__method, route(this.__url), body == null ? "" : body).then(function (r) {
            if (self.__aborted) return;
            self.__status = r.status; self.__text = r.body; self.__ctype = r.contentType;
            self.__rs = 2; self.dispatchEvent(new Event("readystatechange"));
            self.__rs = 3; self.dispatchEvent(new Event("readystatechange"));
            self.__rs = 4; self.dispatchEvent(new Event("readystatechange"));
            self.dispatchEvent(new Event("load")); self.dispatchEvent(new Event("loadend"));
        }, function () {
            self.__rs = 4; self.__status = 0;
            self.dispatchEvent(new Event("readystatechange")); self.dispatchEvent(new Event("error")); self.dispatchEvent(new Event("loadend"));
        });
    };
    define("readyState", function () { return this.__api ? this.__rs : nativeGet(this, "readyState"); });
    define("status", function () { return this.__api ? this.__status : nativeGet(this, "status"); });
    define("statusText", function () { return this.__api ? (this.__status === 200 ? "OK" : "") : nativeGet(this, "statusText"); });
    define("responseText", function () { return this.__api ? this.__text : nativeGet(this, "responseText"); });
    define("responseURL", function () { return this.__api ? this.__url : nativeGet(this, "responseURL"); });
    define("response", function () {
        if (!this.__api) return nativeGet(this, "response");
        if (this.responseType === "json") { try { return JSON.parse(this.__text); } catch (e) { return null; } }
        return this.__text;
    });
    window.XMLHttpRequest = ShimXHR;

    // ---- WebSocket ----
    var NativeWS = window.WebSocket;
    function FakeWebSocket(url) {
        var self = this, target = new EventTarget();
        this.url = String(url); this.readyState = 0; this.protocol = ""; this.extensions = ""; this.bufferedAmount = 0;
        this.binaryType = "blob";
        ["onopen", "onmessage", "onclose", "onerror"].forEach(function (n) { self[n] = null; });
        this.addEventListener = target.addEventListener.bind(target);
        this.removeEventListener = target.removeEventListener.bind(target);
        this.dispatchEvent = target.dispatchEvent.bind(target);
        function emit(type, extra) {
            var ev = new Event(type); if (extra) Object.assign(ev, extra);
            if (typeof self["on" + type] === "function") self["on" + type](ev);
            target.dispatchEvent(ev);
        }
        this.sid = engine.openSocket(parse(url).search.slice(1), function (text) { if (self.readyState === 1) emit("message", { data: text }); });
        setTimeout(function () { if (self.readyState === 0) { self.readyState = 1; emit("open"); } }, 0);
        this.send = function (data) { if (self.readyState === 1) engine.socketSend(self.sid, String(data)); };
        this.close = function () {
            if (self.readyState >= 2) return;
            self.readyState = 3; engine.closeSocket(self.sid); emit("close", { code: 1000, wasClean: true });
        };
        window.addEventListener("pagehide", function () { engine.closeSocket(self.sid); });
    }
    FakeWebSocket.CONNECTING = 0; FakeWebSocket.OPEN = 1; FakeWebSocket.CLOSING = 2; FakeWebSocket.CLOSED = 3;
    window.WebSocket = function (url, protocols) {
        var u = parse(url);
        if (u && u.pathname.split("/").pop() === "ws") return new FakeWebSocket(url);
        return new NativeWS(url, protocols);
    };
    Object.assign(window.WebSocket, { CONNECTING: 0, OPEN: 1, CLOSING: 2, CLOSED: 3 });

    // ---- window.open: the desktop version opened the game in a new tab; here it replaces the page ----
    // The new-game screen builds "https://host?p=0&..." (origin root + query): in the original server that was the game
    // page. Here the origin root belongs to the shell, so map it to marvel.html next to the current page.
    function mapGameUrl(u) {
        if (/\/$/.test(u.pathname) && /[?&](p=|hot_seat)/.test(u.search)) return new URL("marvel.html" + u.search + u.hash, document.baseURI);
        return u;
    }
    var nativeWindowOpen = window.open.bind(window);
    window.open = function (url, target, features) {
        var u = url ? parse(url) : null;
        if (u && u.origin === location.origin && !(features && /width=/.test(features))) { location.href = mapGameUrl(u).href; return window; }
        return nativeWindowOpen(url, target, features);
    };

    // ---- helpers for the shell-aware features (used by the buttons injected into the main menu) ----
    window.MarvelApp = {
        // the shell page publishes its helper API (install, fullscreen, import...) as `marvelShell` once the engine is up
        get shell() { try { return shell.marvelShell || null; } catch (e) { return null; } },
        engine: engine,
        request: function (m, u, b) { return engine.request(m, u, b || ""); },
    };
})();
