// Marvel Champions offline — Spanish interface.
// The original UI is written in English and its code compares English names internally (e.g. 'End Phase'), so nothing is
// translated in the data: only what is SHOWN. Every visible text node / placeholder / title / button value is matched against
// EXACT phrases and PATTERNS; card names and card texts are never touched (they are not in the dictionary, and card faces are
// skipped). The engine translates its own prompts and log lines (data/translate_es.json).
(function () {
    "use strict";
    var lang = "es";
    try { lang = localStorage.getItem("marvel-lang") || "es"; } catch (e) {}
    if (lang !== "es") return;

    var EXACT = {
        // ---------------- main menu
        "Digital Edition": "Edición digital", "New Game": "Nueva partida", "Replay": "Repeticiones", "Deck Editor": "Editor de mazos",
        "View Cards": "Ver cartas", "Puzzle": "Puzles", "Credits": "Créditos",
        // ---------------- new game
        "Scenario": "Escenario", "Encounter Sets:": "Sets de encuentro:", "Modular Sets:": "Sets modulares:", "Expert:": "Experto:",
        "Encounter Size:": "Cartas de encuentro:", "Standard Sets": "Sets estándar", "Modular Sets": "Sets modulares", "Expand": "Desplegar",
        "Random": "Al azar", "Nemesis": "Némesis", "Name": "Nombre", "Heroes": "Héroes", "Game Start": "Empezar la partida", "Timeout:": "Tiempo límite:",
        "Off": "No", "Seed": "Semilla", "Modes of Play": "Modos de juego", "Heroic:": "Heroico:", "Skirmish": "Escaramuza",
        "Campaign (Experimental)": "Campaña (experimental)", "Rule": "Reglas", "Challenges": "Desafíos", "Challenge": "Desafío",
        "Create Scene": "Crear partida", "Create & Play (Hot Seat)": "Crear y jugar (mismo dispositivo)", "Reset to default": "Restablecer",
        "All v16 rules": "Todas las reglas v16", "Campaign Log": "Registro de campaña", "Hero": "Héroe", "Villain": "Villano",
        // ---------------- deck editor / card viewer
        "Sets": "Sets", "Load": "Cargar", "Save": "Guardar", "Import": "Importar", "Export": "Exportar", "Play": "Jugar",
        "Load from marvelcdb.com:": "Cargar desde marvelcdb.com:", "Load from a local file:": "Cargar desde un archivo:", "Load from clipboard:": "Cargar desde el portapapeles:",
        "Deck Build": "Construcción del mazo", "Main": "Principal", "Side": "Reserva", "Left click: Preview": "Toque: ver la carta",
        "Right click: Remove": "Mantener pulsado: quitar", "Middle click: Duplicate": "Clic central: duplicar", "Right click: Add to build deck": "Mantener pulsado: añadir al mazo",
        "We recommend you use": "Te recomendamos usar", "to build your deck.": "para construir tu mazo.", "Get Player Deck": "Obtener mazo",
        "Get Player Deck (Private)": "Obtener mazo (privado)", "set aside": "apartadas", "player deck": "mazo de jugador", "side deck": "mazo de reserva",
        "All": "Todas", "Filter": "Filtrar", "New": "Nuevas", "Type": "Tipo", "Cost": "Coste", "Alliance": "Alianza", "Guard": "Guardián", "Incite": "Incitar",
        "Patrol": "Patrulla", "Peril": "Peligro", "Permanent": "Permanente", "Quickstrike": "Ataque rápido", "Restricted": "Restringida", "Retaliate": "Represalia",
        "Surge": "Oleada", "Toughness": "Dureza", "Uses": "Usos", "Victory": "Victoria", "Villainous": "Malvado",
        "Ally": "Aliado", "Event": "Evento", "Upgrade": "Mejora", "Support": "Apoyo", "PlayerSideScheme": "Plan secundario de jugador", "Resource": "Recurso",
        "AlterEgo": "Alter ego", "Obligation": "Obligación", "Leader": "Líder", "Minion": "Esbirro", "MainScheme": "Plan principal", "SideScheme": "Plan secundario",
        "Treachery": "Traición", "Attachment": "Accesorio", "Environment": "Entorno", "Status": "Estado", "Evidence": "Prueba", "any": "cualquiera",
        "Aggression": "Agresividad", "Justice": "Justicia", "Leadership": "Liderazgo", "Protection": "Protección", "Basic": "Básica",
        "Encounter": "Encuentro", "Campaign": "Campaña", "Identity": "Identidad", "Hide badge": "Ocultar insignia", "Duplicate": "Duplicadas",
        "Unimplemented": "Sin implementar", "Cards": "Cartas", "Build": "Construir", "name or card_id": "nombre o número", "trait": "rasgo",
        "text (regex supported)": "texto (admite expresiones regulares)", "Clean": "Limpiar", "Player Deck": "Mazo de jugador",
        // ---------------- replays / credits / report
        "Game Replay": "Repeticiones de partidas", "Editor": "Editor", "Test": "Prueba", "We are not responsible": "No nos hacemos responsables",
        "Developed by: Irefrixs": "Desarrollado por: Irefrixs", "Tools and Technologies": "Herramientas y tecnologías", "Special Thanks": "Agradecimientos",
        "Download the Latest Version": "Descargar la última versión", "Thank You": "Gracias", "Thank you for playing!": "¡Gracias por jugar!",
        "Upload": "Subir", "Waiting for upload": "Esperando la subida", "automatically": "automáticamente", "Operating system details": "Datos del sistema operativo",
        "Browser information": "Información del navegador", "Gaming session duration": "Duración de la sesión de juego",
        // ---------------- game board
        "OK": "OK", "Log": "Registro", "Pause": "Pausa", "Undo": "Deshacer", "Redo": "Rehacer", "Break": "Detener", "QSave": "Guardado rápido",
        "QLoad": "Carga rápida", "View on Marvelcdb": "Ver en MarvelCDB", "Load Crash": "Cargar fallo", "Card Text": "Texto de cartas", "Sort Hand": "Ordenar mano",
        "By ID": "Por número", "Restart Turn": "Reiniciar turno", "Card Tilt": "Inclinar cartas", "Sound": "Sonido", "New Badge": "Insignia «nueva»",
        "Enhance Fx": "Efectos mejorados", "Preview": "Vista previa", "Auto Targeting": "Objetivo automático", "Auto Activate": "Activación automática",
        "Show Auto Activate Checkbox": "Mostrar casilla de activación automática", "Auto Pause": "Pausa automática", "Goto": "Ir a",
        "Reconnect in": "Reconectando en", "seconds.": "segundos.", "Reconnect Now": "Reconectar ahora", "Connecting...": "Conectando…", "Initialize": "Iniciando",
        "STATISTIC": "ESTADÍSTICA", "ACHIEVEMENT": "LOGRO", "Share replay": "Compartir repetición", "Save replay": "Guardar repetición", "Ignore": "Ignorar", "Report": "Informar",
        "VICTORY": "VICTORIA", "DEFEAT": "DERROTA", "No Image": "Sin imagen", "Id": "Carta", "Damage Dealt": "Daño infligido", "Damage Taken": "Daño recibido",
        "Thwarted Threat": "Amenaza frustrada", "Entered Play": "Entró en juego", "Cancel": "Cancelar",
        // option names (they are shown with spaces instead of "_")
        "Attack": "Atacar", "Thwart": "Frustrar", "Defense": "Defender", "Defend": "Defender", "Recover": "Recuperar", "Change Form": "Cambiar de forma",
        "Change_Form": "Cambiar de forma", "Action": "Acción", "Hero Action": "Acción de héroe", "Alter-Ego Action": "Acción de alter ego", "Response": "Respuesta",
        "Interrupt": "Interrupción", "Forced Response": "Respuesta obligada", "Forced Interrupt": "Interrupción obligada", "Resolve Mulligans": "Resolver mulligan",
        "End Phase": "Terminar fase", "End Turn": "Fin del turno", "End Round": "Fin de la ronda", "Game Rule": "Regla del juego", "Ally Limit": "Límite de aliados",
        "Resolve": "Resolver", "Boost": "Potenciación", "Setup": "Preparación", "When Revealed": "Al revelarse", "When Defeated": "Al ser derrotado",
        "Pay": "Pagar", "Skip": "Saltar", "Done": "Hecho", "Yes": "Sí", "No": "No", "Hand": "Mano", "Deck": "Mazo", "Discard": "Descartar",
        "Stunned": "Aturdido", "Confused": "Confundido", "Tough": "Duro", "Player": "Jugador", "Villain Phase": "Fase del villano", "Player Phase": "Fase de los jugadores",
        "Enters Play": "Entra en juego", "Defeated": "Derrotado", "Resolves": "Resuelve", "End": "Terminar", "Turn": "turno",
        // phases
        "Scenario Setup": "Preparación del escenario", "Init Finished": "Preparación terminada", "Player Turn": "Turno del jugador",
        "Player Turn End": "Fin del turno del jugador", "Main Scheme Place Threat": "Amenaza en el plan principal", "Enemy Activation": "Activación de los enemigos",
        "Deal Encounter Cards": "Repartir cartas de encuentro", "Reveal Encounter Cards": "Revelar cartas de encuentro", "Start Round": "Comienza la ronda",
        // new game: options and rules
        "Create Scene & Play (Hot Seat)": "Crear y jugar (mismo dispositivo)", "Other": "Otros", "Hide Error Message": "Ocultar mensajes de error",
        "Show Achievements": "Mostrar logros", "Statistics Notification:": "Avisos de estadísticas:", "First time": "La primera vez",
        "Skirmish mode (also sometimes called Rookie Mode) is a modification of standard mode that allows players to shorten the length of the game.":
            "El modo escaramuza (también llamado modo novato) es una variante del modo estándar que permite acortar la partida.",
        "To play a standard game modified by skirmish mode, before the game begins, the player group chooses any one version of the villain. During step eight of game setup (Select Scenario), put only the chosen version of the villain into play and remove each other version in the villain deck from the game.":
            "Para jugar en modo escaramuza, antes de empezar el grupo elige una versión del villano. En el paso ocho de la preparación (elegir escenario), pon en juego solo esa versión y retira de la partida las demás versiones del mazo de villano.",
        "Skirmish mode can also be combined with expert mode, heroic mode, and/or campaign mode.": "El modo escaramuza se puede combinar con el modo experto, el heroico y/o el de campaña.",
        "When a player is eliminated,": "Cuando un jugador es eliminado,",
        "place each card owned by the eliminated player in the eliminated player's discard pile": "pon cada carta suya en su pila de descartes",
        "During step four of the villain phase, each player reveals and resolves all facedown encounter cards that have been dealt to them, one card at a time":
            "En el paso cuatro de la fase del villano, cada jugador revela y resuelve todas las cartas de encuentro boca abajo que ha recibido, de una en una",
        "in the order in which they were dealt": "en el orden en que se repartieron",
        "After a minion with teamwork enters play and engages a player, if there is at least one other minion that shares the specified trait in play,":
            "Después de que un esbirro con trabajo en equipo entre en juego y se enfrente a un jugador, si hay en juego al menos otro esbirro con el rasgo indicado,",
        "the minion that just entered play": "el esbirro que acaba de entrar en juego", "activates against the player it is engaged with.": "se activa contra el jugador con el que está enfrentado.",
        "If an ability refers to a title shared by multiple cards in the game, that ability refers only to the card(s) that match the criteria highest in this list:":
            "Si una capacidad se refiere a un título que comparten varias cartas, solo se refiere a las que cumplan el criterio más alto de esta lista:",
        "The card on which the referential ability is printed.": "La carta en la que está impresa la capacidad.",
        "Cards that belong to the same identity or encounter set.": "Las cartas de la misma identidad o del mismo set de encuentro.", "All other cards.": "Todas las demás cartas.",
        "A confused character can attempt to thwart or use a thwart ability even if": "Un personaje confundido puede intentar frustrar o usar una capacidad de frustrar aunque",
        "it has no valid target": "no tenga un objetivo válido",
        "A stunned character can attempt to attack or use an attack ability even if": "Un personaje aturdido puede intentar atacar o usar una capacidad de ataque aunque",
        "Environment cards and encounter cards are not affected by crisis icons in play.": "Las cartas de entorno y de encuentro no se ven afectadas por los iconos de crisis en juego.",
        "When setting up a game in which at least one player is using the 'Pool aspect, shuffle 1 copy of the Crisis of Infinite Deadpools treachery card into the encounter deck.":
            "Si al menos un jugador usa el aspecto 'Pool, al preparar la partida baraja 1 copia de la traición Crisis of Infinite Deadpools en el mazo de encuentros.",
        "for any damage to your computer, loss of files, or any other issues that may arise from using them. Please be cautious and only use trusted content.":
            "de daños en tu equipo, pérdida de archivos ni otros problemas que pueda causar. Usa solo contenido de confianza.",
        "Notice: We will": "Aviso:", "collect some additional information when you upload your save file:": "al subir tu partida guardada se recoge información adicional:",
    };
    // whole sentences that also appear INSIDE longer texts (e.g. the game-over prompt): replaced wherever they are
    var SUBS = [
        ["The Final Stage of the Villain was Defeated", "Se derrotó la última fase del villano"],
        ["The Final Stage of the Main Scheme was Completed", "Se completó la última fase del plan principal"],
        ["The Main Scheme was Completed", "Se completó el plan principal"], ["All players were eliminated", "Todos los jugadores fueron eliminados"],
        // status names inserted by the engine into translated sentences
        ["queda Confused", "queda confundido"], ["queda Stunned", "queda aturdido"], ["queda Tough", "queda con dureza"],
        ["de estar Confused", "de estar confundido"], ["de estar Stunned", "de estar aturdido"], ["de estar Tough", "de tener dureza"],
    ];
    // [regex, replacement] for texts that contain numbers or names
    var PATTERNS = [
        [/^Join as Player (\d+)$/, "Unirse como jugador $1"], [/^Load (\d)$/, "Cargar $1"], [/^Save (\d)$/, "Guardar $1"],
        [/^Round (\d+) Step (\d+)$/, "Ronda $1, paso $2"], [/^(.+) x(\d+)$/, null],                       // statistics "Enters Play x1": translate the name part
        [/^Player (\d+) Turn$/, "Turno del jugador $1"], [/^Player (\d+)$/, "Jugador $1"],
        [/^The Main Scheme was Completed \((.+)\)$/, "Se completó el plan principal ($1)"], [/^The Villain was Defeated \((.+)\)$/, "El villano fue derrotado ($1)"],
        [/^(.+) was Defeated$/, "$1 fue derrotado"], [/^All Heroes were Defeated$/, "Todos los héroes fueron derrotados"],
        [/^Disclaimer: If you download any content from other sources,?$/, "Aviso: si descargas contenido de otras fuentes,"],
        [/^Put your decks in the folder "\.\/deck" to display them in `My Decks`.*$/, "Tus mazos guardados aparecen en «Mis mazos»."],
    ];
    // OK / Cancel buttons: written as HTML with a line break
    var BUTTONS = { "End<br>Turn": "Fin del<br>turno", "End<br>Response": "Terminar<br>respuesta", "End<br>Interrupt": "Terminar<br>interrupción",
        "Cancel<br>Pay": "Cancelar<br>pago", "End<br>Defense": "No<br>defender", "Cancel": "Cancelar", "Over<br>Pay": "Pago<br>excesivo", "End": "Terminar", "Cost": "Coste" };

    var miss = window.__i18nMiss = new Set();
    function translate(t) {
        if (Object.prototype.hasOwnProperty.call(EXACT, t)) return EXACT[t];
        var sub = t, hit = false;
        for (var k = 0; k < SUBS.length; k++) if (sub.indexOf(SUBS[k][0]) >= 0) { sub = sub.split(SUBS[k][0]).join(SUBS[k][1]); hit = true; }
        if (hit) return sub;
        for (var i = 0; i < PATTERNS.length; i++) {
            var m = t.match(PATTERNS[i][0]);
            if (!m) continue;
            if (PATTERNS[i][1] === null) { var head = translate(m[1]); return head ? head + " x" + m[2] : null; }
            return t.replace(PATTERNS[i][0], PATTERNS[i][1]);
        }
        return null;
    }
    var SKIP = "script,style,textarea,code,.face,.dt-item,.card-name,[data-no-i18n],#history-text";
    function skipped(el) { return el && el.closest && el.closest(SKIP); }
    function doText(node) {
        var raw = node.nodeValue; if (!raw || !/[A-Za-z]/.test(raw)) return;
        var t = raw.replace(/\s+/g, " ").trim(); if (!t || t.length > 400) return;
        if (skipped(node.parentElement)) return;
        var es = translate(t);
        if (es != null && es !== t) {
            // an <option> without value="" is read by its TEXT: keep the original English there so filters still work
            var p = node.parentElement;
            if (p && p.tagName === "OPTION" && !p.hasAttribute("value")) p.setAttribute("value", t);
            node.nodeValue = raw.replace(raw.trim(), es);
        }
        else if (es == null && /^[A-Za-z][A-Za-z .,:'()&\-!?]{1,60}$/.test(t)) miss.add(t);
    }
    function doAttrs(el) {
        if (skipped(el)) return;
        ["placeholder", "title"].forEach(function (a) { var v = el.getAttribute && el.getAttribute(a); if (v) { var es = translate(v.trim()); if (es) el.setAttribute(a, es); } });
        if (el.tagName === "INPUT" && /^(button|submit|reset)$/i.test(el.type) && el.value) { var es2 = translate(el.value.trim()); if (es2) el.value = es2; }
        if (el.id === "btn-ok" || el.id === "btn-end") {
            var key = el.innerHTML.replace(/<br\s*\/?>/gi, "<br>").trim();
            if (BUTTONS[key]) el.innerHTML = BUTTONS[key];
        }
    }
    function walk(root) {
        if (!root) return;
        if (root.nodeType === 3) { doText(root); return; }
        if (root.nodeType !== 1 || skipped(root)) return;
        doAttrs(root);
        var w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT);
        for (var n = w.nextNode(); n; n = w.nextNode()) { if (n.nodeType === 3) doText(n); else doAttrs(n); }
    }
    var queue = [], scheduled = false;
    function flush() { scheduled = false; var q = queue; queue = []; for (var i = 0; i < q.length; i++) walk(q[i]); }
    function start() {
        walk(document.body);
        new MutationObserver(function (records) {
            for (var i = 0; i < records.length; i++) {
                var r = records[i];
                if (r.type === "characterData") queue.push(r.target);
                else if (r.type === "attributes") queue.push(r.target);
                else for (var j = 0; j < r.addedNodes.length; j++) queue.push(r.addedNodes[j]);
                if (r.type === "childList" && (r.target.id === "btn-ok" || r.target.id === "btn-end")) queue.push(r.target);
            }
            if (!scheduled) { scheduled = true; (window.requestAnimationFrame || setTimeout)(flush); }
        }).observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ["placeholder", "title", "value"] });
        document.documentElement.lang = "es";
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
    window.MarvelI18n = { translate: translate, missing: function () { return Array.from(miss).sort(); } };
})();
