import random as _random
from collections import deque
from core import *

CATEGORY_NAME = "RANDOM"

class Random:
    """
    Seeded, reproducible random numbers. Undo / load-game / replay re-run the whole game from the same seed, so every
    random call must be a pure function of (seed, call order).

    This used to be backed by `numpy.random` (a heavy dependency that is not available in the browser) or by a hand made
    Mersenne Twister whose `shuffle` was biased (random swaps, not Fisher-Yates) and whose `Undo` did nothing.
    The standard library `random.Random` is the same MT19937 generator, unbiased, and needs no extra package.
    """
    seed = 0
    counter = 0
    rand = _random.Random(0)

    # Only the most recent states are kept: `Undo` is a developer cheat that rewinds a handful of calls.
    states: 'deque[Any]' = deque(maxlen=64)

    @staticmethod
    def AddCounter():
        from engine.log import Log
        Random.counter += 1
        Log.DebugSilent(CATEGORY_NAME, f"{Random.counter=}")

    @staticmethod
    def SetSeed(seed: int) -> None:
        from engine.log import Log
        Random.seed = seed
        Random.counter = 0
        Random.states.clear()
        Random.rand = _random.Random(seed)
        Log.DebugSilent(CATEGORY_NAME, f"Seed: {seed}")

    @staticmethod
    def RandomSeed() -> int:
        seed = _random.SystemRandom().randrange(2**31-2)+1
        Random.SetSeed(seed)
        return seed

    T = TypeVar("T")
    @staticmethod
    def RandomChoice(input_list: Sequence[T]) -> T:
        assert len(input_list) > 0
        Random.AddCounter()
        Random.states.append(Random.rand.getstate())
        return Random.rand.choice(input_list)

    @staticmethod
    def RandomChoice2(input_list: Sequence[T], x: int) -> List[T]:
        if x < 0:
            raise ValueError("x cannot be negative.")
        if x > len(input_list):
            raise ValueError("x cannot be greater than the length of the input list.")
        if x == 1:
            return [Random.RandomChoice(input_list)]
        if len(input_list) == x:
            return list(input_list)

        Random.AddCounter()
        Random.states.append(Random.rand.getstate())
        return Random.rand.sample(list(input_list), x)

    @staticmethod
    def Shuffle(list: List[Any]) -> None:
        Random.AddCounter()
        Random.states.append(Random.rand.getstate())
        Random.rand.shuffle(list)

    @staticmethod
    def Undo():
        if Random.states:
            Random.rand.setstate(Random.states.pop())
