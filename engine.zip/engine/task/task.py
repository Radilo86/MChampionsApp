import threading
import asyncio
from core import *
from engine.task.condition import Condition
from engine.log import Log
from engine.browser.runtime import COOPERATIVE, run_coroutine_sync

CATEGORY_NAME = "TASK"

class Task:

    def __init__(self, process: Callable[[], Awaitable[Any]],
                name: str|None,
                run_for_ever: bool,
                condition: 'Condition') -> None:
        self.is_finished = False
        self.run_forever = run_for_ever
        self.condition = condition
        self.return_value: Any = None

        if COOPERATIVE:
            # No threads in the browser: the (never-suspending) coroutine is simply driven to completion by `Start`
            self.process = process
            self.name = name
            return

        self.loop: asyncio.AbstractEventLoop = asyncio.new_event_loop()

        def run() -> None:
            try:
                asyncio.set_event_loop(self.loop)
                self.return_value = self.loop.run_until_complete(process())
                if self.run_forever:
                    self.loop.run_forever()
            except Exception as exc:
                Log.FailedTrace(CATEGORY_NAME, exc)
            finally:
                self.is_finished = True
                self.loop.close()
                self.condition.NotifyAll()

        self.thread = threading.Thread(target=run, name=name)

    def Start(self) -> None:
        if COOPERATIVE:
            try:
                self.return_value = run_coroutine_sync(self.process())
            except Exception as exc:
                Log.FailedTrace(CATEGORY_NAME, exc)
            finally:
                self.is_finished = True
            return
        self.thread.start()

    def Stop(self) -> None:
        if COOPERATIVE:
            return
        if self.loop.is_running():
            self.loop.call_soon_threadsafe(self.loop.stop)
        self.thread.join()

    def WaitFinished(self) -> None:
        def check():
            return self.is_finished
        self.condition.Wait(check)

