"""
Content packs: new campaigns / scenarios / encounter sets / cards (+ their scripts and pictures) for the offline app.

A pack is a folder (or a ZIP of it):

    contenido.json        {"id": "mi_campania", "nombre": "Mi campaña", "version": "1", "autor": "...", "descripcion": "..."}
    caja.json             optional: the box shown in "New Game": {"nombre": "90. Mi campaña", "escenarios": [...], "heroes": [...], "sets": [...]}
    cartas/*.json         new cards, same format as data/cards.json: {"<pack>": [ {"card_id": "99001", "type": "Minion", ...}, ... ]}
    cartas/<id>.py        script with the abilities of card <id> (same API as cards/pack/**: see docs/card_scripting_guide.md)
    escenarios/*.json     scenarios, same format as data/scenarios/*.json
    sets/*.json           encounter / modular sets, same format as data/encounter_sets/*.json
    nemesis/*.json        nemesis sets (same format)
    mazos/*.json          hero decks, same format as deck/starter/*.json
    imagenes/<id>.jpg     card pictures (.jpg/.png/.webp; landscape schemes are rotated automatically)

`check(files, images)` validates a pack WITH THE ENGINE'S OWN LOADERS and returns where each file must be installed.
It is used by the app (menu "Importar contenido"), by the build (`build_pwa.py --content`) and by `validar_contenido.py`.
"""
import json
import os
import re
import traceback
from typing import Any, Dict, List, Optional, Tuple

TARGETS = {                                   # pack folder -> engine folder
    "escenarios": "data/scenarios_custom/",
    "sets": "data/encounter_sets_custom/",
    "nemesis": "data/encounter_sets_custom/",
    "mazos": "deck/",
}
CARDS_FOLDER = "data/cards_custom/"
SCRIPTS_FOLDER = "cards/custom/"
BOXES_FOLDER = "data/sets_custom/"
MANIFESTS_FOLDER = "content/"
ID_RE = re.compile(r"^[a-z0-9][a-z0-9_\-]{1,40}$")
NAME_RE = re.compile(r"^[A-Za-z0-9_\-\.]+$")
PICTURE_EXT = (".jpg", ".jpeg", ".png", ".webp")


def slug(text: str) -> str:
    s = re.sub(r"[^a-z0-9_\-]+", "_", text.lower()).strip("_")
    return s[:40] or "contenido"


def _ids(value: Any):
    for v in value or []:
        for part in str(v).split(","):
            if part.strip():
                yield part.strip()


def _load_script(card_id: str, source: str, path: str) -> 'Tuple[Optional[str], int]':
    """Compile + run a card script exactly like CardsDB does for user scripts; returns (error, number of abilities)."""
    import ast
    import importlib.util
    try:
        tree = ast.parse(source, filename=path)
    except SyntaxError as exc:
        return f"error de sintaxis en la línea {exc.lineno}: {exc.msg}", 0

    class ImportTransformer(ast.NodeTransformer):
        def visit_ImportFrom(self, node: ast.ImportFrom):
            if node.module is None and node.names and node.names[0].name == "*":
                node.module = "cards.pack"; node.level = 0
            return node

    try:
        code = compile(ImportTransformer().visit(tree), path, "exec")
        spec = importlib.util.spec_from_loader(card_id, loader=None)
        module = importlib.util.module_from_spec(spec)          # type: ignore[arg-type]
        exec(code, module.__dict__)
        if not hasattr(module, "GetAbilities"):
            return "no define la función GetAbilities()", 0
        abilities = module.GetAbilities()
        return None, len(abilities)
    except Exception as exc:
        tb = traceback.extract_tb(exc.__traceback__)
        line = next((f.lineno for f in reversed(tb) if f.filename == path), None)
        return f"{type(exc).__name__}: {exc}" + (f" (línea {line})" if line else ""), 0


_desc_keys: Optional[Dict[str, set]] = None


def desc_keys() -> Dict[str, set]:
    """card type -> every "desc" key the official cards of that type use (what the engine accepts)."""
    global _desc_keys
    if _desc_keys is None:
        from cards.database import CardsDB
        keys: Dict[str, set] = {}
        for p in CardsDB.papers.values():
            keys.setdefault(p.type, set()).update((p.desc or {}).keys())
        _desc_keys = keys
    return _desc_keys


def check(files: Dict[str, str], images: List[str]) -> Dict[str, Any]:
    """
    files:  pack-relative path -> text (every file except pictures)
    images: pack-relative paths of the pictures
    Returns {"ok", "pack", "errors", "warnings", "plan": {target: source}, "images": {card_id: source}, "summary"}
    """
    from cards.database import CardsDB
    from cards.paper import Paper
    from engine.lib import Json
    from engine.file import FileManager
    from game.scene.replay.campaign import CampaignDescriptor
    from game.scene.replay.hero import HeroDescriptor
    from game.scene.replay.encounter_set import EncounterSetDescriptor

    errors: List[str] = []
    warnings: List[str] = []
    plan: Dict[str, str] = {}
    files = {k.replace("\\", "/").lstrip("./"): v for k, v in files.items()}

    # ---- manifest
    manifest: Dict[str, Any] = {}
    if "contenido.json" not in files:
        errors.append("Falta contenido.json en la raíz del paquete.")
    else:
        try:
            manifest = json.loads(files["contenido.json"])
            if not isinstance(manifest, dict): raise ValueError("no es un objeto JSON")
        except ValueError as exc:
            errors.append(f"contenido.json no es JSON válido: {exc}")
    name = str(manifest.get("nombre") or manifest.get("name") or "").strip()
    pack_id = str(manifest.get("id") or slug(name)).strip()
    if manifest and not name:
        errors.append("contenido.json: falta \"nombre\".")
    if manifest and not ID_RE.match(pack_id):
        errors.append(f"contenido.json: \"id\" debe ser corto, en minúsculas, sin espacios (letras, números, _ o -): '{pack_id}'.")
    pack = {"id": pack_id, "nombre": name, "version": str(manifest.get("version", "1")), "autor": manifest.get("autor", ""),
            "descripcion": manifest.get("descripcion", "")}

    known_cards = set(CardsDB.papers)
    known_sets = {os.path.splitext(f)[0] for d in ("data/encounter_sets", "data/nemesis", "data/encounter_sets_custom") if os.path.isdir(d) for f in os.listdir(d) if f.endswith(".json")}
    known_scen = {os.path.splitext(f)[0] for d in ("data/scenarios", "data/challenges", "data/scenarios_custom") if os.path.isdir(d) for f in os.listdir(d) if f.endswith(".json")}

    # ---- cards (catalogue)
    pack_cards: Dict[str, Any] = {}
    for path in sorted(p for p in files if p.startswith("cartas/") and p.endswith(".json")):
        try:
            data = json.loads(files[path])
            if not isinstance(data, dict): raise ValueError('debe ser {"nombre_de_pack": [cartas...]}')
        except ValueError as exc:
            errors.append(f"{path}: JSON no válido ({exc})"); continue
        for pack_name, cards in data.items():
            if not isinstance(cards, list):
                errors.append(f"{path}: \"{pack_name}\" debe ser una lista de cartas"); continue
            for i, card in enumerate(cards):
                where = f"{path} › {pack_name}[{i}]"
                if not isinstance(card, dict) or not card.get("card_id"):
                    errors.append(f"{where}: cada carta necesita \"card_id\""); continue
                cid = str(card["card_id"])
                if cid in pack_cards:
                    errors.append(f"{where}: card_id {cid} repetido en el paquete")
                try:
                    if not Paper.GetFullLink(card):
                        paper = Paper.Load(dict(card), pack_name)
                        if not paper.name: warnings.append(f"{where}: la carta {cid} no tiene \"name\"")
                        if not paper.type: errors.append(f"{where}: la carta {cid} no tiene \"type\"")
                except Exception as exc:
                    errors.append(f"{where}: la carta {cid} no se puede cargar ({type(exc).__name__}: {exc})"); continue
                # every "desc" key must be one the engine knows for that card type (an unknown key crashes the game setup)
                ctype = str(card.get("type", ""))
                allowed = desc_keys().get(ctype)
                if allowed is not None:
                    import difflib
                    for key in (card.get("desc") or {}):
                        if key not in allowed:
                            near = difflib.get_close_matches(key, sorted(allowed), n=3, cutoff=0.4)
                            errors.append(f"{where}: la carta {cid} ({ctype}) usa la clave «{key}» en \"desc\", que no existe para ese tipo."
                                          + (f" ¿Quizá {', '.join(near)}?" if near else f" Claves válidas: {', '.join(sorted(allowed))}."))
                if cid in known_cards:
                    warnings.append(f"La carta {cid} ya existe en el juego («{CardsDB.papers[cid].name}»): la del paquete la sustituye.")
                if card.get("reglas") is not None:
                    from engine.browser import rules as _rules
                    errs, warns = _rules.check_rules(card.get("reglas"), str(card.get("type", "")))
                    errors.extend(f"{where} (carta {cid}): {e}" for e in errs)
                    warnings.extend(f"{where} (carta {cid}): {w}" for w in warns)
                    if f"cartas/{cid}.py" in files:
                        warnings.append(f"La carta {cid} tiene «reglas» y también cartas/{cid}.py: se usará el script.")
                pack_cards[cid] = card
        plan[CARDS_FOLDER + f"{pack_id}__{os.path.basename(path)}"] = path
    all_cards = known_cards | set(pack_cards)

    # ---- scripts
    for path in sorted(p for p in files if p.startswith("cartas/") and p.endswith(".py")):
        cid = os.path.splitext(os.path.basename(path))[0]
        if cid not in all_cards:
            warnings.append(f"{path}: no hay ninguna carta con id {cid}; el script no se usará.")
        error, n = _load_script(cid, files[path], path)
        if error: errors.append(f"{path}: {error}")
        elif n == 0: warnings.append(f"{path}: GetAbilities() devuelve una lista vacía.")
        plan[SCRIPTS_FOLDER + f"{cid}.py"] = path

    def check_ids(where: str, value: Any) -> None:
        missing = [x for x in _ids(value) if x not in all_cards]
        if missing: errors.append(f"{where}: cartas que no existen: {', '.join(sorted(set(missing))[:12])}")

    # ---- encounter / nemesis sets
    pack_sets = set()
    for folder in ("sets", "nemesis"):
        for path in sorted(p for p in files if p.startswith(folder + "/") and p.endswith(".json")):
            base = os.path.splitext(os.path.basename(path))[0]
            if not NAME_RE.match(base): errors.append(f"{path}: el nombre del archivo solo puede tener letras, números, _ - ."); continue
            try:
                data = json.loads(files[path]); Json.LoadsAs(files[path], EncounterSetDescriptor)
            except Exception as exc:
                errors.append(f"{path}: no es un set válido ({type(exc).__name__}: {exc})"); continue
            check_ids(path, data.get("encounters"))
            if base in known_sets: warnings.append(f"{path}: ya existe un set llamado '{base}': lo sustituye.")
            pack_sets.add(base); plan[TARGETS[folder] + base + ".json"] = path
    all_sets = known_sets | pack_sets

    # ---- scenarios
    pack_scen = set()
    for path in sorted(p for p in files if p.startswith("escenarios/") and p.endswith(".json")):
        base = os.path.splitext(os.path.basename(path))[0]
        if not NAME_RE.match(base): errors.append(f"{path}: el nombre del archivo solo puede tener letras, números, _ - ."); continue
        try:
            data = json.loads(files[path]); Json.LoadsAs(files[path], CampaignDescriptor)
        except Exception as exc:
            errors.append(f"{path}: no es un escenario válido ({type(exc).__name__}: {exc})"); continue
        for key in ("villain", "schemes", "set_aside", "encounters"): check_ids(f"{path} › {key}", data.get(key))
        if not list(_ids(data.get("schemes"))): errors.append(f"{path}: necesita al menos un plan principal en \"schemes\"")
        for s in (data.get("encounter_sets") or []) + (data.get("modular_sets") or []):
            if s not in all_sets: errors.append(f"{path}: usa el set '{s}', que no existe (ni en el juego ni en el paquete)")
        if base in known_scen: warnings.append(f"{path}: ya existe un escenario '{base}': lo sustituye.")
        pack_scen.add(base); plan[TARGETS["escenarios"] + base + ".json"] = path

    # ---- hero decks
    pack_heroes = set()
    for path in sorted(p for p in files if p.startswith("mazos/") and p.endswith(".json")):
        base = os.path.splitext(os.path.basename(path))[0]
        if not NAME_RE.match(base): errors.append(f"{path}: el nombre del archivo solo puede tener letras, números, _ - ."); continue
        try:
            data = json.loads(files[path]); Json.LoadsAs(files[path], HeroDescriptor)
        except Exception as exc:
            errors.append(f"{path}: no es un mazo válido ({type(exc).__name__}: {exc})"); continue
        for key in ("hero", "hero_deck", "player_deck", "obligations", "nemesis_set", "set_aside"): check_ids(f"{path} › {key}", data.get(key))
        pack_heroes.add(base); plan[TARGETS["mazos"] + base + ".json"] = path

    # ---- box shown in New Game
    box_entry: Dict[str, Any] = {}
    if "caja.json" in files:
        try:
            box = json.loads(files["caja.json"])
            title = str(box.get("nombre") or name)
            box_entry = {title: {"name": pack_id, "scenarios": list(box.get("escenarios", sorted(s for s in pack_scen if not s.endswith("_expert")))),
                                 "heroes": list(box.get("heroes", [])), "encounters": list(box.get("sets", sorted(pack_sets))), "max_id": ""}}
            for s in box_entry[title]["scenarios"]:
                if s not in known_scen | pack_scen: errors.append(f"caja.json: el escenario '{s}' no existe")
                elif s + "_expert" not in known_scen | pack_scen:
                    warnings.append(f"caja.json: '{s}' no tiene versión experta (escenarios/{s}_expert.json): en New Game aparecerá como no disponible.")
            plan[BOXES_FOLDER + pack_id + ".json"] = "caja.json"
        except Exception as exc:
            errors.append(f"caja.json no es válido: {exc}")
    elif pack_scen:
        warnings.append("No hay caja.json: los escenarios aparecerán en la caja «Custom» de New Game.")

    # ---- pictures
    picture_of: Dict[str, str] = {}
    for path in images:
        p = path.replace("\\", "/")
        cid = os.path.splitext(os.path.basename(p))[0]
        if not p.lower().endswith(PICTURE_EXT): continue
        picture_of[cid] = p
        if cid not in all_cards: warnings.append(f"{p}: no hay ninguna carta con id {cid}.")
    no_picture = sorted(c for c in pack_cards if c not in picture_of and not Paper.GetFullLink(pack_cards[c]))
    if no_picture:
        warnings.append(f"{len(no_picture)} cartas del paquete no tienen imagen (se dibujarán con sus datos): {', '.join(no_picture[:15])}{' …' if len(no_picture) > 15 else ''}")

    unknown = [p for p in files if not (p == "contenido.json" or p == "caja.json" or p.startswith(("cartas/", "escenarios/", "sets/", "nemesis/", "mazos/", "imagenes/")) or p.lower().endswith((".md", ".txt")))]
    if unknown: warnings.append(f"Archivos que se ignoran (carpeta desconocida): {', '.join(unknown[:10])}")

    summary = {"cartas": len(pack_cards), "con_reglas": sum(1 for c in pack_cards.values() if c.get("reglas")), "scripts": sum(1 for t in plan if t.startswith(SCRIPTS_FOLDER)), "escenarios": len(pack_scen),
               "sets": len(pack_sets), "mazos": len(pack_heroes), "imagenes": len(picture_of), "caja": next(iter(box_entry), "")}
    return {"ok": not errors, "pack": pack, "errors": errors, "warnings": warnings, "plan": plan, "images": picture_of, "summary": summary,
            "manifest_path": MANIFESTS_FOLDER + pack_id + ".json"}


def installed() -> List[Dict[str, Any]]:
    out = []
    if os.path.isdir(MANIFESTS_FOLDER):
        for f in sorted(os.listdir(MANIFESTS_FOLDER)):
            if f.endswith(".json"):
                try: out.append(json.load(open(os.path.join(MANIFESTS_FOLDER, f), encoding="utf-8")))
                except Exception: pass
    return out


def custom_boxes() -> Dict[str, Any]:
    boxes: Dict[str, Any] = {}
    if os.path.isdir(BOXES_FOLDER):
        for f in sorted(os.listdir(BOXES_FOLDER)):
            if f.endswith(".json"):
                try:
                    box = json.load(open(os.path.join(BOXES_FOLDER, f), encoding="utf-8"))
                    title = str(box.get("nombre") or f[:-5])
                    boxes[title] = {"name": f[:-5], "scenarios": list(box.get("escenarios", [])), "heroes": list(box.get("heroes", [])),
                                    "encounters": list(box.get("sets", [])), "max_id": ""}
                except Exception: pass
    return boxes


def custom_card_files() -> List[str]:
    if not os.path.isdir(CARDS_FOLDER): return []
    return ["./" + CARDS_FOLDER + f for f in sorted(os.listdir(CARDS_FOLDER)) if f.endswith(".json")]


def custom_index() -> Dict[str, Any]:
    """card id -> data the service worker uses to draw the cards of content packs (same shape as cards-index.json)."""
    from cards.database import CardsDB
    tag = re.compile(r"<[^>]*>")
    ids = set()
    for path in custom_card_files():
        try:
            for cards in json.load(open(path, encoding="utf-8")).values():
                if isinstance(cards, list): ids.update(str(c.get("card_id")) for c in cards if isinstance(c, dict))
        except Exception: pass
    index: Dict[str, Any] = {}
    for cid in ids:
        p = CardsDB.papers.get(cid)
        if not p: continue
        d = p.desc or {}
        entry: Dict[str, Any] = {"n": p.name, "t": p.type}
        if d.get("Class"): entry["a"] = d["Class"]
        if "Cost" in d: entry["c"] = d["Cost"]
        stats = " ".join(f"{k} {d[k]}" for k in ("ATK", "THW", "DEF", "SCH", "REC", "HP", "RES") if k in d)
        if stats: entry["s"] = stats
        if p.traits: entry["tr"] = " · ".join(p.traits)
        text = tag.sub("", p.text or "")
        if text: entry["x"] = text[:420]
        index[cid] = entry
    return index
