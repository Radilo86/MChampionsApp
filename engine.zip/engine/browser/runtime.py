"""
Cooperative runtime.

The engine thread is the *only* Python thread. Whenever the game must wait (for the player's decision, for the UI to
finish an animation, for a client to connect, for a new game...) it calls `Condition.Wait(check, timeout)`.
Here that is implemented as:

    while not check():
        message = bridge.next_message(timeout)   # blocks (Atomics.wait in the browser, a queue in tests)
        server.dispatch(message)                 # behaves exactly like the old aiohttp handlers

so UI requests are served *while* the game is "blocked", which is precisely when the original server thread served them.
"""
import sys
import os
import json
import time
import traceback
from typing import Any, Callable, Dict, List, Optional

IS_BROWSER = sys.platform == "emscripten"
# Native tests (and the headless QA bot) can force this mode as well.
COOPERATIVE = IS_BROWSER or os.environ.get("MARVEL_COOPERATIVE") == "1"


class Bridge:
    """Interface between the engine and whatever hosts it (browser page, test harness...)."""

    def next_message(self, timeout_ms: Optional[float]) -> Optional[Dict[str, Any]]:
        """Block until the UI sends something. Returns None on timeout."""
        raise NotImplementedError

    def respond(self, request_id: int, status: int, content_type: str, body: Any) -> None:
        raise NotImplementedError

    def frame(self, player_id: int, text: str) -> None:
        """Push a `FrameDescriptor` (JSON text) to every socket attached to `player_id`."""
        raise NotImplementedError

    def save_file(self, path: str, data: bytes) -> None:
        """A persistent file was written: let the host store it (IndexedDB in the browser)."""

    def delete_file(self, path: str) -> None:
        """A persistent file was removed."""

    def log(self, text: str) -> None:
        sys.__stderr__.write(text if text.endswith("\n") else text + "\n")


class JsBridge(Bridge):
    """Bridge used inside the Pyodide web worker. `js.bridge` is created by worker.js."""

    def __init__(self) -> None:
        import js  # type: ignore
        from pyodide.ffi import to_js  # type: ignore
        self._js = js.bridge
        self._to_js = to_js

    def next_message(self, timeout_ms: Optional[float]) -> Optional[Dict[str, Any]]:
        raw = self._js.nextMessage(-1 if timeout_ms is None else float(timeout_ms))
        if raw is None:
            return None
        return json.loads(str(raw))

    def respond(self, request_id: int, status: int, content_type: str, body: Any) -> None:
        if isinstance(body, (bytes, bytearray)):
            self._js.respondBinary(request_id, status, content_type, self._to_js(bytes(body)))
        else:
            self._js.respond(request_id, status, content_type, body)

    def frame(self, player_id: int, text: str) -> None:
        self._js.frame(player_id, text)

    def save_file(self, path: str, data: bytes) -> None:
        self._js.saveFile(path, self._to_js(bytes(data)))

    def delete_file(self, path: str) -> None:
        self._js.deleteFile(path)

    def log(self, text: str) -> None:
        self._js.log(text)


class Runtime:
    bridge: Optional[Bridge] = None
    dispatcher: Optional[Callable[[Dict[str, Any]], None]] = None
    persistent_prefixes: List[str] = []
    stopping = False

    @staticmethod
    def setup(bridge: Bridge, dispatcher: Callable[[Dict[str, Any]], None]) -> None:
        Runtime.bridge = bridge
        Runtime.dispatcher = dispatcher

    # ------------------------------------------------------------------------------------------------------------
    @staticmethod
    def pump(timeout_ms: Optional[float]) -> bool:
        """Receive and serve ONE message. Returns False if nothing arrived before the timeout."""
        assert Runtime.bridge is not None, "Runtime not set up"
        message = Runtime.bridge.next_message(timeout_ms)
        if message is None:
            return False
        if message.get("kind") == "stop":
            Runtime.stopping = True
            raise SystemExit("stop requested")
        try:
            assert Runtime.dispatcher is not None
            Runtime.dispatcher(message)
        except SystemExit:
            raise
        except Exception:  # a bad request must never kill the game loop
            text = traceback.format_exc()
            Runtime.bridge.log("[server] handler failed:\n" + text)
            request_id = message.get("id")
            if request_id is not None:
                Runtime.bridge.respond(request_id, 500, "text/plain", text)
        return True

    @staticmethod
    def wait_for(check: Callable[[], bool], timeout: Optional[float] = None) -> bool:
        """Cooperative equivalent of `threading.Condition.wait_for`."""
        deadline = None if timeout is None else time.monotonic() + timeout
        while True:
            if check():
                return True
            if deadline is None:
                Runtime.pump(None)
            else:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return bool(check())
                Runtime.pump(remaining * 1000.0)

    # ------------------------------------------------------------------------------------------------------------
    # Persistence helpers (called by engine.file)
    @staticmethod
    def is_persistent(path: str) -> bool:
        norm = path.replace("\\", "/")
        if norm.startswith("./"):
            norm = norm[2:]
        return any(norm.startswith(prefix) for prefix in Runtime.persistent_prefixes)

    @staticmethod
    def file_written(path: str) -> None:
        if Runtime.bridge is None or not Runtime.is_persistent(path):
            return
        try:
            with open(path, "rb") as f:
                Runtime.bridge.save_file(_norm(path), f.read())
        except Exception:
            Runtime.bridge.log("[persist] cannot read back " + path + "\n" + traceback.format_exc())

    @staticmethod
    def file_deleted(path: str) -> None:
        if Runtime.bridge is not None and Runtime.is_persistent(path):
            Runtime.bridge.delete_file(_norm(path))


def _norm(path: str) -> str:
    p = path.replace("\\", "/")
    return p[2:] if p.startswith("./") else p


class Condition:
    """Drop-in replacement for `engine.task.condition.Condition` (same API, no threads)."""

    def __init__(self, name: str) -> None:
        self.name = name
        self.func: Any = None

    def Wait(self, check: Callable[[], bool], timeout: Optional[float] = None) -> bool:
        self.func = check
        return Runtime.wait_for(check, timeout)

    def NotifyAll(self) -> None:
        # State is only ever mutated by the engine thread itself (handlers run inside `Wait`), so there is
        # nobody to wake up: the predicate is simply re-evaluated after each handled message.
        pass


def run_coroutine_sync(coro: Any) -> Any:
    """Drive a coroutine that never really suspends (all the engine's `async def` handlers are like that)."""
    try:
        while True:
            coro.send(None)
    except StopIteration as stop:
        return stop.value
