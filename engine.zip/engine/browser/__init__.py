"""
Browser / PWA runtime of the Marvel LCG engine.

The original engine was designed to run as a desktop server (aiohttp + threads). A browser (Pyodide / WebAssembly)
has neither threads nor sockets, so this package provides:

  * a single-threaded *cooperative* implementation of `Condition` (see `runtime.py`), where "waiting" means
    "serve incoming requests from the UI until the awaited condition becomes true";
  * a `DeviceManager` that talks to the UI through a `Bridge` instead of a web server (`device.py`);
  * an in-process re-implementation of every HTTP/WebSocket route the original server exposed (`server.py`).

Nothing in `game/` or `cards/` knows about any of this.
"""
