"""
Entry point of the offline app. Runs inside the Pyodide web worker (and, for tests, inside a plain Python thread).

    boot.main(bridge, files)      # never returns until the page asks the worker to stop
"""
import sys
import os
import time
import traceback
from typing import Any, Dict, Optional

# Folders / files that must survive a page reload (they are mirrored to IndexedDB by the host page)
PERSISTENT_PREFIXES = ["replays/", "deck/", "statistics.json", "data/scenarios_custom/", "settings/", "save_",
                       # content packs (new campaigns / cards) imported in the app
                       "data/cards_custom/", "cards/custom/", "data/encounter_sets_custom/", "data/sets_custom/", "content/"]


def main(bridge: Any, files: Optional[Dict[str, Any]] = None) -> None:
    from engine.browser.runtime import Runtime, COOPERATIVE
    assert COOPERATIVE, "The browser runtime must be selected before importing the engine"

    Runtime.bridge = bridge
    Runtime.persistent_prefixes = PERSISTENT_PREFIXES

    # Restore what the user saved in previous sessions *before* the engine reads statistics / decks
    from engine.browser.server import restore_file, BrowserServer
    for path, data in (files or {}).items():
        try:
            restore_file(path, data)
        except Exception:
            bridge.log(f"[boot] could not restore {path}\n{traceback.format_exc()}")

    # This build always runs with its own configuration (device = "browser", no web server, no online images...).
    # Values are injected with "command line" priority so that a stray desktop `launch.json` can never win.
    import json
    from engine.config import ConfigVariables
    config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "launch.browser.json")
    with open(config_path, encoding="utf-8") as config_file:
        ConfigVariables.instance_command.update(json.load(config_file))
    # language of the texts the engine writes (prompts, log): Spanish unless the player chose English in the menu
    idioma = "es"
    try:
        idioma = json.load(open("settings/idioma.json", encoding="utf-8")).get("idioma", "es")
    except Exception:
        pass
    if idioma == "es" and os.path.exists("data/translate_es.json"):
        ConfigVariables.instance_command["translate_file"] = "./data/translate_es.json"
    # card catalogues of the installed content packs (they must be known before CardsDB.Initialize)
    from engine.browser import content
    if content.custom_card_files():
        ConfigVariables.instance_command["cards_json_custom_files"] = content.custom_card_files()

    from engine import Engine
    from build import Build
    if not Engine.Initialize():
        raise RuntimeError("Engine.Initialize() failed")

    server = BrowserServer(Engine.device_manager)
    Engine.device_manager.server = server
    Runtime.setup(bridge, server.dispatch)
    bridge.log(f"[boot] Marvel LCG engine ready ({Build.MAJOR}.{Build.MINOR}.{Build.PATCH}.{Build.BUILD})")

    crashes = 0
    while not Runtime.stopping:
        started = time.monotonic()
        try:
            Engine.game.GameRun()
            return
        except SystemExit:
            return
        except Exception:
            # The desktop build exits on an unhandled engine error. A phone app must not: report and go back
            # to "waiting for a new game", exactly the state the UI expects.
            bridge.log("[boot] engine crashed, restarting the game loop:\n" + traceback.format_exc())
            crashes = crashes + 1 if time.monotonic() - started < 2 else 1
            if crashes >= 5:
                raise
            try:
                Engine.game.state.SetRunningState(False)
                Engine.game.state.start_state.Reset()
            except Exception:
                pass
