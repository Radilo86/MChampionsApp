"""
Decision validation, done BEFORE a player's decision reaches the engine.

Why: when the controller accepts a decision it starts mutating the world while it parses it (targets are set, and
`Player.SpendResource` moves the paying cards to the resource area and discards them) and only afterwards finds out
that, say, the cost was not covered. The decision is then rejected, but those side effects stay, and a replay of the
recorded decisions (undo / load) does not reproduce them. The official UI never sends such a decision, but stale or
duplicated taps on a phone can: a double tap, a button of a question that was already answered, a page that reconnects.

`validate_decision` only rejects what is CERTAINLY invalid (unknown / unplayable option, illegal target, wrong number of
targets, payment from a source that is not offered). Anything it does not understand
(debug commands, unexpected formats) is let through unchanged.
"""
import json
from typing import Any, Dict, List, Optional


def _payment_sources(pay: Dict[str, Any]) -> Dict[str, int]:
    """effect id -> number of resources it produces (len of its text: 'Y' -> 1, 'YY' -> 2)."""
    sources: Dict[str, int] = {}
    for item in pay.get("payment", []) or []:
        if isinstance(item, dict):
            if "effect_id" in item:
                sources[str(item["effect_id"])] = max(1, len(str(item.get("res_text", "Y"))))
            else:
                for effect_id, text in item.items():
                    sources[str(effect_id)] = max(1, len(str(text)))
    return sources


def validate_decision(options_json: str, post_json: str) -> Optional[str]:
    """Returns a reason (str) if the decision is certainly invalid, otherwise None."""
    try:
        command = json.loads(post_json)
        options: List[Dict[str, Any]] = json.loads(options_json)
    except (TypeError, ValueError):
        return None
    if not isinstance(command, dict) or not isinstance(options, list) or "id" not in command:
        return None

    command_id = str(command.get("id", ""))
    if not command_id.lstrip("-").isdigit():
        return None                                        # debug / console commands (":..."), unknown formats
    if command_id in ("0", ""):
        return None                                        # "pass" / cancel / end phase

    option = next((o for o in options if str(o.get("id")) == command_id), None)
    if option is None:
        return "la opción ya no está disponible (pregunta anterior)"
    if option.get("failure_reason"):
        return "la opción no se puede jugar ahora"

    targets = [str(t) for t in (command.get("targets") or [])]
    legal = {str(t) for t in (option.get("all_legal_targets") or [])}
    low, high = (option.get("target_num_range") or [0, 0])[:2]
    if any(t not in legal for t in targets):
        return "objetivo no válido"
    if len(targets) < low or len(targets) > max(high, low):
        return "número de objetivos incorrecto"

    pay_map = option.get("target_payment") or {}
    pay = pay_map.get(targets[0]) if targets else None
    if pay is None:
        pay = pay_map.get("0")
    if isinstance(pay, dict):
        # NOTE: whether the cost is covered is NOT checked here. It looks easy ("sum of the chosen resources >= cost") but the
        # engine accepts cheaper payments (costs reduced to 0, special rules...): measured on 3,600 decisions, that rule
        # wrongly rejected 12 legal plays. Underpayment is handled inside the engine (see EffectChecker.CheckBeforeActive).
        sources = _payment_sources(pay)
        chosen = [str(r) for r in (command.get("resources") or [])]
        if any(r not in sources for r in chosen):
            return "se paga con algo que no es un recurso disponible"
    return None
