"""
MarvelCDB (https://marvelcdb.com) deck -> deck of this game.

The page downloads the deck from the MarvelCDB public API (needs a connection, once) and sends the JSON here; the
conversion needs the card catalogue and the starter decks, which live in the engine. The result is a normal hero deck
(`{"hero", "hero_deck", "obligations", "nemesis_set", "player_deck", ...}`) that can be saved on the device and then
used offline.

MarvelCDB deck JSON (API `/api/public/deck/<id>` and `/api/public/decklist/<id>`):
    {"id": 123, "name": "...", "hero_code": "01001", "hero_name": "Spider-Man",
     "slots": {"01002": 1, "01003": 2, "01058": 2, ...}, "meta": "{\"aspect\":\"justice\"}" | null, ...}
"""
import copy
import json
import re
from typing import Any, Dict, List, Optional, Tuple

from engine.file import FileManager
from engine.lib import Json

PLAYER_CARD_TYPES = {"Ally", "Event", "Support", "Upgrade", "Resource", "PlayerSideScheme", "Evidence"}
HACK_SKIP = {"26002"}      # the original deck editor skips this card as well

_starter_cache: Optional[Dict[str, Tuple[str, Dict[str, Any]]]] = None


def _hero_code(face: str) -> str:
    """'01001a,01001b' -> '01001'"""
    return re.sub(r"[a-z]+$", "", face.split(",")[0])


def starter_decks() -> Dict[str, Tuple[str, Dict[str, Any]]]:
    """hero code -> (file path, starter deck json)"""
    global _starter_cache
    if _starter_cache is None:
        from engine.file.manager import STARTER_DECK_FOLDER
        cache: Dict[str, Tuple[str, Dict[str, Any]]] = {}
        for path in FileManager.ListFiles(STARTER_DECK_FOLDER.value, ext=".json"):
            try:
                deck = Json.Load(path)
                cache[_hero_code(deck["hero"][0])] = (path, deck)
            except Exception:
                continue
        _starter_cache = cache
    return _starter_cache


def _derived_base(code: str, warnings: List[str]) -> Dict[str, Any]:
    """Hero without a starter deck in the package: build hero faces / nemesis / obligation from the card catalogue."""
    from cards.database import CardsDB
    faces = sorted(cid for cid, p in CardsDB.papers.items() if p.type in ("Hero", "AlterEgo") and _hero_code(cid) == code)
    if not faces:
        raise ValueError(f"Héroe desconocido: {code}")
    hero_paper = CardsDB.papers[faces[0]]
    alter_ego = next((CardsDB.papers[f].name for f in faces if CardsDB.papers[f].type == "AlterEgo"), "")
    nemesis = sorted(cid for cid, p in CardsDB.papers.items() if p.set_name == f"{hero_paper.set_name} Nemesis")
    obligations = sorted(cid for cid, p in CardsDB.papers.items() if p.type == "Obligation" and alter_ego and p.desc.get("GiveTo") == alter_ego)
    warnings.append("Este héroe no tiene mazo de inicio en el paquete: obligación y conjunto némesis deducidos del catálogo (una copia de cada carta).")
    return {"version": "0.5.8", "name": hero_paper.name, "metadata": {"url": ""}, "hero": [",".join(faces)], "hero_deck": [],
            "set_aside": [], "obligations": obligations[:1], "nemesis_set": nemesis, "player_deck": []}


def convert(data: Dict[str, Any]) -> Dict[str, Any]:
    """Returns {"deck": <game deck>, "warnings": [...]}. Raises ValueError with a user-readable message."""
    from cards.database import CardsDB
    warnings: List[str] = []

    if not isinstance(data, dict):
        raise ValueError("El contenido no es un mazo (se esperaba un objeto JSON).")
    if "hero" in data and "player_deck" in data:                       # already a deck of this game
        return {"deck": data, "warnings": warnings}

    code = str(data.get("hero_code") or data.get("investigator_code") or "")
    slots = data.get("slots")
    if not code or not isinstance(slots, dict):
        raise ValueError("No parece un mazo de MarvelCDB (faltan «hero_code» o «slots»). ¿Es un mazo privado o no compartido?")

    base_entry = starter_decks().get(code)
    base = copy.deepcopy(base_entry[1]) if base_entry else _derived_base(code, warnings)

    signature: List[str] = []
    player: List[str] = []
    for card_id in sorted(slots, key=str):
        try:
            count = int(slots[card_id])
        except (TypeError, ValueError):
            continue
        card_id = str(card_id)
        if card_id in HACK_SKIP:
            continue
        paper = CardsDB.papers.get(card_id)
        if paper is None:
            warnings.append(f"Carta desconocida en este paquete: {card_id} (x{count}); se omite.")
            continue
        if paper.type in ("Hero", "AlterEgo", "Obligation"):
            continue                                                   # identity / required cards come from the hero base
        if paper.type not in PLAYER_CARD_TYPES:
            warnings.append(f"«{paper.name}» ({card_id}) no es una carta de jugador; se omite.")
            continue
        target = signature if paper.desc.get("Class") == "Hero" else player
        target.extend([card_id] * count)

    if not player:
        warnings.append("El mazo no contiene cartas de jugador.")
    deck = {
        "version": base.get("version", "0.5.8"),
        "name": str(data.get("name") or base.get("name") or "MarvelCDB deck"),
        "metadata": {"url": f"https://marvelcdb.com/decklist/view/{data['id']}" if data.get("id") else ""},
        "hero": base["hero"],
        "hero_deck": signature or base.get("hero_deck", []),
        "set_aside": base.get("set_aside", []),
        "obligations": base.get("obligations", []),
        "nemesis_set": base.get("nemesis_set", []),
        "player_deck": player,
    }
    total = len(deck["hero_deck"]) + len(player)
    if total < 40:
        warnings.append(f"El mazo tiene {total} cartas (el mínimo de las reglas es 40).")
    return {"deck": deck, "warnings": warnings}


def list_heroes() -> List[Dict[str, Any]]:
    """Every hero deck that can be picked in the new game screen: starter decks + the user's own decks."""
    from cards.database import CardsDB
    from engine.file.manager import STARTER_DECK_FOLDER, DECK_FOLDERS
    items: List[Dict[str, Any]] = []
    sources = [("starter", FileManager.ListFiles(STARTER_DECK_FOLDER.value, ext=".json")),
               ("mine", FileManager.ListFiles(*DECK_FOLDERS.value, ext=".json"))]
    for source, paths in sources:
        for path in paths:
            try:
                deck = Json.Load(path)
                face = deck["hero"][0].split(",")[0]
                paper = CardsDB.papers.get(face)
                items.append({"file": path, "name": deck.get("name") or (paper.name if paper else face), "hero": paper.name if paper else "", "sub": (paper.subtitle or "") if paper else "",
                              "pic": face, "source": source, "cards": len(deck.get("hero_deck", [])) + len(deck.get("player_deck", []))})
            except Exception:
                continue
    items.sort(key=lambda i: (i["source"] != "mine", i["name"].lower()))
    return items
