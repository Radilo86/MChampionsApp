"""
`DeviceManager` for the browser. Mirrors `engine/device/manager/web/manager.py` + `engine/device/web/web_device.py`
but, instead of aiohttp servers and websockets, it pushes frames through the `Bridge`.
"""
from core import *
from engine.log import Log
from engine.device.base.device import Device
from engine.device.base.input import InputDevice
from engine.device.base.output import OutputDevice
from engine.device.manager.base import DeviceManager
from engine.browser.runtime import Runtime

CATEGORY_NAME = "BROWSER_DEVICE"


class SocketInfo:
    """One emulated websocket (one open game page)."""

    def __init__(self, sid: int, player_ids: List[int], url: str) -> None:
        self.sid = sid
        self.player_ids = player_ids
        self.url = url

    def __repr__(self) -> str:
        return f"{self.sid} ({self.player_ids})"


class BrowserClientManager:

    def __init__(self) -> None:
        self.sockets: Dict[int, SocketInfo] = {}
        self.client_synced: List[int] = [0] * 4

    def Add(self, sid: int, player_ids: List[int], url: str) -> None:
        self.sockets[sid] = SocketInfo(sid, player_ids, url)
        Log.Info(CATEGORY_NAME, f"[Client] Player {player_ids} connected")

    def Remove(self, sid: int) -> None:
        info = self.sockets.pop(sid, None)
        if info:
            Log.Info(CATEGORY_NAME, f"[Client] Player {info.player_ids} disconnect")

    def GetClients(self, player_id: int) -> List[SocketInfo]:
        return [s for s in self.sockets.values() if player_id in s.player_ids]

    def ClearSync(self) -> None:
        self.client_synced = [0] * 4

    def GetInfo(self) -> List[str]:
        return [s.url for s in self.sockets.values()]


class BrowserDevice(OutputDevice, InputDevice):

    def __init__(self, controller: 'Any', manager: 'BrowserDeviceManager') -> None:
        self.manager_web = manager
        super().__init__(controller, manager)

    @property
    def total_players(self) -> List[int]:
        return list(range(self.controller.manager.total_players))

    @override
    def IsConnect(self) -> bool:
        return self.manager_web.CheckConnect(self.player_id)

    @override
    def IsSyncReady(self) -> bool:
        return self.manager_web.CheckSync(self)

    @override
    def IsInputReady(self) -> bool:
        # Tell every client "go and fetch the options" (same as WebDevice.IsInputReady), then keep waiting.
        #
        # IMPORTANT: send it ONCE per question. With threads the wait predicate was only re-evaluated on notify; in the
        # cooperative runtime it is re-evaluated after every request the page makes, and each evaluation used to push
        # a new frame -> the page fetched the options again -> another request -> another frame... (an endless
        # ping-pong that rebuilt the option buttons all the time and wiped the player's selection).
        manager = self.manager_web
        if manager.ask_frame_sent:
            return False
        manager.ask_frame_sent = True
        for i in self.total_players:
            manager.SendRender(i, "GetInput")
        return False

    @override
    def Render(self) -> None:
        self.manager_web.SendRender(self.controller.player_id, "WaitSync")


class BrowserDeviceManager(DeviceManager):

    def __init__(self) -> None:
        super().__init__()
        self.client_manager = BrowserClientManager()
        self.stat_sent_size: Dict[str, int] = {}
        self.server: 'Any|None' = None   # set by boot.py
        self.ask_frame_sent = False      # see BrowserDevice.IsInputReady

    @override
    def DoGetInput(self, data: 'Any', player_id: int, check: 'Callable[[], bool]'):
        # The game state is consistent right now (the previous decision has been fully resolved):
        # a good moment to refresh the autosave, before blocking for the next decision.
        if self.server is not None:
            self.server.autosave()
        self.ask_frame_sent = False      # a new question: its "GetInput" frame has not been sent yet
        return super().DoGetInput(data, player_id, check)

    @override
    def CreateDevices(self, controller: 'Any') -> Tuple['OutputDevice', 'InputDevice']:
        device = BrowserDevice(controller, self)
        return device, device

    @override
    def OnNewGame(self) -> None:
        super().OnNewGame()
        self.client_manager.ClearSync()
        self.stat_sent_size = {}

    @override
    def OnShutdown(self) -> None:
        pass

    # ------------------------------------------------------------------------------------------------------------
    def KillConnect(self) -> None:
        pass

    def CheckSync(self, device: 'Device') -> bool:
        if not device.is_connected:
            Log.DebugSilent("SYNC", "WaitSync Exit: disconnected")
            return True

        controller = device.controller
        if not controller.world:
            return True
        if not controller.game.state.is_running:
            return True
        if self.client_manager.client_synced[device.player_id] >= controller.world.render.last_render_id:
            return True
        return False

    def ClientUpdateRenderId(self, player_id: int, render_id: int, game_id: int) -> None:
        if player_id >= len(self.controllers):
            return
        if game_id == self.controllers[player_id].game.session.game_id:
            self.client_manager.client_synced[player_id] = render_id
            self.notify.sync.NotifyAll()

    def CheckConnect(self, player_id: int) -> bool:
        return self.client_manager.GetClients(player_id) != []

    def AddSize(self, category: str, byte_size: int) -> None:
        pass

    # ------------------------------------------------------------------------------------------------------------
    @property
    def game(self) -> 'Any':
        return self.controllers[0].game

    @property
    def controller_manager(self) -> 'Any':
        return self.controllers[0].manager

    def SendRender(self, player_id: int, caller: str) -> None:
        """Equivalent of `GameServerSocket.WebSendRender`: push a FrameDescriptor to the clients of `player_id`."""
        from engine.log import Notify
        from engine.lib import Json
        from game.render.descriptor.frame import FrameDescriptor

        if Runtime.bridge is None:
            return
        clients = self.client_manager.GetClients(player_id)
        if not clients:
            return

        notify_texts = Notify.Get()
        game = self.game
        world = game.world
        remaining_time = self.timer.GetRemainingTime() or 0
        data = FrameDescriptor(
            render_id           = world.render.last_render_id if world else 0,
            game_id             = game.session.game_id,
            ask_players         = self.asking_players,
            remaining_time      = remaining_time,
            max_timeout         = self.timer.max_timeout,
            notify_texts        = notify_texts,
            debug_message       = world.render.debug_message if world else "",
            current_step_id     = game.controller_manager.replay.current_step_id,
            max_replay_step_id  = game.controller_manager.replay.GetReplayOperationLen(),
            player_id           = player_id,
            total_players       = world.started_player_num if world else 0,
        )
        Runtime.bridge.frame(player_id, Json.Dumps(data.__dict__))
