"""
No-code card abilities ("reglas").

A card of a content pack can describe what it does with plain Spanish sentences instead of a Python script:

    {"card_id": "99101", "type": "Event", "name": "Golpe certero", "desc": {"Cost": "2"},
     "reglas": ["Acción de héroe (ataque): inflige 4 de daño a un enemigo."]}

Every sentence is   DISPARADOR [(condición)] [, COSTE] : EFECTO [y EFECTO ...]
and is translated into the very same AbilityFactory building blocks the 3,457 official card scripts use, so it behaves
exactly like a scripted card (it can be undone, replayed, saved...). `PHRASES` below is the whole vocabulary; it is also
what the in-app editor (creador.html) offers in its menus. `parse()` gives precise errors with suggestions.
"""
import difflib
import re
import unicodedata
from typing import Any, Callable, Dict, List, Optional, Tuple

# ------------------------------------------------------------------------------------------------------------------- text
NUMBERS = {"un": 1, "una": 1, "uno": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, "seis": 6, "siete": 7, "ocho": 8, "nueve": 9, "diez": 10}
N = r"(\d+|un|una|uno|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez)"
PER = r"( por jugador)?"


def norm(text: str) -> str:
    # quotes first: «» and curly quotes are not ASCII and would vanish below
    text = re.sub("[«»\u201c\u201d]", '"', text)
    t = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii").lower()
    t = re.sub(r"\s+", " ", t).strip()
    return t.rstrip(".").strip()


def expand(text: str) -> str:
    """Spanish contractions: «del plan» -> «de el plan», «al villano» -> «a el villano» (but «al azar» stays)."""
    text = re.sub(r"\bdel\b", "de el", text)
    return re.sub(r"\bal (villano|plan|enemigo|esbirro|aliado|personaje)\b", r"a el \1", text)


def number(word: str) -> int:
    return int(word) if word.isdigit() else NUMBERS[word]


# ------------------------------------------------------------------------------------------------------------------- vocabulary
PLAYER_TYPES = {"Ally", "Event", "Support", "Upgrade", "Resource", "PlayerSideScheme", "Hero", "AlterEgo"}
ENCOUNTER_TYPES = {"Minion", "Treachery", "Attachment", "Environment", "SideScheme", "Obligation", "Villain", "MainScheme"}

TRIGGERS: List[Tuple[str, str]] = [
    (r"accion de heroe(?: \((ataque|frustracion|frustrar)\))?", "hero_action"),
    (r"accion de alter-?ego", "alter_action"),
    (r"accion(?: \((ataque|frustracion|frustrar)\))?", "action"),
    (r"al jugar(?:la|lo|se)?", "action"),
    (r"al entrar en juego", "enter_play"),
    (r"al revelarse(?: \((heroe|alter-?ego)\))?", "revealed"),
    (r"al ser derrotad[oa]", "defeated"),
    (r"potenciacion|boost", "boost"),
]
COSTS = {"agota esta carta": "exhaust_this", "descarta una carta de tu mano": "discard_hand"}

# fixed targets (resolved when the ability resolves) and chosen ones (the player picks, like "an enemy")
FIXED_UNITS = {"el villano": "villain", "cada enemigo": "each_enemy", "cada esbirro": "each_minion", "tu heroe": "your_identity",
               "tu identidad": "your_identity", "tu personaje": "your_identity", "cada heroe": "each_identity",
               "cada identidad": "each_identity", "cada aliado": "each_ally", "esta carta": "this"}
CHOSEN_UNITS = {"un enemigo": "Enemy", "un esbirro": "Minion", "un personaje": "Unit2", "un aliado": "Ally"}
FIXED_SCHEMES = {"el plan principal": "MainScheme", "cada plan": "EachScheme", "cada plan secundario": "EachSideScheme", "esta carta": "this"}
CHOSEN_SCHEMES = {"un plan": "Scheme2", "un plan secundario": "SchemeSide2"}
STATUS = {"aturde": "Stunned", "confunde": "Confused"}

UNIT_T = "(" + "|".join(sorted(list(FIXED_UNITS) + list(CHOSEN_UNITS), key=len, reverse=True)) + ")"
SCHEME_T = "(" + "|".join(sorted(list(FIXED_SCHEMES) + list(CHOSEN_SCHEMES), key=len, reverse=True)) + ")"
NAME = r'["«]([^"»]+)["»]'

# (regex, kind) — the order matters: the first match wins
EFFECTS: List[Tuple[str, str]] = [
    (rf"inflige {N}{PER} (?:puntos? )?de dano a {UNIT_T}", "damage"),
    (rf"cura {N}{PER} (?:puntos? )?de dano (?:a|de) {UNIT_T}", "heal"),
    (rf"(?:quita|retira|elimina) {N}{PER} (?:fichas? )?de amenaza de {SCHEME_T}", "remove_threat"),
    (rf"(?:pon|coloca|anade) {N}{PER} (?:fichas? )?de amenaza en {SCHEME_T}", "place_threat"),
    (rf"cada jugador roba {N} cartas?", "each_draw"),
    (rf"roba {N} cartas?", "draw"),
    (rf"cada jugador descarta {N} cartas? al azar(?: de su mano)?", "each_discard_random"),
    (rf"descarta {N} cartas? al azar(?: de tu mano)?", "discard_random"),
    (rf"(aturde|confunde) a {UNIT_T}", "status"),
    (rf"(?:da|otorga) dureza a {UNIT_T}", "tough"),
    (rf"prepara a {UNIT_T}", "ready"),
    (rf"agota a {UNIT_T}", "exhaust"),
    (r"el villano te ataca", "villain_attacks"),
    (r"el villano ataca a cada jugador", "villain_attacks_each"),
    (r"el villano maquina contra cada jugador", "villain_schemes_each"),
    (r"el villano maquina", "villain_schemes"),
    (rf"cada jugador recibe {N} cartas? de encuentro", "each_encounter"),
    (rf"recibe {N} cartas? de encuentro", "encounter"),
    (r"esta carta gana oleada", "surge"),
    (rf"busca {NAME} en el mazo(?: y la pila de descartes)? de encuentros? y revelala", "search_reveal"),
    (rf"busca {NAME} en el mazo(?: y la pila de descartes)? de encuentros? y ponla en juego(?: enfrentada contigo)?", "search_put"),
    (r"descarta cartas de encuentro hasta (?:revelar |descartar )?un esbirro y ponlo en juego(?: enfrentado contigo)?", "discard_until_minion"),
]

# the vocabulary shown in the docs and in the editor (one example per phrase)
PHRASES: Dict[str, List[str]] = {
    "disparadores": ["Acción", "Acción de héroe", "Acción de héroe (ataque)", "Acción de héroe (frustración)", "Acción de alter-ego",
                     "Al entrar en juego", "Al revelarse", "Al revelarse (héroe)", "Al revelarse (alter-ego)", "Al ser derrotado", "Potenciación"],
    "costes": ["agota esta carta", "descarta una carta de tu mano"],
    "efectos": ["inflige 3 de daño a un enemigo", "inflige 2 de daño a cada enemigo", "inflige 1 de daño a tu héroe", "inflige 1 de daño a cada héroe",
                "cura 2 de daño a un personaje", "cura 3 de daño a tu héroe", "cura 2 de daño al villano",
                "quita 2 de amenaza de un plan", "quita 1 de amenaza del plan principal", "quita 1 de amenaza de cada plan",
                "pon 1 de amenaza en el plan principal", "pon 1 por jugador de amenaza en el plan principal", "pon 2 de amenaza en esta carta",
                "roba 2 cartas", "cada jugador roba 1 carta", "descarta 1 carta al azar", "cada jugador descarta 1 carta al azar",
                "aturde a un enemigo", "confunde al villano", "da dureza a tu héroe", "prepara a tu héroe", "agota a un aliado",
                "el villano maquina", "el villano te ataca", "el villano ataca a cada jugador", "el villano maquina contra cada jugador",
                "recibe 1 carta de encuentro", "cada jugador recibe 1 carta de encuentro", "esta carta gana oleada",
                "busca «Nombre de la carta» en el mazo de encuentros y revélala", "busca «Nombre de la carta» en el mazo de encuentros y ponla en juego",
                "descarta cartas de encuentro hasta un esbirro y ponlo en juego"],
    "objetivos": list(FIXED_UNITS) + list(CHOSEN_UNITS) + list(FIXED_SCHEMES) + list(CHOSEN_SCHEMES),
}
_EXAMPLES_NORM = {expand(norm(p)): p for p in PHRASES["efectos"]}


class RuleError(ValueError):
    pass


def _suggest(text: str, choices: List[str]) -> str:
    near = difflib.get_close_matches(text, choices, n=2, cutoff=0.45)
    return (" ¿Quizá: «" + "» o «".join(near) + "»?") if near else ""


# ------------------------------------------------------------------------------------------------------------------- parsing
def _split_effects(body: str) -> List[str]:
    # protect names in quotes, then split on ";" and " y " / ", y " / ". " between effects
    names: List[str] = []
    def keep(m: 're.Match[str]') -> str:
        names.append(m.group(0)); return f"\x00{len(names) - 1}\x00"
    protected = re.sub(NAME, keep, body)
    # «… y revélala», «… y ponla / ponlo en juego», «el mazo y la pila de descartes» are ONE effect: protect that «y»
    protected = re.sub(r"\s+y\s+(?=(?:rev[eé]lal[ao]|ponl[ao]|la pila))", " \x01 ", protected, flags=re.I)
    parts = re.split(r"\s*;\s*|\s*,?\s+y luego\s+|\s*,?\s+y\s+(?=[a-z])|\.\s+", protected)
    out = []
    for p in parts:
        p = re.sub(r"\x00(\d+)\x00", lambda m: names[int(m.group(1))], p).replace("\x01", "y").strip(" ,.")
        if p: out.append(p)
    return out


def parse(rule: str, card_type: str) -> Dict[str, Any]:
    """'Acción de héroe (ataque): inflige 4 de daño a un enemigo.' -> {trigger, label, condition, costs, effects}"""
    if ":" not in rule:
        raise RuleError(f"falta «:» entre el disparador y el efecto (ej.: «Al revelarse: el villano maquina.»)")
    head_raw, body_raw = rule.split(":", 1)
    head = norm(head_raw)
    parts = [p.strip() for p in head.split(",")]
    trig_txt, cost_txts = parts[0], parts[1:]
    trigger = label = condition = None
    for pat, key in TRIGGERS:
        m = re.fullmatch(pat, trig_txt)
        if m:
            trigger = key
            extra = m.group(1) if m.groups() else None
            if key in ("hero_action", "action") and extra:
                label = "attack" if extra == "ataque" else "thwart"
            if key == "revealed" and extra:
                condition = "Hero" if extra == "heroe" else "Alter-Ego"
            break
    if trigger is None:
        trig = {norm(x): x for x in PHRASES["disparadores"]}
        near = difflib.get_close_matches(trig_txt, list(trig), n=2, cutoff=0.45)
        raise RuleError(f"no conozco el disparador «{head_raw.strip()}»." + ((" ¿Quizá: «" + "» o «".join(trig[x] for x in near) + "»?") if near else ""))
    costs = []
    for c in cost_txts:
        if c not in COSTS:
            raise RuleError(f"no conozco el coste «{c}»." + _suggest(c, list(COSTS)))
        costs.append(COSTS[c])

    # the trigger must make sense for this kind of card
    if trigger in ("hero_action", "alter_action", "action") and card_type in ENCOUNTER_TYPES:
        raise RuleError(f"«{head_raw.strip()}» es para cartas de jugador; una carta de tipo {card_type} usa «Al revelarse», «Al ser derrotado» o «Potenciación».")
    if trigger == "boost" and card_type in PLAYER_TYPES:
        raise RuleError("«Potenciación» es solo para cartas de encuentro.")
    if trigger == "revealed" and card_type in PLAYER_TYPES:
        raise RuleError("«Al revelarse» es para cartas de encuentro, villanos y planes; una carta de jugador usa «Acción» o «Al entrar en juego».")
    if trigger == "defeated" and card_type not in ("Minion", "Ally", "Villain", "SideScheme", "PlayerSideScheme"):
        raise RuleError(f"«Al ser derrotado» solo existe para esbirros, aliados, villanos y planes secundarios (esta carta es {card_type}).")
    if trigger == "enter_play" and card_type in ("Event", "Treachery"):
        raise RuleError(f"una carta de tipo {card_type} no entra en juego: usa «Acción» (evento) o «Al revelarse» (traición).")

    effects = []
    chosen = None
    for e in _split_effects(body_raw):
        en = expand(norm(e))
        for pat, kind in EFFECTS:
            m = re.fullmatch(pat, en)
            if not m:
                continue
            spec: Dict[str, Any] = {"kind": kind, "text": e}
            g = m.groups()
            if kind in ("damage", "heal", "remove_threat", "place_threat"):
                spec["n"], spec["per_player"], spec["target"] = number(g[0]), bool(g[1]), g[2]
            elif kind in ("draw", "each_draw", "discard_random", "each_discard_random", "encounter", "each_encounter"):
                spec["n"] = number(g[0])
            elif kind == "status":
                spec["status"], spec["target"] = STATUS[g[0]], g[1]
            elif kind in ("tough", "ready", "exhaust"):
                spec["target"] = g[0]
            elif kind in ("search_reveal", "search_put"):
                spec["name"] = re.search(NAME, e).group(1).strip()
            # chosen target (only one kind per sentence: the player picks it once)
            tgt = spec.get("target")
            if tgt in CHOSEN_UNITS or tgt in CHOSEN_SCHEMES:
                want = CHOSEN_UNITS.get(tgt) or CHOSEN_SCHEMES.get(tgt)
                if kind in ("remove_threat", "place_threat") and tgt in CHOSEN_UNITS:
                    raise RuleError(f"la amenaza va en un plan, no en «{tgt}».")
                if kind not in ("remove_threat", "place_threat") and tgt in CHOSEN_SCHEMES:
                    raise RuleError(f"«{tgt}» es un plan: solo se le puede poner o quitar amenaza.")
                if chosen and chosen[0] != want:
                    raise RuleError("en una misma regla solo se puede elegir UN objetivo (p. ej. «un enemigo»); crea otra regla para el segundo.")
                chosen = (want, kind)
            if kind == "surge" and card_type not in ENCOUNTER_TYPES:
                raise RuleError("«esta carta gana oleada» es para cartas de encuentro.")
            effects.append(spec)
            break
        else:
            near = difflib.get_close_matches(en, list(_EXAMPLES_NORM), n=2, cutoff=0.45)
            hint = (" ¿Quizá: «" + "» o «".join(_EXAMPLES_NORM[x] for x in near) + "»?") if near else " Mira la lista de efectos en COMO_AÑADIR_CONTENIDO.md."
            raise RuleError(f"no entiendo el efecto «{e}»." + hint)
    if not effects:
        raise RuleError("después de «:» falta el efecto.")
    return {"trigger": trigger, "label": label, "condition": condition, "costs": costs, "effects": effects, "chosen": chosen, "text": rule}


# ------------------------------------------------------------------------------------------------------------------- runtime
def _player(effect: Any, message: Any, this: Any) -> Any:
    from game.operate.worlds import Worlds
    for get in (lambda: message.GetToPlayer(), lambda: effect.GetInitiator(), lambda: this.GetEngagedPlayer(), lambda: this.GetController()):
        try:
            p = get()
            if p is not None and hasattr(p, "GetIdentity"):
                return p
        except Exception:
            pass
    return Worlds.GetFirstPlayer(effect)


def _units(target: str, effect: Any, this: Any, player: Any) -> List[Any]:
    import cards.pack as P
    W = P.Worlds
    key = FIXED_UNITS.get(target)
    if target in CHOSEN_UNITS:
        return list(effect.targets)
    if key == "villain":
        v = W.FindVillain(effect); return [v] if v else []
    if key == "each_enemy": return list(W.GetOnFieldEnemies(effect))
    if key == "each_minion": return list(W.GetOnFieldMinions(effect))
    if key == "your_identity": return [player.GetIdentity()] if player else []
    if key == "each_identity": return [p.GetIdentity() for p in W.GetPlayers(effect)]
    if key == "each_ally": return [x for x in W.GetOnFieldFriendlyCharacters(effect) if P.Ally.IsType(x)]
    if key == "this": return [this]
    return []


def _schemes(target: str, effect: Any, this: Any) -> Any:
    if target in CHOSEN_SCHEMES:
        return list(effect.targets)
    lit = FIXED_SCHEMES[target]
    return [this] if lit == "this" else lit


def _run(spec: Dict[str, Any], effect: Any, message: Any, this: Any, player: Any) -> None:
    import cards.pack as P
    W, F = P.Worlds, P.Faces
    kind = spec["kind"]
    n = spec.get("n", 1)
    if spec.get("per_player"):
        n *= max(1, len(W.GetPlayers(effect)))
    if kind == "damage":
        units = _units(spec["target"], effect, this, player)
        if units: this.DealDamage(units, n, effect)
    elif kind == "heal":
        units = _units(spec["target"], effect, this, player)
        if units: this.HealthUnits(units, n, effect)
    elif kind == "remove_threat":
        tgt = _schemes(spec["target"], effect, this)
        if spec["target"] == "cada plan secundario": tgt = list(W.GetSideSchemes(effect))
        if tgt: this.RemoveThreatFromSchemes(tgt, n, effect)
    elif kind == "place_threat":
        tgt = _schemes(spec["target"], effect, this)
        if tgt: this.PlaceThreatOnSchemes(tgt, n, effect)
    elif kind == "draw":
        if player: player.DrawUp(n, effect)
    elif kind == "each_draw":
        for p in W.GetPlayers(effect): p.DrawUp(n, effect)
    elif kind == "discard_random":
        if player: player.DiscardRandomHandCards(n, effect)
    elif kind == "each_discard_random":
        for p in W.GetPlayers(effect): p.DiscardRandomHandCards(n, effect)
    elif kind == "status":
        units = _units(spec["target"], effect, this, player)
        if units: F.GiveStatus(units, spec["status"], effect)
    elif kind == "tough":
        units = _units(spec["target"], effect, this, player)
        if units: F.GiveStatus(units, "Tough", effect)
    elif kind == "ready":
        units = _units(spec["target"], effect, this, player)
        if units: F.ReadyAll(units, effect)
    elif kind == "exhaust":
        units = _units(spec["target"], effect, this, player)
        if units: F.ExhaustAll(units, effect)
    elif kind in ("villain_schemes", "villain_attacks", "villain_schemes_each", "villain_attacks_each"):
        villain = W.FindVillain(effect)
        if not villain: return
        targets = W.GetPlayers(effect) if kind.endswith("_each") else [player]
        for p in targets:
            if p is None: continue
            if kind.startswith("villain_schemes"): villain.DoSchemes(p, effect)
            else: villain.DoAttackYou(p, effect)
    elif kind == "encounter":
        if player: player.DealEncounterCards(n, effect)
    elif kind == "each_encounter":
        for p in W.GetPlayers(effect): p.DealEncounterCards(n, effect)
    elif kind == "surge":
        this.GainSurge(1, effect)
    elif kind in ("search_reveal", "search_put"):
        face = P.Search.EncounterCard(effect, include_discard_pile=True, name=spec["name"])
        if face:
            if kind == "search_reveal": face.Reveal(player, effect)
            else: face.PutIntoPlay(player, effect)
    elif kind == "discard_until_minion":
        face = W.DiscardEncounterCardsUntil(effect, card_type=P.Minion)
        if face: face.PutIntoPlay(player or W.GetFirstPlayer(effect), effect)


TARGET_FILTER = {"damage": {}, "heal": {"canbe_heal": True}, "Stunned": {"canbe_stunned": True}, "Confused": {"canbe_confused": True},
                 "tough": {"canbe_tough": True}, "ready": {"canbe_ready": True}, "exhaust": {"canbe_exhaust": True},
                 "place_threat": {"can_place_threat": True}, "remove_threat": {}}


def build(parsed: Dict[str, Any], card_type: str) -> Any:
    """One parsed sentence -> one Ability (same building blocks as the official card scripts)."""
    import cards.pack as P
    AF, AT = P.AbilityFactory, P.AbilityType
    specs = parsed["effects"]

    def resolve(effect: Any, message: Any) -> None:
        this = effect.this
        player = _player(effect, message, this)
        for spec in specs:
            _run(spec, effect, message, this, player)

    t = parsed["trigger"]
    if t in ("action", "hero_action", "alter_action"):
        kind = {"action": AT.Action, "hero_action": AT.HeroAction, "alter_action": AT.AlterEgoAction}[t]
        ability = AF.WhenInYourPlayTurn(kind, resolve)
        if card_type == "Event":
            ability = ability.SetPlay()
        if parsed["label"]:
            ability = ability.SetLabel(parsed["label"])
    elif t == "enter_play":
        ability = AF.WhenThisRevealed(None, resolve) if card_type in ENCOUNTER_TYPES else AF.AfterCardEnterPlay(AT.Response, "This", resolve)
    elif t == "revealed":
        ability = AF.WhenThisRevealed(parsed["condition"], resolve)
    elif t == "defeated":
        if card_type in ("SideScheme", "PlayerSideScheme"):
            ability = AF.WhenSchemeBeDefeated(AT.WhenDefeated, "This", resolve)
        else:
            ability = AF.WhenUnitBeDefeated(AT.WhenDefeated, "This", resolve)
    elif t == "boost":
        ability = AF.WhenCardBecomeBoost("This", resolve)
    else:
        raise RuleError(f"disparador desconocido {t}")
    for c in parsed["costs"]:
        ability = ability.SetCostFunc(P.CostFunc.Exhaust("This") if c == "exhaust_this" else P.CostFunc.Discard("YourHandCards"))
    if parsed["chosen"]:
        type_name, kind = parsed["chosen"]
        target_type = getattr(P, type_name)
        spec = next(s for s in specs if s["kind"] == kind)
        kw = TARGET_FILTER.get(spec.get("status", kind), {})
        ability = ability.SetTarget(target_type, **kw)
    return ability


def compile_rules(rules: List[str], card_type: str) -> List[Any]:
    return [build(parse(r, card_type), card_type) for r in rules]


def check_rules(rules: Any, card_type: str) -> Tuple[List[str], List[str]]:
    """Validation for content packs: (errors, warnings)."""
    errors: List[str] = []
    warnings: List[str] = []
    if not isinstance(rules, list) or not all(isinstance(r, str) for r in rules):
        return ["\"reglas\" debe ser una lista de frases"], warnings
    for i, r in enumerate(rules, 1):
        try:
            parsed = parse(r, card_type)
            build(parsed, card_type)
            if parsed["trigger"] == "revealed" and card_type in ("Villain", "MainScheme") and any(
                    e["kind"] in ("draw", "each_draw", "discard_random", "each_discard_random") for e in parsed["effects"]):
                warnings.append(f"regla {i}: el primer villano y el primer plan principal se revelan en la PREPARACIÓN, cuando los mazos "
                                f"de los jugadores aún están vacíos: robar o descartar ahí puede eliminar a los jugadores. Úsalo solo en fases posteriores.")
            if parsed["trigger"] == "action" and card_type in ("Support", "Ally", "Upgrade") and not parsed["costs"]:
                warnings.append(f"regla {i}: una «Acción» sin coste se puede usar sin límite; añade «, agota esta carta» antes de «:».")
        except RuleError as exc:
            errors.append(f"regla {i} («{r.strip()[:60]}»): {exc}")
        except Exception as exc:
            errors.append(f"regla {i}: no se pudo construir ({type(exc).__name__}: {exc})")
    return errors, warnings


# ------------------------------------------------------------------------------------------------------------------- registry
_registry: Optional[Dict[str, Tuple[List[str], str]]] = None


def registry() -> Dict[str, Tuple[List[str], str]]:
    """card id -> (rules, type), read from the card catalogues of the installed content packs."""
    global _registry
    if _registry is None:
        import json
        from engine.browser import content
        reg: Dict[str, Tuple[List[str], str]] = {}
        for path in content.custom_card_files():
            try:
                for cards in json.load(open(path, encoding="utf-8")).values():
                    if isinstance(cards, list):
                        for c in cards:
                            if isinstance(c, dict) and c.get("reglas"):
                                reg[str(c.get("card_id"))] = (list(c["reglas"]), str(c.get("type", "")))
            except Exception:
                pass
        _registry = reg
    return _registry


def abilities_for(card_id: str) -> 'Optional[List[Any]]':
    entry = registry().get(card_id)
    if not entry:
        return None
    return compile_rules(entry[0], entry[1])
