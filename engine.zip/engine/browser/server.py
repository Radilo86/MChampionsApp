"""
In-process replacement of the aiohttp server of the desktop version.

`BrowserServer.dispatch(message)` receives messages posted by the page (see `engine/browser/runtime.py`) and answers
them through the `Bridge`. Every route of `engine/device/web/server/*.py` is implemented here with identical semantics.
"""
import json
import os
import time
from urllib.parse import urlsplit, unquote_plus
from typing import Any, Callable, Dict, List, Optional, Tuple

from core import *
from build import Build
from engine.config import ConfigVariables
from engine.lib import Json, Ver
from engine.log import Log
from engine.file import FileManager
from engine.browser.runtime import Runtime
from engine.browser.device import BrowserDeviceManager

CATEGORY_NAME = "BROWSER_SERVER"

READ_ONLY_FIRST_REPLAY_FOLDER   = ConfigVariables.Bool('read_only_first_replay_folder', True)
CARDS_JSON_FILE                 = ConfigVariables.File('cards_json_file')
REPLAY_FOLDERS                  = ConfigVariables.Folders('replay_folders')
DECK_FOLDERS                    = ConfigVariables.Folders('deck_folders')
STARTER_DECK_FOLDER             = ConfigVariables.Folder('starter_deck_folder')
ENCOUNTER_SETS_FOLDERS          = ConfigVariables.Folders('encounter_sets_folders')
SCENARIOS_FOLDERS               = ConfigVariables.Folders('scenarios_folders')
CUSTOM_SCENARIOS_FOLDER         = ConfigVariables.Folder('custom_scenario_folder')
PUZZLE_FOLDER                   = ConfigVariables.Folder('puzzle_folder')
PUZZLE_TEST_FOLDER              = ConfigVariables.Folder('puzzle_test_folder')

AUTOSAVE_FILE = "replays/autosave.json"


class Request:
    def __init__(self, method: str, url: str, body: str = "") -> None:
        parts = urlsplit(url)
        path = parts.path
        # The page may be served from a sub-folder (GitHub pages...): only the last route name matters.
        self.path = "/" + path.strip("/").split("/")[-1] if path.strip("/") else "/"
        self.method = method.upper()
        self.raw_query = parts.query
        self.query_string = unquote_plus(parts.query)
        self.query: Dict[str, str] = {}
        for pair in parts.query.split("&"):
            if not pair:
                continue
            key, _, value = pair.partition("=")
            key = unquote_plus(key)
            if key not in self.query:
                self.query[key] = unquote_plus(value)
        self.body = body


class Response:
    def __init__(self, body: Any = "", status: int = 200, content_type: str = "text/plain") -> None:
        self.body = body
        self.status = status
        self.content_type = content_type


def JsonResponse(obj: Any, status: int = 200) -> Response:
    return Response(json.dumps(obj), status, "application/json")


class BrowserServer:

    def __init__(self, device_manager: BrowserDeviceManager) -> None:
        self.device_manager = device_manager
        self.json_cache: Dict[str, str] = {}
        self.autosave_enabled = True
        self.autosave_dirty = False
        self.routes: Dict[str, Callable[[Request], Response]] = {
            '/list_file': self.list_file,
            '/list_scenarios': self.list_scenarios,
            '/list_encounter_sets': self.list_encounter_sets,
            '/list_deck': self.list_deck,
            '/list_starter_deck': self.list_starter_deck,
            '/list_replay_files': self.list_replay_files,
            '/list_puzzle_files': self.list_puzzle_files,
            '/list_puzzle_test_files': self.list_puzzle_test_files,
            '/read_file': self.read_file,
            '/get_encounter_set_json': self.get_encounter_set_json,
            '/get_scenario_json': self.get_scenario_json,
            '/get_hero_json': self.get_hero_json,
            '/get_sets_json': self.get_sets_json,
            '/get_sets_custom_scenario': self.get_sets_custom_scenario,
            '/get_cards_json': self.get_cards_json,
            '/get_translate_json': self.get_translate_json,
            '/get_card_json': self.get_card_json,
            '/get_completion_rate': self.get_completion_rate,
            '/get_statistics': self.get_statistics,
            '/get_session_statistics': self.get_session_statistics,
            '/get_play_scene_name': self.get_play_scene_name,
            '/get_max_timeout': self.get_max_timeout,
            '/get_puzzle_json': self.get_puzzle_json,
            '/get_replay_json': self.get_replay_json,
            '/get_gamers': self.get_gamers,
            '/get_version': self.get_version,
            '/new': self.new_game,
            '/new_debug': self.new_debug,
            '/load_replay': self.load_replay,
            '/load_replay_data': self.load_replay_data,
            '/save_replay_data': self.save_replay_data,
            '/load_puzzle': self.load_puzzle,
            '/new_puzzle_replay': self.new_puzzle_replay,
            '/new_puzzle': self.new_puzzle,
            '/new_game_online': self.not_available,
            '/new_game_lan': self.not_available,
            '/debug': self.handle_debug_command,
            '/client_updated': self.handle_client_updated,
            '/get_ask': self.handle_get_ask,
            '/get_world': self.handle_get_world,
            '/post': self.handle_post,
            # Added for the offline app
            '/autosave_info': self.autosave_info,
            '/load_autosave': self.load_autosave,
            '/delete_replay': self.delete_replay,
            '/save_deck': self.save_deck,
            '/delete_deck': self.delete_deck,
            '/list_heroes': self.list_heroes,
            '/convert_marvelcdb': self.convert_marvelcdb,
        }

    # ================================================================================================================
    # Dispatch
    @property
    def game(self) -> 'Any':
        return self.device_manager.game

    @property
    def controller_manager(self) -> 'Any':
        return self.device_manager.controller_manager

    def dispatch(self, message: Dict[str, Any]) -> None:
        kind = message.get("kind")
        bridge = Runtime.bridge
        assert bridge is not None
        if kind == "http":
            request = Request(message.get("method", "GET"), message["url"], message.get("body") or "")
            handler = self.routes.get(request.path)
            if handler is None:
                bridge.respond(message["id"], 404, "text/plain", f"Not found: {request.path}")
                return
            response = handler(request)
            bridge.respond(message["id"], response.status, response.content_type, response.body)
        elif kind == "ws_open":
            self.ws_open(message["sid"], message.get("query", ""))
        elif kind == "ws_message":
            self.ws_message(message["sid"], message.get("data", ""))
        elif kind == "ws_close":
            self.device_manager.client_manager.Remove(message["sid"])
        elif kind == "files":
            # Files restored from IndexedDB at boot (decks, replays, statistics...)
            for path, data in message.get("files", {}).items():
                restore_file(path, data)
        elif kind == "ping":
            if "id" in message:
                bridge.respond(message["id"], 200, "text/plain", "pong")
        else:
            Log.Warn(CATEGORY_NAME, f"Unknown message kind: {kind}")

    # ================================================================================================================
    # Helpers
    def get_player_ids(self, request: Request) -> List[int]:
        if 'hot_seat' in request.query or ('hot_seat' in request.raw_query):
            return list(range(self.controller_manager.total_players))
        p = request.query.get('p', '0')
        if p == '':
            return [0]
        ids = [int(x) for x in p.split(',') if x != '']
        return ids or [0]

    def get_first_controller(self, request: Request) -> 'Any':
        return self.device_manager.controllers[self.get_player_ids(request)[0]]

    def read_json_file(self, file_path: 'str|None', *, do_cache: bool = True) -> Response:
        if not file_path:
            return JsonResponse({})
        if do_cache and file_path in self.json_cache:
            return Response(self.json_cache[file_path], 200, "application/json")
        text = Json.Dumps(Json.Load(file_path))
        if do_cache:
            self.json_cache[file_path] = text
        return Response(text, 200, "application/json")

    def list_file_response(self, *folders: str, ext: 'str|None' = None) -> Response:
        return JsonResponse(FileManager.ListFiles(*folders, ext=ext))

    # ================================================================================================================
    # GET: data
    def list_file(self, r: Request) -> Response:
        return self.list_file_response(r.path)

    def list_scenarios(self, r: Request) -> Response:
        return self.list_file_response(*SCENARIOS_FOLDERS.value, CUSTOM_SCENARIOS_FOLDER.value)

    def list_encounter_sets(self, r: Request) -> Response:
        return self.list_file_response(*ENCOUNTER_SETS_FOLDERS.value)

    def list_deck(self, r: Request) -> Response:
        return self.list_file_response(*DECK_FOLDERS.value, ext=".json")

    def list_starter_deck(self, r: Request) -> Response:
        return self.list_file_response(STARTER_DECK_FOLDER.value)

    def list_replay_files(self, r: Request) -> Response:
        if READ_ONLY_FIRST_REPLAY_FOLDER.value:
            return self.list_file_response(REPLAY_FOLDERS.value[0])
        return self.list_file_response(*REPLAY_FOLDERS.value)

    def list_puzzle_files(self, r: Request) -> Response:
        return self.list_file_response(PUZZLE_FOLDER.value)

    def list_puzzle_test_files(self, r: Request) -> Response:
        return self.list_file_response(PUZZLE_TEST_FOLDER.value)

    def read_replay_file(self, file_path: str) -> Response:
        from game.scene.scene import Scene
        replay, checksum = Json.LoadAsInternal(file_path, Scene)
        return JsonResponse({
            "version": replay.version,
            "is_puzzle": replay.is_puzzle,
            "time": replay.time,
            "cover": replay.cover,
            "path": replay.path,
            "comment": replay.comment,
            "villain": replay.campaign.villain[0] if replay.campaign.villain else replay.campaign.schemes[0],
            "players": [x.hero[0] for x in replay.players],
            "seed": replay.seed,
            "checksum": checksum == "Ok",
            "author": "",
            "step": len(replay.inputs),
        })

    def read_puzzle_file(self, file_path: str) -> Response:
        from game.puzzle.puzzle_data import PuzzleData
        puzzle, checksum = Json.LoadAsInternal(file_path, PuzzleData)
        return JsonResponse({
            "version": puzzle.version,
            "is_puzzle": True,
            "time": "",
            "cover": puzzle.cover,
            "path": file_path,
            "comment": puzzle.comment,
            "villain": puzzle.villain[0],
            "players": [puzzle.players[0].identities[0]],
            "seed": puzzle.seed,
            "checksum": checksum == "Ok",
            "author": puzzle.author,
            "step": 0,
        })

    def read_file(self, r: Request) -> Response:
        return self.read_json_file(r.query_string)

    def get_encounter_set_json(self, r: Request) -> Response:
        return self.read_json_file(FileManager.FindJsonPath("EncounterSet", r.query_string))

    def get_scenario_json(self, r: Request) -> Response:
        return self.read_json_file(FileManager.FindJsonPath("Campaign", r.query_string))

    def get_hero_json(self, r: Request) -> Response:
        # Decks written by the user must never be served from a stale cache
        return self.read_json_file(FileManager.FindJsonPath("Hero", r.query_string), do_cache=False)

    def get_sets_json(self, r: Request) -> Response:
        return self.read_json_file(FileManager.FindJsonPath("SetInfo", "sets_info.json"))

    def get_sets_custom_scenario(self, r: Request) -> Response:
        return JsonResponse(FileManager.ListFiles(CUSTOM_SCENARIOS_FOLDER.value, ".json"))

    def get_cards_json(self, r: Request) -> Response:
        return self.read_json_file(CARDS_JSON_FILE.value)

    def get_translate_json(self, r: Request) -> Response:
        from engine.lib import TransText
        return self.read_json_file(TransText.translate_file)

    def get_card_json(self, r: Request) -> Response:
        from cards.database import CardsDB
        paper = CardsDB.FindCardPaper(r.query_string)
        return Response(Json.Dumps(paper), 200, "application/json")

    def get_completion_rate(self, r: Request) -> Response:
        return Response(str(self.game.statistics.completion_rate))

    def get_statistics(self, r: Request) -> Response:
        return JsonResponse(self.game.statistics.content.data)

    def get_session_statistics(self, r: Request) -> Response:
        stats = getattr(self.game.session, "statistics", None)
        return JsonResponse(stats.dic if stats else {})

    def get_play_scene_name(self, r: Request) -> Response:
        controller = self.get_first_controller(r)
        return Response(controller.world.scene.name if controller.world else "")

    def get_max_timeout(self, r: Request) -> Response:
        return Response(str(self.device_manager.timer.max_timeout))

    def get_puzzle_json(self, r: Request) -> Response:
        file = FileManager.FindJsonPath("Puzzle", r.query_string)
        assert file
        return self.read_puzzle_file(file)

    def get_replay_json(self, r: Request) -> Response:
        file = FileManager.FindJsonPath("Replay", r.query_string)
        assert file
        return self.read_replay_file(file)

    def get_gamers(self, r: Request) -> Response:
        if self.game.state.is_running:
            return Response(str(self.controller_manager.total_players))
        return Response("0")

    def get_version(self, r: Request) -> Response:
        return Response(Ver.ui_version_str)

    def not_available(self, r: Request) -> Response:
        return JsonResponse({'error': 'Not available in the offline app'}, 404)

    # ================================================================================================================
    # New game / replay
    def new_debug(self, r: Request) -> Response:
        self.game.Restart()
        return JsonResponse({'result': "New game created"})

    def new_game(self, r: Request) -> Response:
        from game.game_run.game_new import NewGameDescriptor
        new_game = Json.LoadsAs(r.query.get('data', ""), NewGameDescriptor)
        self.game.NewGame(new_game)
        self.autosave_dirty = False
        return JsonResponse({'result': "New game created"})

    def load_replay(self, r: Request) -> Response:
        self.game.LoadReplay(r.query_string)
        return JsonResponse({'result': "New game created"})

    def load_replay_data(self, r: Request) -> Response:
        from game.scene.scene import Scene
        data = json.loads(r.body) if r.body else {}
        replay_data = data.get('data', None)
        try:
            step: 'int|None' = int(r.query_string)
        except Exception:
            step = None
        if replay_data is None:
            return JsonResponse({'error': 'No data provided'}, 400)
        scene = Json.LoadsAs(replay_data, Scene)
        state = 'Replay' if step == 0 else 'Load'
        self.game.session.LoadScene(scene, step, state)
        return JsonResponse({'result': "New game created"})

    def save_replay_data(self, r: Request) -> Response:
        data = Json.SaveString(self.game.scene, ignore_check_sum=False)
        # The desktop server answered `Json.DumpGZip(data)` with `data` being a *str*, i.e. a JSON string literal.
        # The page does `await response.json()` and writes that string to the file, so keep the same shape.
        return Response(json.dumps(data), 200, "application/json")

    def play_puzzle(self, puzzle: 'Any') -> None:
        from game.scene.scene import Scene
        puzzle_pre_command: List[str] = []

        def get_cards_text(cards: List[str]) -> str:
            return ",".join(f"'{x}'" for x in cards)

        def append_puzzle_command(command: str, cards: List[str]) -> None:
            text = get_cards_text(cards)
            if text:
                puzzle_pre_command.append(f"{command}({text})")

        append_puzzle_command("Puzzle.CreateEncounterDeck", puzzle.encounter_deck)
        append_puzzle_command("Puzzle.CreateEncounterDiscardPile", puzzle.encounter_discard_pile)
        append_puzzle_command("Puzzle.CreateHandCards", puzzle.players[0].hand_cards)
        append_puzzle_command("Puzzle.CreatePlayerDiscardPile", puzzle.players[0].player_discard_pile)
        append_puzzle_command("Puzzle.CreatePlayerDeck", puzzle.players[0].player_deck)
        append_puzzle_command("Puzzle.CreatePlayerAdditionalDeck", puzzle.players[0].set_aside)

        puzzle_data = {
            "version": puzzle.version,
            "metadata": {"seed": puzzle.seed, "comment": puzzle.comment, "cover": puzzle.cover, "is_puzzle": True},
            "campaign": {
                "version": puzzle.version, "name": "Villain", "villain": puzzle.villain, "expert": puzzle.expert,
                "schemes": puzzle.schemes, "set_aside": puzzle.set_aside, "encounters": [],
                "encounter_sets": [], "modular_sets": []
            },
            "players": [
                {
                    "version": puzzle.version, "name": f"Player {index}", "hero": puzzle.players[index].identities,
                    "hero_deck": [], "obligations": [], "nemesis_set": [],
                    "set_aside": puzzle.players[index].set_aside, "player_deck": []
                }
                for index in range(len(puzzle.players))
            ],
            "puzzle": puzzle_pre_command + puzzle.puzzle_command,
        }
        scene = Json.LoadsAs(Json.Dumps(puzzle_data), Scene)
        scene.UpdateVersion()
        self.game.session.LoadScene(scene, None, 'Replay')
        self.controller_manager.skip.SetSkipTo(0)

    def load_puzzle(self, r: Request) -> Response:
        from game.puzzle.puzzle_data import PuzzleData
        puzzle = Json.LoadsAs(r.query_string, PuzzleData)
        self.play_puzzle(puzzle)
        return JsonResponse({'result': "New game created"})

    def new_puzzle_replay(self, r: Request) -> Response:
        from game.scene.scene import Scene
        scene = Json.LoadsAs(r.query_string, Scene)
        scene.UpdateVersion()
        self.game.session.LoadScene(scene, None, 'Replay')
        self.controller_manager.skip.SetSkipTo(0)
        return JsonResponse({'result': "New game created"})

    def new_puzzle(self, r: Request) -> Response:
        from game.puzzle.puzzle_data import PuzzleData
        puzzle = Json.LoadsAs(r.query_string, PuzzleData)
        self.play_puzzle(puzzle)
        return JsonResponse({'result': "New game created"})

    # ================================================================================================================
    # Synchronisation with the page (get_world / get_ask / post / client_updated / debug)
    def handle_debug_command(self, r: Request) -> Response:
        controller = self.get_first_controller(r)
        controller_manager = controller.manager
        debug_cmd = Unquote(r.query_string)
        controller_manager.console.SetCommand(debug_cmd, controller.world)
        if controller_manager.console.debug_cmds or \
            controller_manager.console.debug_break or \
            controller_manager.skip.is_skipping or \
            controller_manager.skip.skip_to > 0 or \
            controller_manager.replay.is_updated:
            self.device_manager.ExitWait()
        return Response(debug_cmd)

    def handle_client_updated(self, r: Request) -> Response:
        render_id = int(r.query.get('r', 0))
        game_id = int(r.query.get('g', 0))
        for player_id in self.get_player_ids(r):
            self.device_manager.ClientUpdateRenderId(player_id, render_id, game_id)
        return Response("", 200)

    def handle_get_ask(self, r: Request) -> Response:
        dm = self.device_manager
        if dm.asking_players == []:
            return JsonResponse({})
        data = None
        for player_id in self.get_player_ids(r):
            if player_id in dm.asking_players:
                if data is None:
                    data = asdict(dm.ask_options[player_id])
                else:
                    list1 = Json.LoadsAs(data['options_json'], List[Any])
                    list2 = Json.LoadsAs(asdict(dm.ask_options[player_id])['options_json'], List[Any])
                    data['options_json'] = Json.Dumps(list1 + list2)
        if data is None:
            return JsonResponse({})
        return Response(json.dumps(data), 200, "application/json")

    def handle_get_world(self, r: Request) -> Response:
        controller = self.get_first_controller(r)
        if controller.world:
            data = controller.world.render.descriptor
        else:
            # If we returned {}, the ts code would read null and crash
            from game.render.descriptor.world import WorldDescriptor
            data = WorldDescriptor()
        return Response(Json.Dumps(data), 200, "application/json")

    def handle_post(self, r: Request) -> Response:
        from engine.browser.validate import validate_decision
        post_json = Unquote(r.body)
        player_ids = self.get_player_ids(r)
        assert len(player_ids) == 1
        if post_json:
            for player_id in player_ids:
                if player_id in self.device_manager.asking_players:
                    reason = validate_decision(self.device_manager.ask_options[player_id].options_json, post_json)
                    if reason:
                        # Certainly invalid (stale / duplicated tap, unpaid cost...): do NOT let it reach the engine, whose
                        # controller would apply part of it before rejecting it. Ask the page to refresh the question.
                        Log.Warn(CATEGORY_NAME, f"Decision ignored: {reason}")
                        if Runtime.bridge is not None:
                            Runtime.bridge.log(f"[decision ignored] {reason}")
                        self.device_manager.ask_frame_sent = False
                        self.device_manager.SendRender(player_id, "GetInput")
                        self.device_manager.ask_frame_sent = True
                        return JsonResponse({"ignored": reason})
                    self.device_manager.WhenInput(post_json, player_id)
                    self.autosave_dirty = True
        return Response("", 200)

    # ================================================================================================================
    # WebSocket emulation
    def ws_open(self, sid: int, query: str) -> None:
        request = Request("GET", "ws?" + query)
        player_ids = self.get_player_ids(request)
        self.device_manager.client_manager.Add(sid, player_ids, query)
        if Build.release and ('debug' in request.query or 'show' in request.query):
            self.game.statistics.SetPause(True)
        self.controller_manager.replay.SetIsReplay('replay' in request.query)

    def ws_message(self, sid: int, data: str) -> None:
        if 'mouse_position' in data:
            return  # a single device: nobody to show our cursor to
        if data.startswith('Connected'):
            info = self.device_manager.client_manager.sockets.get(sid)
            if info and len(info.player_ids) > 0:
                self.device_manager.SendRender(info.player_ids[0], "websocket_handler")
            self.device_manager.notify.connect.NotifyAll()

    # ================================================================================================================
    # Offline-app extras: autosave, saved replays, user decks
    def autosave(self) -> None:
        """Called by the device manager right before the engine blocks waiting for a decision."""
        if not self.autosave_enabled or not self.autosave_dirty:
            return
        self.autosave_dirty = False
        try:
            game = self.game
            if not game.state.is_running or game.world is None or game.world.is_game_over:
                return
            if game.controller_manager.skip.is_skipping or game.controller_manager.replay.is_replay or game.scene.is_puzzle:
                return
            if game.controller_manager.replay.current_step_id < 1:
                return
            data = game.session.DumpSave()
            if os.environ.get("MARVEL_TRACE_AUTOSAVE"):
                Runtime.bridge.log(f"[autosave] step={game.controller_manager.replay.current_step_id} inputs={len(game.scene.inputs)}")
            FileManager.MakeDir("./replays")
            with FileManager.OpenFile("./" + AUTOSAVE_FILE, write=True) as file:
                file.Write(data)
        except Exception as exc:
            Log.FailedTrace(CATEGORY_NAME, exc, no_take_as_error=True)
            if Runtime.bridge is not None:
                Runtime.bridge.log(f"[autosave] FAILED: {exc!r}")

    def autosave_info(self, r: Request) -> Response:
        path = "./" + AUTOSAVE_FILE
        if not FileManager.Exists(path):
            return JsonResponse({})
        try:
            return self.read_replay_file(path)
        except Exception as exc:
            Log.FailedTrace(CATEGORY_NAME, exc, no_take_as_error=True)
            return JsonResponse({})

    def load_autosave(self, r: Request) -> Response:
        from game.scene.scene import Scene
        path = "./" + AUTOSAVE_FILE
        if not FileManager.Exists(path):
            return JsonResponse({'error': 'No autosave'}, 404)
        with FileManager.OpenFile(path, read=True) as file:
            text = file.Read()
        scene = Json.LoadsAs(text, Scene)
        scene.UpdateVersion()
        self.game.session.LoadScene(scene, -1, 'Load')  # resume exactly at the saved decision
        self.autosave_dirty = False
        return JsonResponse({'result': "Loaded"})

    def delete_replay(self, r: Request) -> Response:
        name = FileManager.GetBaseName(r.query_string)
        path = FileManager.JoinPath(REPLAY_FOLDERS.value[0], name)
        if FileManager.Exists(path) and name.endswith(".json"):
            FileManager.Delete(path)
            return JsonResponse({'result': 'deleted'})
        return JsonResponse({'error': 'not found'}, 404)

    def save_deck(self, r: Request) -> Response:
        """POST {name, data} -> ./deck/<name>.json (stored in IndexedDB by the host)."""
        body = json.loads(r.body or "{}")
        name = FileManager.SanitizeFilename(str(body.get('name', 'deck'))) or 'deck'
        data = body.get('data')
        if isinstance(data, (dict, list)):
            data = json.dumps(data, indent=4)
        if not isinstance(data, str):
            return JsonResponse({'error': 'No data'}, 400)
        json.loads(data)  # must be valid JSON
        FileManager.MakeDir("./deck")
        with FileManager.OpenFile(f"./deck/{name}.json", write=True) as file:
            file.Write(data)
        return JsonResponse({'result': 'saved', 'path': f"./deck/{name}.json"})

    def delete_deck(self, r: Request) -> Response:
        name = FileManager.GetBaseName(r.query_string)
        path = f"./deck/{name}"
        if name.endswith(".json") and FileManager.Exists(path):
            FileManager.Delete(path)
            return JsonResponse({'result': 'deleted'})
        return JsonResponse({'error': 'not found'}, 404)

    def list_heroes(self, r: Request) -> Response:
        from engine.browser import marvelcdb
        return JsonResponse(marvelcdb.list_heroes())

    def convert_marvelcdb(self, r: Request) -> Response:
        """POST <MarvelCDB deck json> (or {data: ...}) -> {deck, warnings} | {error}"""
        from engine.browser import marvelcdb
        try:
            body = json.loads(r.body or "{}")
            if isinstance(body, dict) and "data" in body and "slots" not in body:
                body = json.loads(body["data"]) if isinstance(body["data"], str) else body["data"]
            return JsonResponse(marvelcdb.convert(body))
        except (ValueError, KeyError, TypeError) as exc:
            return JsonResponse({"error": str(exc)}, 400)


def restore_file(path: str, data: Any) -> None:
    """Write a file coming from IndexedDB without echoing it back to the host."""
    import base64
    import os
    prefix = "./" + path.lstrip("./")
    os.makedirs(os.path.dirname(prefix) or ".", exist_ok=True)
    raw = base64.b64decode(data) if isinstance(data, str) else bytes(data)
    with open(prefix, "wb") as f:
        f.write(raw)
