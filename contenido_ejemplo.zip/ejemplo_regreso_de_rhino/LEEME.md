# Paquete de ejemplo: «El regreso de Rhino»

Un escenario nuevo contra Rhino (villano del juego, cartas 01094/01095) con:
* un **plan principal nuevo** (`99001a/99001b`) y un **plan secundario** sin script (`99004`),
* una **traición con reglas sin programar** (`99003`: `"reglas"` en `cartas/cartas.json`),
* un plan secundario que **al ser derrotado** te hace robar (`99004`),
* un **set modular nuevo** «Secuaces de Rhino» con un esbirro nuevo sin script (`99002`, Guard desde `desc`) y una carta del juego (`01102`),
* su propia **caja** en New Game (`caja.json`).

Las imágenes van en `imagenes/` con el id de la carta como nombre (`99002.jpg`…). Este ejemplo no trae: las cartas se dibujan solas.
Comprime la carpeta en un ZIP y usa **Importar contenido** en el menú de la app.
